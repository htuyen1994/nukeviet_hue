-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: 127.0.0.1
-- Generation Time: June 2, 2015, 07:53 AM GMT
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `nukeviet`
--


-- ---------------------------------------


--
-- Table structure for table `nv4_authors`
--

DROP TABLE IF EXISTS `nv4_authors`;
CREATE TABLE `nv4_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) DEFAULT '',
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_authors`
--

INSERT INTO `nv4_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', 'a5243f7d8f6bcc900636067e2df7a656', 1433228247, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/48.0 Chrome/42.0.2311.152_coc_coc Safari/537.36');


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_config`
--

DROP TABLE IF EXISTS `nv4_authors_config`;
CREATE TABLE `nv4_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_module`
--

DROP TABLE IF EXISTS `nv4_authors_module`;
CREATE TABLE `nv4_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `lang_key` varchar(50) NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32) DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_authors_module`
--

INSERT INTO `nv4_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, '24fa7cb415cdfd07483ee8192eba9caa'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '284d0ff08e7d8514cbc2a1aa9f3ad51c'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, 'dd58492ae46033da36240edde566c07f'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, 'c9a7df6a79f0f6feea597847efe8a11b'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, 'a67dbd8c2ae012f72369b23318e16b35'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, 'a6ec61e1c66d783f3e2887ec4ee8edd5'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, '4be2485a8390b1151d4c45e29021f709'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '0db057e33ffb74be22400c2e028b3584'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, 'e2727d113a011c0e7f8974627a3c8a09'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, '4623c1e1f3516da46d4f5bdc2617513c'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '088ac8451ff481a270ca314f8a9501cf');


-- ---------------------------------------


--
-- Table structure for table `nv4_banip`
--

DROP TABLE IF EXISTS `nv4_banip`;
CREATE TABLE `nv4_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_click`
--

DROP TABLE IF EXISTS `nv4_banners_click`;
CREATE TABLE `nv4_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_click`
--

INSERT INTO `nv4_banners_click` VALUES
(2, 1432614506, 0, '127.0.0.1', 'ZZ', '', 'firefox', '', 'Windows NT', 'http://nukeviet.my:88/news/');


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_clients`
--

DROP TABLE IF EXISTS `nv4_banners_clients`;
CREATE TABLE `nv4_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(80) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_plans`
--

DROP TABLE IF EXISTS `nv4_banners_plans`;
CREATE TABLE `nv4_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) DEFAULT '',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_plans`
--

INSERT INTO `nv4_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_rows`
--

DROP TABLE IF EXISTS `nv4_banners_rows`;
CREATE TABLE `nv4_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) DEFAULT '',
  `imageforswf` varchar(255) DEFAULT '',
  `click_url` varchar(255) DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_rows`
--

INSERT INTO `nv4_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', '', 'http://www.mofa.gov.vn', '_blank', 1432349800, 1432349800, 0, 0, 1, 1), 
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', '', 'http://vinades.vn', '_blank', 1432349800, 1432349800, 0, 1, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.gif', 'gif', 'image/gif', 510, 65, '', '', 'http://webnhanh.vn', '_blank', 1432349800, 1432349800, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_config`
--

DROP TABLE IF EXISTS `nv4_config`;
CREATE TABLE `nv4_config` (
  `lang` varchar(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` text,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_config`
--

INSERT INTO `nv4_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle - sitename'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'ssl_https', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2097152'), 
('sys', 'global', 'upload_checking_mode', 'mild'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '0'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'allow_adminlangs', 'en,vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '1'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', 'news'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'openid_mode', '1'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', 'yahoo,google'), 
('sys', 'global', 'optActive', '1'), 
('sys', 'global', 'timestamp', '2'), 
('sys', 'global', 'mudim_displaymode', '1'), 
('sys', 'global', 'mudim_method', '4'), 
('sys', 'global', 'mudim_showpanel', '1'), 
('sys', 'global', 'mudim_active', '1'), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'version', '4.0.16'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'google_client_id', ''), 
('sys', 'global', 'google_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'adminrelogin_max', '3'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '0'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '5'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'define', 'nv_gfx_width', '120'), 
('sys', 'define', 'nv_gfx_height', '25'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, sub, sup, table, tbody, td, th, tr, u, ul, iframe, figure, figcaption, video, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('vi', 'global', 'site_domain', ''), 
('vi', 'global', 'site_name', 'hue'), 
('vi', 'global', 'site_logo', 'images/logo.png'), 
('vi', 'global', 'site_description', 'NukeViet CMS 4.x Developed by VINADES.,JSC'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'site_theme', 'default'), 
('vi', 'global', 'mobile_theme', ''), 
('vi', 'global', 'site_home_module', 'news'), 
('vi', 'global', 'switch_mobi_des', '1'), 
('vi', 'global', 'upload_logo', 'images/logo.png'), 
('vi', 'global', 'autologosize1', '50'), 
('vi', 'global', 'autologosize2', '40'), 
('vi', 'global', 'autologosize3', '30'), 
('vi', 'global', 'autologomod', ''), 
('vi', 'global', 'name_show', '0'), 
('vi', 'global', 'cronjobs_next_time', '1433231902'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'seotools', 'prcservice', ''), 
('vi', 'about', 'auto_postcomm', '1'), 
('vi', 'about', 'allowed_comm', '-1'), 
('vi', 'about', 'view_comm', '6'), 
('vi', 'about', 'setcomm', '4'), 
('vi', 'about', 'activecomm', '0'), 
('vi', 'about', 'emailcomm', '0'), 
('vi', 'about', 'adminscomm', ''), 
('vi', 'about', 'sortcomm', '0'), 
('vi', 'about', 'captcha', '1'), 
('vi', 'news', 'indexfile', 'viewcat_main_right'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '52'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showtooltip', '1'), 
('vi', 'news', 'tooltip_position', 'bottom'), 
('vi', 'news', 'tooltip_length', '150'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'news', 'show_no_image', ''), 
('vi', 'news', 'allowed_rating_point', '1'), 
('vi', 'news', 'facebookappid', ''), 
('vi', 'news', 'socialbutton', '1'), 
('vi', 'news', 'alias_lower', '1'), 
('vi', 'news', 'tags_alias', '0'), 
('vi', 'news', 'auto_tags', '0'), 
('vi', 'news', 'tags_remind', '1'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'news', 'imgposition', '2'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'allowed_comm', '-1'), 
('vi', 'news', 'view_comm', '6'), 
('vi', 'news', 'setcomm', '4'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'adminscomm', ''), 
('vi', 'news', 'sortcomm', '0'), 
('vi', 'news', 'captcha', '1'), 
('vi', 'page', 'auto_postcomm', '1'), 
('vi', 'page', 'allowed_comm', '-1'), 
('vi', 'page', 'view_comm', '6'), 
('vi', 'page', 'setcomm', '4'), 
('vi', 'page', 'activecomm', '1'), 
('vi', 'page', 'emailcomm', '0'), 
('vi', 'page', 'adminscomm', ''), 
('vi', 'page', 'sortcomm', '0'), 
('vi', 'page', 'captcha', '1'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'admin@gmail.com'), 
('sys', 'global', 'error_send_email', 'admin@gmail.com'), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'my_domains', 'nukeviet.my,nguyenhue.my'), 
('sys', 'global', 'cookie_prefix', 'nv3c_Wn5sg'), 
('sys', 'global', 'session_prefix', 'nv3s_G9zbk8'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '0'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', 'DNK9kb86G5B3OoS-PKxKrgzSvZG_OhuQdzqEvjysSq4,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'shops', 'groups_notify', '3'), 
('vi', 'shops', 'auto_postcomm', '1'), 
('vi', 'shops', 'allowed_comm', '-1'), 
('vi', 'shops', 'point_new_order', '0'), 
('vi', 'shops', 'review_active', '1'), 
('vi', 'shops', 'review_check', '1'), 
('vi', 'shops', 'review_captcha', '1'), 
('vi', 'shops', 'group_price', ''), 
('vi', 'shops', 'point_conversion', '0'), 
('vi', 'shops', 'active_order_popup', '1'), 
('vi', 'shops', 'active_order_non_detail', '1'), 
('vi', 'shops', 'active_price', '1'), 
('vi', 'shops', 'active_order_number', '0'), 
('vi', 'shops', 'order_day', '0'), 
('vi', 'shops', 'order_nexttime', '0'), 
('vi', 'shops', 'active_payment', '1'), 
('vi', 'shops', 'groups_price', '3'), 
('vi', 'shops', 'active_tooltip', '1'), 
('vi', 'shops', 'timecheckstatus', '0'), 
('vi', 'shops', 'show_product_code', '1'), 
('vi', 'shops', 'show_compare', '1'), 
('vi', 'shops', 'show_displays', '0'), 
('vi', 'shops', 'use_shipping', '1'), 
('vi', 'shops', 'use_coupons', '0'), 
('vi', 'shops', 'active_wishlist', '1'), 
('vi', 'shops', 'active_gift', '1'), 
('vi', 'shops', 'active_warehouse', '1'), 
('vi', 'shops', 'tags_alias', '0'), 
('vi', 'shops', 'auto_tags', '1'), 
('vi', 'shops', 'tags_remind', '0'), 
('vi', 'shops', 'point_active', '0'), 
('vi', 'shops', 'image_size', '100x100'), 
('vi', 'shops', 'home_view', 'view_home_cat'), 
('vi', 'shops', 'per_page', '20'), 
('vi', 'shops', 'per_row', '3'), 
('vi', 'shops', 'money_unit', 'VND'), 
('vi', 'shops', 'weight_unit', 'g'), 
('vi', 'shops', 'post_auto_member', '0'), 
('vi', 'shops', 'auto_check_order', '1'), 
('vi', 'shops', 'format_order_id', 'S%06s'), 
('vi', 'shops', 'format_code_id', 'S%06s'), 
('vi', 'shops', 'facebookappid', ''), 
('vi', 'shops', 'active_guest_order', '1'), 
('vi', 'shops', 'active_showhomtext', '1'), 
('vi', 'shops', 'active_order', '1'), 
('vi', 'download', 'auto_postcomm', '1'), 
('vi', 'download', 'allowed_comm', '-1'), 
('vi', 'download', 'view_comm', '6'), 
('vi', 'download', 'setcomm', '4'), 
('vi', 'download', 'activecomm', '1'), 
('vi', 'download', 'emailcomm', '0'), 
('vi', 'download', 'adminscomm', ''), 
('vi', 'download', 'sortcomm', '0'), 
('vi', 'download', 'captcha', '1'), 
('vi', 'shops', 'view_comm', '6'), 
('vi', 'shops', 'setcomm', '4'), 
('vi', 'shops', 'activecomm', '1'), 
('vi', 'shops', 'emailcomm', '0'), 
('vi', 'shops', 'adminscomm', ''), 
('vi', 'shops', 'sortcomm', '0'), 
('vi', 'shops', 'captcha', '1'), 
('vi', 'shops', 'homewidth', '100'), 
('vi', 'shops', 'homeheight', '100');


-- ---------------------------------------


--
-- Table structure for table `nv4_cookies`
--

DROP TABLE IF EXISTS `nv4_cookies`;
CREATE TABLE `nv4_cookies` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `domain` varchar(100) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_counter`
--

DROP TABLE IF EXISTS `nv4_counter`;
CREATE TABLE `nv4_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `vi_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_counter`
--

INSERT INTO `nv4_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1433230100, 0), 
('total', 'hits', 1433230100, 45, 45), 
('year', '2015', 1433230100, 45, 45), 
('year', '2016', 0, 0, 0), 
('year', '2017', 0, 0, 0), 
('year', '2018', 0, 0, 0), 
('year', '2019', 0, 0, 0), 
('year', '2020', 0, 0, 0), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('month', 'Jan', 0, 0, 0), 
('month', 'Feb', 0, 0, 0), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 0, 0, 0), 
('month', 'May', 1432806464, 37, 37), 
('month', 'Jun', 1433230100, 8, 8), 
('month', 'Jul', 0, 0, 0), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 0, 0, 0), 
('month', 'Nov', 0, 0, 0), 
('month', 'Dec', 0, 0, 0), 
('day', '01', 0, 0, 0), 
('day', '02', 1433230100, 8, 8), 
('day', '03', 0, 0, 0), 
('day', '04', 0, 0, 0), 
('day', '05', 0, 0, 0), 
('day', '06', 0, 0, 0), 
('day', '07', 0, 0, 0), 
('day', '08', 0, 0, 0), 
('day', '09', 0, 0, 0), 
('day', '10', 0, 0, 0), 
('day', '11', 0, 0, 0), 
('day', '12', 0, 0, 0), 
('day', '13', 0, 0, 0), 
('day', '14', 0, 0, 0), 
('day', '15', 0, 0, 0), 
('day', '16', 0, 0, 0), 
('day', '17', 0, 0, 0), 
('day', '18', 0, 0, 0), 
('day', '19', 0, 0, 0), 
('day', '20', 0, 0, 0), 
('day', '21', 0, 0, 0), 
('day', '22', 0, 0, 0), 
('day', '23', 1432370482, 0, 0), 
('day', '24', 0, 0, 0), 
('day', '25', 0, 0, 0), 
('day', '26', 1432635439, 0, 0), 
('day', '27', 0, 0, 0), 
('day', '28', 1432806464, 0, 0), 
('day', '29', 0, 0, 0), 
('day', '30', 0, 0, 0), 
('day', '31', 0, 0, 0), 
('dayofweek', 'Sunday', 0, 0, 0), 
('dayofweek', 'Monday', 0, 0, 0), 
('dayofweek', 'Tuesday', 1433230100, 23, 23), 
('dayofweek', 'Wednesday', 0, 0, 0), 
('dayofweek', 'Thursday', 1432806464, 15, 15), 
('dayofweek', 'Friday', 0, 0, 0), 
('dayofweek', 'Saturday', 1432370482, 7, 7), 
('hour', '00', 0, 0, 0), 
('hour', '01', 0, 0, 0), 
('hour', '02', 0, 0, 0), 
('hour', '03', 0, 0, 0), 
('hour', '04', 0, 0, 0), 
('hour', '05', 0, 0, 0), 
('hour', '06', 0, 0, 0), 
('hour', '07', 0, 0, 0), 
('hour', '08', 1433208520, 1, 1), 
('hour', '09', 1433212613, 1, 1), 
('hour', '10', 1433217098, 2, 2), 
('hour', '11', 1432788071, 0, 0), 
('hour', '12', 1432791672, 0, 0), 
('hour', '13', 1433228238, 3, 3), 
('hour', '14', 1433230100, 1, 1), 
('hour', '15', 1432800677, 0, 0), 
('hour', '16', 1432806464, 0, 0), 
('hour', '17', 1432635439, 0, 0), 
('hour', '18', 0, 0, 0), 
('hour', '19', 0, 0, 0), 
('hour', '20', 0, 0, 0), 
('hour', '21', 0, 0, 0), 
('hour', '22', 0, 0, 0), 
('hour', '23', 0, 0, 0), 
('bot', 'Alexa', 0, 0, 0), 
('bot', 'AltaVista Scooter', 0, 0, 0), 
('bot', 'Altavista Mercator', 0, 0, 0), 
('bot', 'Altavista Search', 0, 0, 0), 
('bot', 'Aport.ru Bot', 0, 0, 0), 
('bot', 'Ask Jeeves', 0, 0, 0), 
('bot', 'Baidu', 0, 0, 0), 
('bot', 'Exabot', 0, 0, 0), 
('bot', 'FAST Enterprise', 0, 0, 0), 
('bot', 'FAST WebCrawler', 0, 0, 0), 
('bot', 'Francis', 0, 0, 0), 
('bot', 'Gigablast', 0, 0, 0), 
('bot', 'Google AdsBot', 0, 0, 0), 
('bot', 'Google Adsense', 0, 0, 0), 
('bot', 'Google Bot', 0, 0, 0), 
('bot', 'Google Desktop', 0, 0, 0), 
('bot', 'Google Feedfetcher', 0, 0, 0), 
('bot', 'Heise IT-Markt', 0, 0, 0), 
('bot', 'Heritrix', 0, 0, 0), 
('bot', 'IBM Research', 0, 0, 0), 
('bot', 'ICCrawler - ICjobs', 0, 0, 0), 
('bot', 'Ichiro', 0, 0, 0), 
('bot', 'InfoSeek Spider', 0, 0, 0), 
('bot', 'Lycos.com Bot', 0, 0, 0), 
('bot', 'MSN Bot', 0, 0, 0), 
('bot', 'MSN Bot Media', 0, 0, 0), 
('bot', 'MSN Bot News', 0, 0, 0), 
('bot', 'MSN NewsBlogs', 0, 0, 0), 
('bot', 'Majestic-12', 0, 0, 0), 
('bot', 'Metager', 0, 0, 0), 
('bot', 'NG-Search', 0, 0, 0), 
('bot', 'Nutch Bot', 0, 0, 0), 
('bot', 'NutchCVS', 0, 0, 0), 
('bot', 'OmniExplorer', 0, 0, 0), 
('bot', 'Online Link Validator', 0, 0, 0), 
('bot', 'Open-source Web Search', 0, 0, 0), 
('bot', 'Psbot', 0, 0, 0), 
('bot', 'Rambler', 0, 0, 0), 
('bot', 'SEO Crawler', 0, 0, 0), 
('bot', 'SEOSearch', 0, 0, 0), 
('bot', 'Seekport', 0, 0, 0), 
('bot', 'Sensis', 0, 0, 0), 
('bot', 'Seoma', 0, 0, 0), 
('bot', 'Snappy', 0, 0, 0), 
('bot', 'Steeler', 0, 0, 0), 
('bot', 'Synoo', 0, 0, 0), 
('bot', 'Telekom', 0, 0, 0), 
('bot', 'TurnitinBot', 0, 0, 0), 
('bot', 'Vietnamese Search', 0, 0, 0), 
('bot', 'Voyager', 0, 0, 0), 
('bot', 'W3 Sitesearch', 0, 0, 0), 
('bot', 'W3C Linkcheck', 0, 0, 0), 
('bot', 'W3C Validator', 0, 0, 0), 
('bot', 'WiseNut', 0, 0, 0), 
('bot', 'YaCy', 0, 0, 0), 
('bot', 'Yahoo Bot', 0, 0, 0), 
('bot', 'Yahoo MMCrawler', 0, 0, 0), 
('bot', 'Yahoo Slurp', 0, 0, 0), 
('bot', 'YahooSeeker', 0, 0, 0), 
('bot', 'Yandex', 0, 0, 0), 
('bot', 'Yandex Blog', 0, 0, 0), 
('bot', 'Yandex Direct Bot', 0, 0, 0), 
('bot', 'Yandex Something', 0, 0, 0), 
('browser', 'netcaptor', 0, 0, 0), 
('browser', 'opera', 0, 0, 0), 
('browser', 'aol', 0, 0, 0), 
('browser', 'aol2', 0, 0, 0), 
('browser', 'mosaic', 0, 0, 0), 
('browser', 'k-meleon', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'avantbrowser', 0, 0, 0), 
('browser', 'avantgo', 0, 0, 0), 
('browser', 'proxomitron', 0, 0, 0), 
('browser', 'chrome', 1433230100, 9, 9), 
('browser', 'safari', 0, 0, 0), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'links', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'abrowse', 0, 0, 0), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'ant', 0, 0, 0), 
('browser', 'aweb', 0, 0, 0), 
('browser', 'beonex', 0, 0, 0), 
('browser', 'blazer', 0, 0, 0), 
('browser', 'camino', 0, 0, 0), 
('browser', 'chimera', 0, 0, 0), 
('browser', 'columbus', 0, 0, 0), 
('browser', 'crazybrowser', 0, 0, 0), 
('browser', 'curl', 0, 0, 0), 
('browser', 'deepnet', 0, 0, 0), 
('browser', 'dillo', 0, 0, 0), 
('browser', 'doris', 0, 0, 0), 
('browser', 'elinks', 0, 0, 0), 
('browser', 'epiphany', 0, 0, 0), 
('browser', 'ibrowse', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'ice', 0, 0, 0), 
('browser', 'isilox', 0, 0, 0), 
('browser', 'lotus', 0, 0, 0), 
('browser', 'lunascape', 0, 0, 0), 
('browser', 'maxthon', 0, 0, 0), 
('browser', 'mbrowser', 0, 0, 0), 
('browser', 'multibrowser', 0, 0, 0), 
('browser', 'nautilus', 0, 0, 0), 
('browser', 'netfront', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'oregano', 0, 0, 0), 
('browser', 'phaseout', 0, 0, 0), 
('browser', 'plink', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'shiira', 0, 0, 0), 
('browser', 'sleipnir', 0, 0, 0), 
('browser', 'slimbrowser', 0, 0, 0), 
('browser', 'staroffice', 0, 0, 0), 
('browser', 'sunrise', 0, 0, 0), 
('browser', 'voyager', 0, 0, 0), 
('browser', 'w3m', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'xiino', 0, 0, 0), 
('browser', 'explorer', 0, 0, 0), 
('browser', 'firefox', 1432806464, 36, 36), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'netscape2', 0, 0, 0), 
('browser', 'mozilla', 0, 0, 0), 
('browser', 'mozilla2', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 0, 0, 0), 
('browser', 'Unknown', 0, 0, 0), 
('browser', 'Unspecified', 0, 0, 0), 
('os', 'windows8', 0, 0, 0), 
('os', 'windows7', 0, 0, 0), 
('os', 'windowsvista', 0, 0, 0), 
('os', 'windows2003', 0, 0, 0), 
('os', 'windowsxp', 0, 0, 0), 
('os', 'windowsxp2', 0, 0, 0), 
('os', 'windows2k', 0, 0, 0), 
('os', 'windows95', 0, 0, 0), 
('os', 'windowsce', 0, 0, 0), 
('os', 'windowsme', 0, 0, 0), 
('os', 'windowsme2', 0, 0, 0), 
('os', 'windowsnt', 0, 0, 0), 
('os', 'windowsnt2', 1433230100, 45, 45), 
('os', 'windows98', 0, 0, 0), 
('os', 'windows', 0, 0, 0), 
('os', 'linux', 0, 0, 0), 
('os', 'linux2', 0, 0, 0), 
('os', 'linux3', 0, 0, 0), 
('os', 'macosx', 0, 0, 0), 
('os', 'macppc', 0, 0, 0), 
('os', 'mac', 0, 0, 0), 
('os', 'amiga', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'freebsd2', 0, 0, 0), 
('os', 'irix', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'netbsd2', 0, 0, 0), 
('os', 'os2', 0, 0, 0), 
('os', 'os22', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'openbsd2', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('os', 'palm2', 0, 0, 0), 
('os', 'Unspecified', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 0, 0, 0), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 0, 0, 0), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 0, 0, 0), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 0, 0, 0), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 0, 0, 0), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 0, 0, 0), 
('country', 'CO', 0, 0, 0), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 0, 0, 0), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 0, 0, 0), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 0, 0, 0), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 0, 0, 0), 
('country', 'EG', 0, 0, 0), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 0, 0, 0), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 0, 0, 0), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 0, 0, 0), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 0, 0, 0), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 0, 0, 0), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 0, 0, 0), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 0, 0, 0), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 0, 0, 0), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 0, 0, 0), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 0, 0, 0), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 0, 0, 0), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 0, 0, 0), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 0, 0, 0), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 0, 0, 0), 
('country', 'NO', 0, 0, 0), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 0, 0, 0), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 0, 0, 0), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 0, 0, 0), 
('country', 'PR', 0, 0, 0), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 0, 0, 0), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 0, 0, 0), 
('country', 'RU', 0, 0, 0), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 0, 0, 0), 
('country', 'SG', 0, 0, 0), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 0, 0, 0), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 0, 0, 0), 
('country', 'UY', 0, 0, 0), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 0, 0, 0), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 0, 0, 0), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1433230100, 45, 45), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_cronjobs`
--

DROP TABLE IF EXISTS `nv4_cronjobs`;
CREATE TABLE `nv4_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_cronjobs`
--

INSERT INTO `nv4_cronjobs` VALUES
(1, 1432349800, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1433231602, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1432349800, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1433208520, 1, 'Tự động lưu CSDL'), 
(3, 1432349800, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1433230101, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1432349800, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1433230101, 1, 'Xóa IP log files, Xóa các file nhật ký truy cập'), 
(5, 1432349800, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1433208520, 1, 'Xóa các file error_log quá hạn'), 
(6, 1432349800, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1432349800, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1433230101, 1, 'Xóa các referer quá hạn'), 
(8, 1432349800, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 0, 1, 1433208520, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'), 
(9, 1432349800, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1433225603, 1, 'Kiểm tra phiên bản NukeViet'), 
(10, 1432349800, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1433208520, 1, 'Xóa thông báo cũ');


-- ---------------------------------------


--
-- Table structure for table `nv4_extension_files`
--

DROP TABLE IF EXISTS `nv4_extension_files`;
CREATE TABLE `nv4_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `lastmodified` int(11) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  AUTO_INCREMENT=642  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_extension_files`
--

INSERT INTO `nv4_extension_files` VALUES
(1, 'module', 'contact', 'modules/contact/action_mysql.php', 1432349800, 0), 
(2, 'module', 'contact', 'modules/contact/action_oci.php', 1432349800, 0), 
(3, 'module', 'contact', 'modules/contact/admin/change_status.php', 1432349800, 0), 
(4, 'module', 'contact', 'modules/contact/admin/content.php', 1432349800, 0), 
(5, 'module', 'contact', 'modules/contact/admin/del.php', 1432349800, 0), 
(6, 'module', 'contact', 'modules/contact/admin/del_department.php', 1432349800, 0), 
(7, 'module', 'contact', 'modules/contact/admin/department.php', 1432349800, 0), 
(8, 'module', 'contact', 'modules/contact/admin/index.html', 1432349800, 0), 
(9, 'module', 'contact', 'modules/contact/admin/main.php', 1432349800, 0), 
(10, 'module', 'contact', 'modules/contact/admin/reply.php', 1432349800, 0), 
(11, 'module', 'contact', 'modules/contact/admin/row.php', 1432349800, 0), 
(12, 'module', 'contact', 'modules/contact/admin/view.php', 1432349800, 0), 
(13, 'module', 'contact', 'modules/contact/admin.functions.php', 1432349800, 0), 
(14, 'module', 'contact', 'modules/contact/admin.menu.php', 1432349800, 0), 
(15, 'module', 'contact', 'modules/contact/blocks/global.department.ini', 1432349800, 0), 
(16, 'module', 'contact', 'modules/contact/blocks/global.department.php', 1432349800, 0), 
(17, 'module', 'contact', 'modules/contact/funcs/index.html', 1432349800, 0), 
(18, 'module', 'contact', 'modules/contact/funcs/main.php', 1432349800, 0), 
(19, 'module', 'contact', 'modules/contact/functions.php', 1432349800, 0), 
(20, 'module', 'contact', 'modules/contact/index.html', 1432349800, 0), 
(21, 'module', 'contact', 'modules/contact/js/admin.js', 1432349800, 0), 
(22, 'module', 'contact', 'modules/contact/js/index.html', 1432349800, 0), 
(23, 'module', 'contact', 'modules/contact/js/user.js', 1432349800, 0), 
(24, 'module', 'contact', 'modules/contact/language/admin_en.php', 1432349800, 0), 
(25, 'module', 'contact', 'modules/contact/language/admin_vi.php', 1432349800, 0), 
(26, 'module', 'contact', 'modules/contact/language/en.php', 1432349800, 0), 
(27, 'module', 'contact', 'modules/contact/language/index.html', 1432349800, 0), 
(28, 'module', 'contact', 'modules/contact/language/vi.php', 1432349800, 0), 
(29, 'module', 'contact', 'modules/contact/menu.php', 1432349800, 0), 
(30, 'module', 'contact', 'modules/contact/siteinfo.php', 1432349800, 0), 
(31, 'module', 'contact', 'modules/contact/theme.php', 1432349800, 0), 
(32, 'module', 'contact', 'modules/contact/version.php', 1432349800, 0), 
(33, 'module', 'contact', 'themes/admin_default/modules/contact/content.tpl', 1432349800, 0), 
(34, 'module', 'contact', 'themes/admin_default/modules/contact/department.tpl', 1432349800, 0), 
(35, 'module', 'contact', 'themes/admin_default/modules/contact/index.html', 1432349800, 0), 
(36, 'module', 'contact', 'themes/admin_default/modules/contact/main.tpl', 1432349800, 0), 
(37, 'module', 'contact', 'themes/admin_default/modules/contact/reply.tpl', 1432349800, 0), 
(38, 'module', 'contact', 'themes/admin_default/modules/contact/row.tpl', 1432349800, 0), 
(39, 'module', 'contact', 'themes/admin_default/modules/contact/view.tpl', 1432349800, 0), 
(40, 'module', 'contact', 'themes/default/modules/contact/block.department.tpl', 1432349800, 0), 
(41, 'module', 'contact', 'themes/default/modules/contact/form.tpl', 1432349800, 0), 
(42, 'module', 'contact', 'themes/default/modules/contact/index.html', 1432349800, 0), 
(43, 'module', 'contact', 'themes/default/modules/contact/sendcontact.tpl', 1432349800, 0), 
(44, 'module', 'contact', 'themes/modern/modules/contact/form.tpl', 1432349800, 0), 
(45, 'module', 'contact', 'themes/modern/modules/contact/index.html', 1432349800, 0), 
(46, 'module', 'contact', 'themes/modern/modules/contact/sendcontact.tpl', 1432349800, 0), 
(47, 'module', 'contact', 'themes/admin_default/css/contact.css', 1432349800, 0), 
(48, 'module', 'contact', 'themes/modern/css/contact.css', 1432349800, 0), 
(49, 'module', 'news', 'modules/news/action_mysql.php', 1432349800, 0), 
(50, 'module', 'news', 'modules/news/action_oci.php', 1432349800, 0), 
(51, 'module', 'news', 'modules/news/admin/addtotopics.php', 1432349800, 0), 
(52, 'module', 'news', 'modules/news/admin/alias.php', 1432349800, 0), 
(53, 'module', 'news', 'modules/news/admin/block.php', 1432349800, 0), 
(54, 'module', 'news', 'modules/news/admin/cat.php', 1432349800, 0), 
(55, 'module', 'news', 'modules/news/admin/chang_block_cat.php', 1432349800, 0), 
(56, 'module', 'news', 'modules/news/admin/change_block.php', 1432349800, 0), 
(57, 'module', 'news', 'modules/news/admin/change_cat.php', 1432349800, 0), 
(58, 'module', 'news', 'modules/news/admin/change_source.php', 1432349800, 0), 
(59, 'module', 'news', 'modules/news/admin/change_topic.php', 1432349800, 0), 
(60, 'module', 'news', 'modules/news/admin/content.php', 1432349800, 0), 
(61, 'module', 'news', 'modules/news/admin/declined.php', 1432349800, 0), 
(62, 'module', 'news', 'modules/news/admin/del_block_cat.php', 1432349800, 0), 
(63, 'module', 'news', 'modules/news/admin/del_cat.php', 1432349800, 0), 
(64, 'module', 'news', 'modules/news/admin/del_content.php', 1432349800, 0), 
(65, 'module', 'news', 'modules/news/admin/del_source.php', 1432349800, 0), 
(66, 'module', 'news', 'modules/news/admin/del_topic.php', 1432349800, 0), 
(67, 'module', 'news', 'modules/news/admin/exptime.php', 1432349800, 0), 
(68, 'module', 'news', 'modules/news/admin/groups.php', 1432349800, 0), 
(69, 'module', 'news', 'modules/news/admin/index.html', 1432349800, 0), 
(70, 'module', 'news', 'modules/news/admin/list_block.php', 1432349800, 0), 
(71, 'module', 'news', 'modules/news/admin/list_block_cat.php', 1432349800, 0), 
(72, 'module', 'news', 'modules/news/admin/list_cat.php', 1432349800, 0), 
(73, 'module', 'news', 'modules/news/admin/list_source.php', 1432349800, 0), 
(74, 'module', 'news', 'modules/news/admin/list_topic.php', 1432349800, 0), 
(75, 'module', 'news', 'modules/news/admin/main.php', 1432349800, 0), 
(76, 'module', 'news', 'modules/news/admin/publtime.php', 1432349800, 0), 
(77, 'module', 'news', 'modules/news/admin/re-published.php', 1432349800, 0), 
(78, 'module', 'news', 'modules/news/admin/rpc.php', 1432349800, 0), 
(79, 'module', 'news', 'modules/news/admin/setting.php', 1432349800, 0), 
(80, 'module', 'news', 'modules/news/admin/sourceajax.php', 1432349800, 0), 
(81, 'module', 'news', 'modules/news/admin/sources.php', 1432349800, 0), 
(82, 'module', 'news', 'modules/news/admin/tags.php', 1432349800, 0), 
(83, 'module', 'news', 'modules/news/admin/tagsajax.php', 1432349800, 0), 
(84, 'module', 'news', 'modules/news/admin/tools.php', 1432349800, 0), 
(85, 'module', 'news', 'modules/news/admin/topicajax.php', 1432349800, 0), 
(86, 'module', 'news', 'modules/news/admin/topicdelnews.php', 1432349800, 0), 
(87, 'module', 'news', 'modules/news/admin/topics.php', 1432349800, 0), 
(88, 'module', 'news', 'modules/news/admin/topicsnews.php', 1432349800, 0), 
(89, 'module', 'news', 'modules/news/admin/view.php', 1432349800, 0), 
(90, 'module', 'news', 'modules/news/admin/waiting.php', 1432349800, 0), 
(91, 'module', 'news', 'modules/news/admin.functions.php', 1432349800, 0), 
(92, 'module', 'news', 'modules/news/admin.menu.php', 1432349800, 0), 
(93, 'module', 'news', 'modules/news/blocks/global.block_category.ini', 1432349800, 0), 
(94, 'module', 'news', 'modules/news/blocks/global.block_category.php', 1432349800, 0), 
(95, 'module', 'news', 'modules/news/blocks/global.block_groups.ini', 1432349800, 0), 
(96, 'module', 'news', 'modules/news/blocks/global.block_groups.php', 1432349800, 0), 
(97, 'module', 'news', 'modules/news/blocks/global.block_news_cat.ini', 1432349800, 0), 
(98, 'module', 'news', 'modules/news/blocks/global.block_news_cat.php', 1432349800, 0), 
(99, 'module', 'news', 'modules/news/blocks/global.block_tophits.ini', 1432349800, 0), 
(100, 'module', 'news', 'modules/news/blocks/global.block_tophits.php', 1432349800, 0), 
(101, 'module', 'news', 'modules/news/blocks/index.html', 1432349800, 0), 
(102, 'module', 'news', 'modules/news/blocks/module.block_content.php', 1432349800, 0), 
(103, 'module', 'news', 'modules/news/blocks/module.block_headline.ini', 1432349800, 0), 
(104, 'module', 'news', 'modules/news/blocks/module.block_headline.php', 1432349800, 0), 
(105, 'module', 'news', 'modules/news/blocks/module.block_news.ini', 1432349800, 0), 
(106, 'module', 'news', 'modules/news/blocks/module.block_news.php', 1432349800, 0), 
(107, 'module', 'news', 'modules/news/blocks/module.block_newscenter.ini', 1432349800, 0), 
(108, 'module', 'news', 'modules/news/blocks/module.block_newscenter.php', 1432349800, 0), 
(109, 'module', 'news', 'modules/news/comment.php', 1432349800, 0), 
(110, 'module', 'news', 'modules/news/funcs/content.php', 1432349800, 0), 
(111, 'module', 'news', 'modules/news/funcs/detail.php', 1432349800, 0), 
(112, 'module', 'news', 'modules/news/funcs/groups.php', 1432349800, 0), 
(113, 'module', 'news', 'modules/news/funcs/index.html', 1432349800, 0), 
(114, 'module', 'news', 'modules/news/funcs/main.php', 1432349800, 0), 
(115, 'module', 'news', 'modules/news/funcs/print.php', 1432349800, 0), 
(116, 'module', 'news', 'modules/news/funcs/rating.php', 1432349800, 0), 
(117, 'module', 'news', 'modules/news/funcs/rss.php', 1432349800, 0), 
(118, 'module', 'news', 'modules/news/funcs/savefile.php', 1432349800, 0), 
(119, 'module', 'news', 'modules/news/funcs/search.php', 1432349800, 0), 
(120, 'module', 'news', 'modules/news/funcs/sendmail.php', 1432349800, 0), 
(121, 'module', 'news', 'modules/news/funcs/sitemap.php', 1432349800, 0), 
(122, 'module', 'news', 'modules/news/funcs/tag.php', 1432349800, 0), 
(123, 'module', 'news', 'modules/news/funcs/topic.php', 1432349800, 0), 
(124, 'module', 'news', 'modules/news/funcs/viewcat.php', 1432349800, 0), 
(125, 'module', 'news', 'modules/news/functions.php', 1432349800, 0), 
(126, 'module', 'news', 'modules/news/global.functions.php', 1432349800, 0), 
(127, 'module', 'news', 'modules/news/index.html', 1432349800, 0), 
(128, 'module', 'news', 'modules/news/js/admin.js', 1432349800, 0), 
(129, 'module', 'news', 'modules/news/js/content.js', 1432349800, 0), 
(130, 'module', 'news', 'modules/news/js/index.html', 1432349800, 0), 
(131, 'module', 'news', 'modules/news/js/user.js', 1432349800, 0), 
(132, 'module', 'news', 'modules/news/language/admin_en.php', 1432349800, 0), 
(133, 'module', 'news', 'modules/news/language/admin_vi.php', 1432349800, 0), 
(134, 'module', 'news', 'modules/news/language/block.global.block_category_en.php', 1432349800, 0), 
(135, 'module', 'news', 'modules/news/language/block.global.block_category_vi.php', 1432349800, 0), 
(136, 'module', 'news', 'modules/news/language/block.global.block_groups_en.php', 1432349800, 0), 
(137, 'module', 'news', 'modules/news/language/block.global.block_groups_vi.php', 1432349800, 0), 
(138, 'module', 'news', 'modules/news/language/block.global.block_news_cat_en.php', 1432349800, 0), 
(139, 'module', 'news', 'modules/news/language/block.global.block_news_cat_vi.php', 1432349800, 0), 
(140, 'module', 'news', 'modules/news/language/block.global.block_tophits_en.php', 1432349800, 0), 
(141, 'module', 'news', 'modules/news/language/block.global.block_tophits_vi.php', 1432349800, 0), 
(142, 'module', 'news', 'modules/news/language/block.module.block_headline_en.php', 1432349800, 0), 
(143, 'module', 'news', 'modules/news/language/block.module.block_headline_vi.php', 1432349800, 0), 
(144, 'module', 'news', 'modules/news/language/block.module.block_news_en.php', 1432349800, 0), 
(145, 'module', 'news', 'modules/news/language/block.module.block_news_vi.php', 1432349800, 0), 
(146, 'module', 'news', 'modules/news/language/block.module.block_newscenter_en.php', 1432349800, 0), 
(147, 'module', 'news', 'modules/news/language/block.module.block_newscenter_vi.php', 1432349800, 0), 
(148, 'module', 'news', 'modules/news/language/en.php', 1432349800, 0), 
(149, 'module', 'news', 'modules/news/language/index.html', 1432349800, 0), 
(150, 'module', 'news', 'modules/news/language/vi.php', 1432349800, 0), 
(151, 'module', 'news', 'modules/news/menu.php', 1432349800, 0), 
(152, 'module', 'news', 'modules/news/mobile/index.html', 1432349800, 0), 
(153, 'module', 'news', 'modules/news/rssdata.php', 1432349800, 0), 
(154, 'module', 'news', 'modules/news/search.php', 1432349800, 0), 
(155, 'module', 'news', 'modules/news/siteinfo.php', 1432349800, 0), 
(156, 'module', 'news', 'modules/news/theme.php', 1432349800, 0), 
(157, 'module', 'news', 'modules/news/version.php', 1432349800, 0), 
(158, 'module', 'news', 'themes/admin_default/modules/news/addtotopics.tpl', 1432349800, 0), 
(159, 'module', 'news', 'themes/admin_default/modules/news/block.tpl', 1432349800, 0), 
(160, 'module', 'news', 'themes/admin_default/modules/news/block_list.tpl', 1432349800, 0), 
(161, 'module', 'news', 'themes/admin_default/modules/news/blockcat_lists.tpl', 1432349800, 0), 
(162, 'module', 'news', 'themes/admin_default/modules/news/cat.tpl', 1432349800, 0), 
(163, 'module', 'news', 'themes/admin_default/modules/news/cat_list.tpl', 1432349800, 0), 
(164, 'module', 'news', 'themes/admin_default/modules/news/content.tpl', 1432349800, 0), 
(165, 'module', 'news', 'themes/admin_default/modules/news/del_cat.tpl', 1432349800, 0), 
(166, 'module', 'news', 'themes/admin_default/modules/news/groups.tpl', 1432349800, 0), 
(167, 'module', 'news', 'themes/admin_default/modules/news/index.html', 1432349800, 0), 
(168, 'module', 'news', 'themes/admin_default/modules/news/main.tpl', 1432349800, 0), 
(169, 'module', 'news', 'themes/admin_default/modules/news/redriect.tpl', 1432349800, 0), 
(170, 'module', 'news', 'themes/admin_default/modules/news/settings.tpl', 1432349800, 0), 
(171, 'module', 'news', 'themes/admin_default/modules/news/sources.tpl', 1432349800, 0), 
(172, 'module', 'news', 'themes/admin_default/modules/news/sources_list.tpl', 1432349800, 0), 
(173, 'module', 'news', 'themes/admin_default/modules/news/tags.tpl', 1432349800, 0), 
(174, 'module', 'news', 'themes/admin_default/modules/news/tags_lists.tpl', 1432349800, 0), 
(175, 'module', 'news', 'themes/admin_default/modules/news/tools.tpl', 1432349800, 0), 
(176, 'module', 'news', 'themes/admin_default/modules/news/topics.tpl', 1432349800, 0), 
(177, 'module', 'news', 'themes/admin_default/modules/news/topics_list.tpl', 1432349800, 0), 
(178, 'module', 'news', 'themes/admin_default/modules/news/topicsnews.tpl', 1432349800, 0), 
(179, 'module', 'news', 'themes/default/images/news/index.html', 1432349800, 0), 
(180, 'module', 'news', 'themes/default/images/news/new.gif', 1432349800, 0), 
(181, 'module', 'news', 'themes/default/modules/news/block_category.tpl', 1432349800, 0), 
(182, 'module', 'news', 'themes/default/modules/news/block_content.tpl', 1432349800, 0), 
(183, 'module', 'news', 'themes/default/modules/news/block_groups.tpl', 1432349800, 0), 
(184, 'module', 'news', 'themes/default/modules/news/block_headline.tpl', 1432349800, 0), 
(185, 'module', 'news', 'themes/default/modules/news/block_news.tpl', 1432349800, 0), 
(186, 'module', 'news', 'themes/default/modules/news/block_newscenter.tpl', 1432349800, 0), 
(187, 'module', 'news', 'themes/default/modules/news/content.tpl', 1432349800, 0), 
(188, 'module', 'news', 'themes/default/modules/news/detail.tpl', 1432349800, 0), 
(189, 'module', 'news', 'themes/default/modules/news/index.html', 1432349800, 0), 
(190, 'module', 'news', 'themes/default/modules/news/print.tpl', 1432349800, 0), 
(191, 'module', 'news', 'themes/default/modules/news/search.tpl', 1432349800, 0), 
(192, 'module', 'news', 'themes/default/modules/news/sendmail.tpl', 1432349800, 0), 
(193, 'module', 'news', 'themes/default/modules/news/topic.tpl', 1432349800, 0), 
(194, 'module', 'news', 'themes/default/modules/news/viewcat_grid.tpl', 1432349800, 0), 
(195, 'module', 'news', 'themes/default/modules/news/viewcat_list.tpl', 1432349800, 0), 
(196, 'module', 'news', 'themes/default/modules/news/viewcat_main_bottom.tpl', 1432349800, 0), 
(197, 'module', 'news', 'themes/default/modules/news/viewcat_main_left.tpl', 1432349800, 0), 
(198, 'module', 'news', 'themes/default/modules/news/viewcat_main_right.tpl', 1432349800, 0), 
(199, 'module', 'news', 'themes/default/modules/news/viewcat_page.tpl', 1432349800, 0), 
(200, 'module', 'news', 'themes/default/modules/news/viewcat_top.tpl', 1432349800, 0), 
(201, 'module', 'news', 'themes/default/modules/news/viewcat_two_column.tpl', 1432349800, 0), 
(202, 'module', 'news', 'themes/modern/images/news/index.html', 1432349800, 0), 
(203, 'module', 'news', 'themes/modern/images/news/new.gif', 1432349800, 0), 
(204, 'module', 'news', 'themes/modern/modules/news/block_category.tpl', 1432349800, 0), 
(205, 'module', 'news', 'themes/modern/modules/news/block_groups.tpl', 1432349800, 0), 
(206, 'module', 'news', 'themes/modern/modules/news/block_headline.tpl', 1432349800, 0), 
(207, 'module', 'news', 'themes/modern/modules/news/block_news.tpl', 1432349800, 0), 
(208, 'module', 'news', 'themes/modern/modules/news/block_newscenter.tpl', 1432349800, 0), 
(209, 'module', 'news', 'themes/modern/modules/news/block_newsright.tpl', 1432349800, 0), 
(210, 'module', 'news', 'themes/modern/modules/news/content.tpl', 1432349800, 0), 
(211, 'module', 'news', 'themes/modern/modules/news/detail.tpl', 1432349800, 0), 
(212, 'module', 'news', 'themes/modern/modules/news/index.html', 1432349800, 0), 
(213, 'module', 'news', 'themes/modern/modules/news/print.tpl', 1432349800, 0), 
(214, 'module', 'news', 'themes/modern/modules/news/search.tpl', 1432349800, 0), 
(215, 'module', 'news', 'themes/modern/modules/news/sendmail.tpl', 1432349800, 0), 
(216, 'module', 'news', 'themes/modern/modules/news/theme.php', 1432349800, 0), 
(217, 'module', 'news', 'themes/modern/modules/news/topic.tpl', 1432349800, 0), 
(218, 'module', 'news', 'themes/modern/modules/news/viewcat_grid.tpl', 1432349800, 0), 
(219, 'module', 'news', 'themes/modern/modules/news/viewcat_list.tpl', 1432349800, 0), 
(220, 'module', 'news', 'themes/modern/modules/news/viewcat_main_bottom.tpl', 1432349800, 0), 
(221, 'module', 'news', 'themes/modern/modules/news/viewcat_main_left.tpl', 1432349800, 0), 
(222, 'module', 'news', 'themes/modern/modules/news/viewcat_main_right.tpl', 1432349800, 0), 
(223, 'module', 'news', 'themes/modern/modules/news/viewcat_page.tpl', 1432349800, 0), 
(224, 'module', 'news', 'themes/modern/modules/news/viewcat_top.tpl', 1432349800, 0), 
(225, 'module', 'news', 'themes/modern/modules/news/viewcat_two_column.tpl', 1432349800, 0), 
(226, 'module', 'news', 'themes/mobile_nukeviet/images/news/email.png', 1432349800, 0), 
(227, 'module', 'news', 'themes/mobile_nukeviet/images/news/index.html', 1432349800, 0), 
(228, 'module', 'news', 'themes/mobile_nukeviet/images/news/new.gif', 1432349800, 0), 
(229, 'module', 'news', 'themes/mobile_nukeviet/images/news/print.png', 1432349800, 0), 
(230, 'module', 'news', 'themes/mobile_nukeviet/images/news/save.png', 1432349800, 0), 
(231, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_blocknews.tpl', 1432349800, 0), 
(232, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_category.tpl', 1432349800, 0), 
(233, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_content.tpl', 1432349800, 0), 
(234, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_headline.tpl', 1432349800, 0), 
(235, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_news.tpl', 1432349800, 0), 
(236, 'module', 'news', 'themes/mobile_nukeviet/modules/news/block_newscenter.tpl', 1432349800, 0), 
(237, 'module', 'news', 'themes/mobile_nukeviet/modules/news/content.tpl', 1432349800, 0), 
(238, 'module', 'news', 'themes/mobile_nukeviet/modules/news/detail.tpl', 1432349800, 0), 
(239, 'module', 'news', 'themes/mobile_nukeviet/modules/news/index.html', 1432349800, 0), 
(240, 'module', 'news', 'themes/mobile_nukeviet/modules/news/print.tpl', 1432349800, 0), 
(241, 'module', 'news', 'themes/mobile_nukeviet/modules/news/search.tpl', 1432349800, 0), 
(242, 'module', 'news', 'themes/mobile_nukeviet/modules/news/sendmail.tpl', 1432349800, 0), 
(243, 'module', 'news', 'themes/mobile_nukeviet/modules/news/theme.php', 1432349800, 0), 
(244, 'module', 'news', 'themes/mobile_nukeviet/modules/news/topic.tpl', 1432349800, 0), 
(245, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_grid.tpl', 1432349800, 0), 
(246, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_list.tpl', 1432349800, 0), 
(247, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_main_bottom.tpl', 1432349800, 0), 
(248, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_page.tpl', 1432349800, 0), 
(249, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_top.tpl', 1432349800, 0), 
(250, 'module', 'news', 'themes/mobile_nukeviet/modules/news/viewcat_two_column.tpl', 1432349800, 0), 
(251, 'module', 'news', 'themes/admin_default/css/news.css', 1432349800, 0), 
(252, 'module', 'news', 'themes/default/css/news.css', 1432349800, 0), 
(253, 'module', 'news', 'themes/modern/css/news.css', 1432349800, 0), 
(254, 'module', 'voting', 'modules/voting/action_mysql.php', 1432349800, 0), 
(255, 'module', 'voting', 'modules/voting/action_oci.php', 1432349800, 0), 
(256, 'module', 'voting', 'modules/voting/admin/content.php', 1432349800, 0), 
(257, 'module', 'voting', 'modules/voting/admin/del.php', 1432349800, 0), 
(258, 'module', 'voting', 'modules/voting/admin/index.html', 1432349800, 0), 
(259, 'module', 'voting', 'modules/voting/admin/main.php', 1432349800, 0), 
(260, 'module', 'voting', 'modules/voting/admin.functions.php', 1432349800, 0), 
(261, 'module', 'voting', 'modules/voting/admin.menu.php', 1432349800, 0), 
(262, 'module', 'voting', 'modules/voting/blocks/global.voting.ini', 1432349800, 0), 
(263, 'module', 'voting', 'modules/voting/blocks/global.voting.php', 1432349800, 0), 
(264, 'module', 'voting', 'modules/voting/blocks/global.voting_random.php', 1432349800, 0), 
(265, 'module', 'voting', 'modules/voting/blocks/index.html', 1432349800, 0), 
(266, 'module', 'voting', 'modules/voting/funcs/index.html', 1432349800, 0), 
(267, 'module', 'voting', 'modules/voting/funcs/main.php', 1432349800, 0), 
(268, 'module', 'voting', 'modules/voting/functions.php', 1432349800, 0), 
(269, 'module', 'voting', 'modules/voting/index.html', 1432349800, 0), 
(270, 'module', 'voting', 'modules/voting/js/admin.js', 1432349800, 0), 
(271, 'module', 'voting', 'modules/voting/js/index.html', 1432349800, 0), 
(272, 'module', 'voting', 'modules/voting/js/user.js', 1432349800, 0), 
(273, 'module', 'voting', 'modules/voting/language/admin_en.php', 1432349800, 0), 
(274, 'module', 'voting', 'modules/voting/language/admin_vi.php', 1432349800, 0), 
(275, 'module', 'voting', 'modules/voting/language/en.php', 1432349800, 0), 
(276, 'module', 'voting', 'modules/voting/language/index.html', 1432349800, 0), 
(277, 'module', 'voting', 'modules/voting/language/vi.php', 1432349800, 0), 
(278, 'module', 'voting', 'modules/voting/theme.php', 1432349800, 0), 
(279, 'module', 'voting', 'modules/voting/version.php', 1432349800, 0), 
(280, 'module', 'voting', 'themes/admin_default/modules/voting/content.tpl', 1432349800, 0), 
(281, 'module', 'voting', 'themes/admin_default/modules/voting/index.html', 1432349800, 0), 
(282, 'module', 'voting', 'themes/admin_default/modules/voting/main.tpl', 1432349800, 0), 
(283, 'module', 'voting', 'themes/default/modules/voting/global.voting.tpl', 1432349800, 0), 
(284, 'module', 'voting', 'themes/default/modules/voting/index.html', 1432349800, 0), 
(285, 'module', 'voting', 'themes/default/modules/voting/main.tpl', 1432349800, 0), 
(286, 'module', 'voting', 'themes/default/modules/voting/result.voting.tpl', 1432349800, 0), 
(287, 'module', 'voting', 'themes/modern/modules/voting/global.voting.tpl', 1432349800, 0), 
(288, 'module', 'voting', 'themes/modern/modules/voting/index.html', 1432349800, 0), 
(289, 'module', 'voting', 'themes/modern/modules/voting/main.tpl', 1432349800, 0), 
(290, 'module', 'voting', 'themes/modern/modules/voting/result.voting.tpl', 1432349800, 0), 
(291, 'module', 'voting', 'themes/admin_default/css/voting.css', 1432349800, 0), 
(292, 'module', 'download', 'modules/download/action_mysql.php', 1432349800, 0), 
(293, 'module', 'download', 'modules/download/action_oci.php', 1432349800, 0), 
(294, 'module', 'download', 'modules/download/admin/add.php', 1432349800, 0), 
(295, 'module', 'download', 'modules/download/admin/cat.php', 1432349800, 0), 
(296, 'module', 'download', 'modules/download/admin/config.php', 1432349800, 0), 
(297, 'module', 'download', 'modules/download/admin/filequeue.php', 1432349800, 0), 
(298, 'module', 'download', 'modules/download/admin/index.html', 1432349800, 0), 
(299, 'module', 'download', 'modules/download/admin/main.php', 1432349800, 0), 
(300, 'module', 'download', 'modules/download/admin/report.php', 1432349800, 0), 
(301, 'module', 'download', 'modules/download/admin/view.php', 1432349800, 0), 
(302, 'module', 'download', 'modules/download/admin.functions.php', 1432349800, 0), 
(303, 'module', 'download', 'modules/download/admin.menu.php', 1432349800, 0), 
(304, 'module', 'download', 'modules/download/blocks/global.new_files.ini', 1432349800, 0), 
(305, 'module', 'download', 'modules/download/blocks/global.new_files.php', 1432349800, 0), 
(306, 'module', 'download', 'modules/download/blocks/global.search.php', 1432349800, 0), 
(307, 'module', 'download', 'modules/download/blocks/global.upload.php', 1432349800, 0), 
(308, 'module', 'download', 'modules/download/blocks/index.html', 1432349800, 0), 
(309, 'module', 'download', 'modules/download/blocks/module.block_category.php', 1432349800, 0), 
(310, 'module', 'download', 'modules/download/blocks/module.block_lastestdownload.php', 1432349800, 0), 
(311, 'module', 'download', 'modules/download/blocks/module.block_topdownload.php', 1432349800, 0), 
(312, 'module', 'download', 'modules/download/comment.php', 1432349800, 0), 
(313, 'module', 'download', 'modules/download/funcs/down.php', 1432349800, 0), 
(314, 'module', 'download', 'modules/download/funcs/index.html', 1432349800, 0), 
(315, 'module', 'download', 'modules/download/funcs/main.php', 1432349800, 0), 
(316, 'module', 'download', 'modules/download/funcs/report.php', 1432349800, 0), 
(317, 'module', 'download', 'modules/download/funcs/rss.php', 1432349800, 0), 
(318, 'module', 'download', 'modules/download/funcs/search.php', 1432349800, 0), 
(319, 'module', 'download', 'modules/download/funcs/sitemap.php', 1432349800, 0), 
(320, 'module', 'download', 'modules/download/funcs/upload.php', 1432349800, 0), 
(321, 'module', 'download', 'modules/download/funcs/viewcat.php', 1432349800, 0), 
(322, 'module', 'download', 'modules/download/funcs/viewfile.php', 1432349800, 0), 
(323, 'module', 'download', 'modules/download/functions.php', 1432349800, 0), 
(324, 'module', 'download', 'modules/download/index.html', 1432349800, 0), 
(325, 'module', 'download', 'modules/download/js/admin.js', 1432349800, 0), 
(326, 'module', 'download', 'modules/download/js/index.html', 1432349800, 0), 
(327, 'module', 'download', 'modules/download/js/user.js', 1432349800, 0), 
(328, 'module', 'download', 'modules/download/language/admin_en.php', 1432349800, 0), 
(329, 'module', 'download', 'modules/download/language/admin_vi.php', 1432349800, 0), 
(330, 'module', 'download', 'modules/download/language/block.global.new_files_en.php', 1432349800, 0), 
(331, 'module', 'download', 'modules/download/language/block.global.new_files_vi.php', 1432349800, 0), 
(332, 'module', 'download', 'modules/download/language/en.php', 1432349800, 0), 
(333, 'module', 'download', 'modules/download/language/index.html', 1432349800, 0), 
(334, 'module', 'download', 'modules/download/language/vi.php', 1432349800, 0), 
(335, 'module', 'download', 'modules/download/menu.php', 1432349800, 0), 
(336, 'module', 'download', 'modules/download/rssdata.php', 1432349800, 0), 
(337, 'module', 'download', 'modules/download/search.php', 1432349800, 0), 
(338, 'module', 'download', 'modules/download/siteinfo.php', 1432349800, 0), 
(339, 'module', 'download', 'modules/download/theme.php', 1432349800, 0), 
(340, 'module', 'download', 'modules/download/version.php', 1432349800, 0), 
(341, 'module', 'download', 'themes/admin_default/modules/download/cat_add.tpl', 1432349800, 0), 
(342, 'module', 'download', 'themes/admin_default/modules/download/cat_list.tpl', 1432349800, 0), 
(343, 'module', 'download', 'themes/admin_default/modules/download/config.tpl', 1432349800, 0), 
(344, 'module', 'download', 'themes/admin_default/modules/download/content.tpl', 1432349800, 0), 
(345, 'module', 'download', 'themes/admin_default/modules/download/filequeue.tpl', 1432349800, 0), 
(346, 'module', 'download', 'themes/admin_default/modules/download/filequeue_edit.tpl', 1432349800, 0), 
(347, 'module', 'download', 'themes/admin_default/modules/download/index.html', 1432349800, 0), 
(348, 'module', 'download', 'themes/admin_default/modules/download/main.tpl', 1432349800, 0), 
(349, 'module', 'download', 'themes/admin_default/modules/download/report.tpl', 1432349800, 0), 
(350, 'module', 'download', 'themes/default/images/download/report.gif', 1432349800, 0), 
(351, 'module', 'download', 'themes/default/modules/download/block.tpl', 1432349800, 0), 
(352, 'module', 'download', 'themes/default/modules/download/block_category.tpl', 1432349800, 0), 
(353, 'module', 'download', 'themes/default/modules/download/block_lastestdownload.tpl', 1432349800, 0), 
(354, 'module', 'download', 'themes/default/modules/download/block_new_files.tpl', 1432349800, 0), 
(355, 'module', 'download', 'themes/default/modules/download/block_search.tpl', 1432349800, 0), 
(356, 'module', 'download', 'themes/default/modules/download/block_topdownload.tpl', 1432349800, 0), 
(357, 'module', 'download', 'themes/default/modules/download/block_upload.tpl', 1432349800, 0), 
(358, 'module', 'download', 'themes/default/modules/download/index.html', 1432349800, 0), 
(359, 'module', 'download', 'themes/default/modules/download/main_page.tpl', 1432349800, 0), 
(360, 'module', 'download', 'themes/default/modules/download/upload.tpl', 1432349800, 0), 
(361, 'module', 'download', 'themes/default/modules/download/viewcat_page.tpl', 1432349800, 0), 
(362, 'module', 'download', 'themes/default/modules/download/viewfile.tpl', 1432349800, 0), 
(363, 'module', 'download', 'themes/modern/images/download/arr_black.png', 1432349800, 0), 
(364, 'module', 'download', 'themes/modern/images/download/arr_red.png', 1432349800, 0), 
(365, 'module', 'download', 'themes/modern/images/download/arr_right.gif', 1432349800, 0), 
(366, 'module', 'download', 'themes/modern/images/download/bt_gradient.png', 1432349800, 0), 
(367, 'module', 'download', 'themes/modern/images/download/bullet_star.png', 1432349800, 0), 
(368, 'module', 'download', 'themes/modern/images/download/comment.gif', 1432349800, 0), 
(369, 'module', 'download', 'themes/modern/images/download/comment.png', 1432349800, 0), 
(370, 'module', 'download', 'themes/modern/images/download/comment_outline.png', 1432349800, 0), 
(371, 'module', 'download', 'themes/modern/images/download/dl-icon.png', 1432349800, 0), 
(372, 'module', 'download', 'themes/modern/images/download/dot.gif', 1432349800, 0), 
(373, 'module', 'download', 'themes/modern/images/download/down.gif', 1432349800, 0), 
(374, 'module', 'download', 'themes/modern/images/download/down.png', 1432349800, 0), 
(375, 'module', 'download', 'themes/modern/images/download/down_outline.png', 1432349800, 0), 
(376, 'module', 'download', 'themes/modern/images/download/download.gif', 1432349800, 0), 
(377, 'module', 'download', 'themes/modern/images/download/download.png', 1432349800, 0), 
(378, 'module', 'download', 'themes/modern/images/download/download2.gif', 1432349800, 0), 
(379, 'module', 'download', 'themes/modern/images/download/folder-icon.png', 1432349800, 0), 
(380, 'module', 'download', 'themes/modern/images/download/folder.gif', 1432349800, 0), 
(381, 'module', 'download', 'themes/modern/images/download/header-bg.png', 1432349800, 0), 
(382, 'module', 'download', 'themes/modern/images/download/index.html', 1432349800, 0), 
(383, 'module', 'download', 'themes/modern/images/download/info.gif', 1432349800, 0), 
(384, 'module', 'download', 'themes/modern/images/download/lt_top_bg.png', 1432349800, 0), 
(385, 'module', 'download', 'themes/modern/images/download/report.gif', 1432349800, 0), 
(386, 'module', 'download', 'themes/modern/images/download/s-icon.png', 1432349800, 0), 
(387, 'module', 'download', 'themes/modern/images/download/spector.png', 1432349800, 0), 
(388, 'module', 'download', 'themes/modern/images/download/thumb.png', 1432349800, 0), 
(389, 'module', 'download', 'themes/modern/images/download/thumb2.png', 1432349800, 0), 
(390, 'module', 'download', 'themes/modern/images/download/thumb3.png', 1432349800, 0), 
(391, 'module', 'download', 'themes/modern/images/download/up-icon.png', 1432349800, 0), 
(392, 'module', 'download', 'themes/modern/images/download/up_bg.png', 1432349800, 0), 
(393, 'module', 'download', 'themes/modern/images/download/upload.gif', 1432349800, 0), 
(394, 'module', 'download', 'themes/modern/images/download/url.gif', 1432349800, 0), 
(395, 'module', 'download', 'themes/modern/modules/download/block.tpl', 1432349800, 0), 
(396, 'module', 'download', 'themes/modern/modules/download/block_category.tpl', 1432349800, 0), 
(397, 'module', 'download', 'themes/modern/modules/download/block_lastestdownload.tpl', 1432349800, 0), 
(398, 'module', 'download', 'themes/modern/modules/download/block_search.tpl', 1432349800, 0), 
(399, 'module', 'download', 'themes/modern/modules/download/block_topdownload.tpl', 1432349800, 0), 
(400, 'module', 'download', 'themes/modern/modules/download/block_upload.tpl', 1432349800, 0), 
(401, 'module', 'download', 'themes/modern/modules/download/index.html', 1432349800, 0), 
(402, 'module', 'download', 'themes/modern/modules/download/main_page.tpl', 1432349800, 0), 
(403, 'module', 'download', 'themes/modern/modules/download/upload.tpl', 1432349800, 0), 
(404, 'module', 'download', 'themes/modern/modules/download/viewcat_page.tpl', 1432349800, 0), 
(405, 'module', 'download', 'themes/modern/modules/download/viewfile.tpl', 1432349800, 0), 
(406, 'module', 'download', 'themes/admin_default/css/download.css', 1432349800, 0), 
(407, 'module', 'download', 'themes/default/css/download.css', 1432349800, 0), 
(408, 'module', 'download', 'themes/modern/css/download.css', 1432349800, 0), 
(409, 'module', 'statistics', 'modules/statistics/blocks/global.counter.php', 1432349800, 0), 
(410, 'module', 'statistics', 'modules/statistics/blocks/index.html', 1432349800, 0), 
(411, 'module', 'statistics', 'modules/statistics/funcs/allbots.php', 1432349800, 0), 
(412, 'module', 'statistics', 'modules/statistics/funcs/allbrowsers.php', 1432349800, 0), 
(413, 'module', 'statistics', 'modules/statistics/funcs/allcountries.php', 1432349800, 0), 
(414, 'module', 'statistics', 'modules/statistics/funcs/allos.php', 1432349800, 0), 
(415, 'module', 'statistics', 'modules/statistics/funcs/allreferers.php', 1432349800, 0), 
(416, 'module', 'statistics', 'modules/statistics/funcs/index.html', 1432349800, 0), 
(417, 'module', 'statistics', 'modules/statistics/funcs/main.php', 1432349800, 0), 
(418, 'module', 'statistics', 'modules/statistics/funcs/referer.php', 1432349800, 0), 
(419, 'module', 'statistics', 'modules/statistics/functions.php', 1432349800, 0), 
(420, 'module', 'statistics', 'modules/statistics/index.html', 1432349800, 0), 
(421, 'module', 'statistics', 'modules/statistics/language/en.php', 1432349800, 0), 
(422, 'module', 'statistics', 'modules/statistics/language/index.html', 1432349800, 0), 
(423, 'module', 'statistics', 'modules/statistics/language/vi.php', 1432349800, 0), 
(424, 'module', 'statistics', 'modules/statistics/theme.php', 1432349800, 0), 
(425, 'module', 'statistics', 'modules/statistics/version.php', 1432349800, 0), 
(426, 'module', 'statistics', 'themes/default/images/statistics/bg.gif', 1432349800, 0), 
(427, 'module', 'statistics', 'themes/default/images/statistics/bg2.gif', 1432349800, 0), 
(428, 'module', 'statistics', 'themes/default/images/statistics/index.html', 1432349800, 0), 
(429, 'module', 'statistics', 'themes/default/modules/statistics/allbots.tpl', 1432349800, 0), 
(430, 'module', 'statistics', 'themes/default/modules/statistics/allbrowsers.tpl', 1432349800, 0), 
(431, 'module', 'statistics', 'themes/default/modules/statistics/allcountries.tpl', 1432349800, 0), 
(432, 'module', 'statistics', 'themes/default/modules/statistics/allos.tpl', 1432349800, 0), 
(433, 'module', 'statistics', 'themes/default/modules/statistics/allreferers.tpl', 1432349800, 0), 
(434, 'module', 'statistics', 'themes/default/modules/statistics/index.html', 1432349800, 0), 
(435, 'module', 'statistics', 'themes/default/modules/statistics/main.tpl', 1432349800, 0), 
(436, 'module', 'statistics', 'themes/default/modules/statistics/referer.tpl', 1432349800, 0), 
(437, 'module', 'statistics', 'themes/modern/images/statistics/bg.gif', 1432349800, 0), 
(438, 'module', 'statistics', 'themes/modern/images/statistics/bg2.gif', 1432349800, 0), 
(439, 'module', 'statistics', 'themes/modern/images/statistics/index.html', 1432349800, 0), 
(440, 'module', 'statistics', 'themes/default/css/statistics.css', 1432349800, 0), 
(441, 'module', 'menu', 'modules/menu/action_mysql.php', 1432349800, 0), 
(442, 'module', 'menu', 'modules/menu/action_oci.php', 1432349800, 0), 
(443, 'module', 'menu', 'modules/menu/admin/change_weight_row.php', 1432349800, 0), 
(444, 'module', 'menu', 'modules/menu/admin/del_row.php', 1432349800, 0), 
(445, 'module', 'menu', 'modules/menu/admin/index.html', 1432349800, 0), 
(446, 'module', 'menu', 'modules/menu/admin/link_menu.php', 1432349800, 0), 
(447, 'module', 'menu', 'modules/menu/admin/link_module.php', 1432349800, 0), 
(448, 'module', 'menu', 'modules/menu/admin/main.php', 1432349800, 0), 
(449, 'module', 'menu', 'modules/menu/admin/menu.php', 1432349800, 0), 
(450, 'module', 'menu', 'modules/menu/admin/rows.php', 1432349800, 0), 
(451, 'module', 'menu', 'modules/menu/admin.functions.php', 1432349800, 0), 
(452, 'module', 'menu', 'modules/menu/admin.menu.php', 1432349800, 0), 
(453, 'module', 'menu', 'modules/menu/blocks/global.bootstrap.ini', 1432349800, 0), 
(454, 'module', 'menu', 'modules/menu/blocks/global.bootstrap.php', 1432349800, 0), 
(455, 'module', 'menu', 'modules/menu/blocks/global.metismenu.ini', 1432349800, 0), 
(456, 'module', 'menu', 'modules/menu/blocks/global.metismenu.php', 1432349800, 0), 
(457, 'module', 'menu', 'modules/menu/blocks/global.site_mods.ini', 1432349800, 0), 
(458, 'module', 'menu', 'modules/menu/blocks/global.site_mods.php', 1432349800, 0), 
(459, 'module', 'menu', 'modules/menu/blocks/global.slimmenu.ini', 1432349800, 0), 
(460, 'module', 'menu', 'modules/menu/blocks/global.slimmenu.php', 1432349800, 0), 
(461, 'module', 'menu', 'modules/menu/blocks/global.superfish.ini', 1432349800, 0), 
(462, 'module', 'menu', 'modules/menu/blocks/global.superfish.php', 1432349800, 0), 
(463, 'module', 'menu', 'modules/menu/blocks/global.treeview.ini', 1432349800, 0), 
(464, 'module', 'menu', 'modules/menu/blocks/global.treeview.php', 1432349800, 0), 
(465, 'module', 'menu', 'modules/menu/blocks/global.vertical_system.ini', 1432349800, 0), 
(466, 'module', 'menu', 'modules/menu/blocks/global.vertical_system.php', 1432349800, 0), 
(467, 'module', 'menu', 'modules/menu/blocks/index.html', 1432349800, 0), 
(468, 'module', 'menu', 'modules/menu/funcs/index.html', 1432349800, 0), 
(469, 'module', 'menu', 'modules/menu/funcs/main.php', 1432349800, 0), 
(470, 'module', 'menu', 'modules/menu/functions.php', 1432349800, 0), 
(471, 'module', 'menu', 'modules/menu/index.html', 1432349800, 0), 
(472, 'module', 'menu', 'modules/menu/js/admin.js', 1432349800, 0), 
(473, 'module', 'menu', 'modules/menu/js/index.html', 1432349800, 0), 
(474, 'module', 'menu', 'modules/menu/language/admin_en.php', 1432349800, 0), 
(475, 'module', 'menu', 'modules/menu/language/admin_vi.php', 1432349800, 0), 
(476, 'module', 'menu', 'modules/menu/language/block.config_en.php', 1432349800, 0), 
(477, 'module', 'menu', 'modules/menu/language/block.config_vi.php', 1432349800, 0), 
(478, 'module', 'menu', 'modules/menu/language/index.html', 1432349800, 0), 
(479, 'module', 'menu', 'modules/menu/menu_blocks.php', 1432349800, 0), 
(480, 'module', 'menu', 'modules/menu/menu_config.php', 1432349800, 0), 
(481, 'module', 'menu', 'modules/menu/version.php', 1432349800, 0), 
(482, 'module', 'menu', 'themes/admin_default/modules/menu/index.html', 1432349800, 0), 
(483, 'module', 'menu', 'themes/admin_default/modules/menu/main.tpl', 1432349800, 0), 
(484, 'module', 'menu', 'themes/admin_default/modules/menu/menu.tpl', 1432349800, 0), 
(485, 'module', 'menu', 'themes/admin_default/modules/menu/rows.tpl', 1432349800, 0), 
(486, 'module', 'menu', 'themes/default/modules/menu/global.bootstrap.tpl', 1432349800, 0), 
(487, 'module', 'menu', 'themes/default/modules/menu/global.metismenu.tpl', 1432349800, 0), 
(488, 'module', 'menu', 'themes/default/modules/menu/global.slimmenu.tpl', 1432349800, 0), 
(489, 'module', 'menu', 'themes/default/modules/menu/global.superfish.tpl', 1432349800, 0), 
(490, 'module', 'menu', 'themes/default/modules/menu/global.treeview.tpl', 1432349800, 0), 
(491, 'module', 'menu', 'themes/default/modules/menu/index.html', 1432349800, 0), 
(492, 'module', 'menu', 'themes/modern/modules/menu/global.superfish.tpl', 1432349800, 0), 
(493, 'module', 'menu', 'themes/modern/modules/menu/index.html', 1432349800, 0), 
(494, 'module', 'menu', 'themes/default/css/menu.css', 1432349800, 0), 
(495, 'module', 'nvtools', 'modules/nvtools/funcs/.htaccess', 1432784898, 0), 
(496, 'module', 'nvtools', 'modules/nvtools/funcs/addfun.php', 1432784898, 0), 
(497, 'module', 'nvtools', 'modules/nvtools/funcs/checktable.php', 1432784898, 0), 
(498, 'module', 'nvtools', 'modules/nvtools/funcs/data.php', 1432784898, 0), 
(499, 'module', 'nvtools', 'modules/nvtools/funcs/index.html', 1432784898, 0), 
(500, 'module', 'nvtools', 'modules/nvtools/funcs/main.php', 1432784898, 0), 
(501, 'module', 'nvtools', 'modules/nvtools/funcs/theme.php', 1432784898, 0), 
(502, 'module', 'nvtools', 'modules/nvtools/functions.php', 1432784898, 0), 
(503, 'module', 'nvtools', 'modules/nvtools/index.html', 1432784898, 0), 
(504, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/colorpicker.js', 1432784898, 0), 
(505, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/css/colorpicker.css', 1432784898, 0), 
(506, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/css/index.html', 1432784898, 0), 
(507, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/blank.gif', 1432784898, 0), 
(508, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_background.png', 1432784898, 0), 
(509, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_hex.png', 1432784898, 0), 
(510, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_hsb_b.png', 1432784898, 0), 
(511, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_hsb_h.png', 1432784898, 0), 
(512, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_hsb_s.png', 1432784898, 0), 
(513, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_indic.gif', 1432784898, 0), 
(514, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_overlay.png', 1432784898, 0), 
(515, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_rgb_b.png', 1432784898, 0), 
(516, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_rgb_g.png', 1432784898, 0), 
(517, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_rgb_r.png', 1432784898, 0), 
(518, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_select.gif', 1432784898, 0), 
(519, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/colorpicker_submit.png', 1432784898, 0), 
(520, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_background.png', 1432784898, 0), 
(521, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_hex.png', 1432784898, 0), 
(522, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_hsb_b.png', 1432784898, 0), 
(523, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_hsb_h.png', 1432784898, 0), 
(524, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_hsb_s.png', 1432784898, 0), 
(525, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_indic.gif', 1432784898, 0), 
(526, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_rgb_b.png', 1432784898, 0), 
(527, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_rgb_g.png', 1432784898, 0), 
(528, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_rgb_r.png', 1432784898, 0), 
(529, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/custom_submit.png', 1432784898, 0), 
(530, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/index.html', 1432784898, 0), 
(531, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/select.png', 1432784898, 0), 
(532, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/select2.png', 1432784898, 0), 
(533, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/images/slider.png', 1432784898, 0), 
(534, 'module', 'nvtools', 'modules/nvtools/js/colorpicker/index.html', 1432784898, 0), 
(535, 'module', 'nvtools', 'modules/nvtools/js/index.html', 1432784898, 0), 
(536, 'module', 'nvtools', 'modules/nvtools/js/user.js', 1432784898, 0), 
(537, 'module', 'nvtools', 'modules/nvtools/language/.htaccess', 1432784898, 0), 
(538, 'module', 'nvtools', 'modules/nvtools/language/index.html', 1432784898, 0), 
(539, 'module', 'nvtools', 'modules/nvtools/language/vi.php', 1432784898, 0), 
(540, 'module', 'nvtools', 'modules/nvtools/modules/index.html', 1432784898, 0), 
(541, 'module', 'nvtools', 'modules/nvtools/modules/rss.tpl', 1432784898, 0), 
(542, 'module', 'nvtools', 'modules/nvtools/modules/rssdata.tpl', 1432784898, 0), 
(543, 'module', 'nvtools', 'modules/nvtools/modules/search.tpl', 1432784898, 0), 
(544, 'module', 'nvtools', 'modules/nvtools/modules/siteinfo.tpl', 1432784898, 0), 
(545, 'module', 'nvtools', 'modules/nvtools/modules/Sitemap.tpl', 1432784898, 0), 
(546, 'module', 'nvtools', 'modules/nvtools/theme/.htaccess', 1432784898, 0), 
(547, 'module', 'nvtools', 'modules/nvtools/theme/blocks/.htaccess', 1432784898, 0), 
(548, 'module', 'nvtools', 'modules/nvtools/theme/blocks/global.banners.tpl', 1432784898, 0), 
(549, 'module', 'nvtools', 'modules/nvtools/theme/blocks/global.rss.tpl', 1432784898, 0), 
(550, 'module', 'nvtools', 'modules/nvtools/theme/blocks/index.html', 1432784898, 0), 
(551, 'module', 'nvtools', 'modules/nvtools/theme/config.tpl', 1432784898, 0), 
(552, 'module', 'nvtools', 'modules/nvtools/theme/css/admin.css', 1432784898, 0), 
(553, 'module', 'nvtools', 'modules/nvtools/theme/css/ie6.css', 1432784898, 0), 
(554, 'module', 'nvtools', 'modules/nvtools/theme/css/index.html', 1432784898, 0), 
(555, 'module', 'nvtools', 'modules/nvtools/theme/css/reset_eric.css', 1432784898, 0), 
(556, 'module', 'nvtools', 'modules/nvtools/theme/css/reset_yahoo.css', 1432784898, 0), 
(557, 'module', 'nvtools', 'modules/nvtools/theme/css/screen.css', 1432784898, 0), 
(558, 'module', 'nvtools', 'modules/nvtools/theme/css/screen.equal.css', 1432784898, 0), 
(559, 'module', 'nvtools', 'modules/nvtools/theme/css/screen.stick.css', 1432784898, 0), 
(560, 'module', 'nvtools', 'modules/nvtools/theme/css/tab_info.css', 1432784898, 0), 
(561, 'module', 'nvtools', 'modules/nvtools/theme/default.jpg', 1432784898, 0), 
(562, 'module', 'nvtools', 'modules/nvtools/theme/favicon.ico', 1432784898, 0), 
(563, 'module', 'nvtools', 'modules/nvtools/theme/images/admin/admin1.png', 1432784898, 0), 
(564, 'module', 'nvtools', 'modules/nvtools/theme/images/admin/admin2.png', 1432784898, 0), 
(565, 'module', 'nvtools', 'modules/nvtools/theme/images/admin/admin3.png', 1432784898, 0), 
(566, 'module', 'nvtools', 'modules/nvtools/theme/images/admin/admin_menu_bg.jpg', 1432784898, 0), 
(567, 'module', 'nvtools', 'modules/nvtools/theme/images/admin/bt03_l.png', 1432784898, 0), 
(568, 'module', 'nvtools', 'modules/nvtools/theme/images/admin/bt03_r.png', 1432784898, 0), 
(569, 'module', 'nvtools', 'modules/nvtools/theme/images/admin/button_bg.gif', 1432784898, 0), 
(570, 'module', 'nvtools', 'modules/nvtools/theme/images/admin/index.html', 1432784898, 0), 
(571, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow1_black.gif', 1432784898, 0), 
(572, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow1_green.gif', 1432784898, 0), 
(573, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow1_red.gif', 1432784898, 0), 
(574, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow2_black.gif', 1432784898, 0), 
(575, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow2_green.gif', 1432784898, 0), 
(576, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow2_red.gif', 1432784898, 0), 
(577, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow3_black.gif', 1432784898, 0), 
(578, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow3_green.gif', 1432784898, 0), 
(579, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow3_red.gif', 1432784898, 0), 
(580, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow4_black.gif', 1432784898, 0), 
(581, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow4_green.gif', 1432784898, 0), 
(582, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/arrow4_red.gif', 1432784898, 0), 
(583, 'module', 'nvtools', 'modules/nvtools/theme/images/arrows/index.html', 1432784898, 0), 
(584, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/add.png', 1432784898, 0), 
(585, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/bad.png', 1432784898, 0), 
(586, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/box_down.png', 1432784898, 0), 
(587, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/calendar.png', 1432784898, 0), 
(588, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/comment.png', 1432784898, 0), 
(589, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/database.png', 1432784898, 0), 
(590, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/default.png', 1432784898, 0), 
(591, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/delete.png', 1432784898, 0), 
(592, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/edit.png', 1432784898, 0), 
(593, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/good.png', 1432784898, 0), 
(594, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/group.png', 1432784898, 0), 
(595, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/home.png', 1432784898, 0), 
(596, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/icon-drag.png', 1432784898, 0), 
(597, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/index.html', 1432784898, 0), 
(598, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/lightbulb.png', 1432784898, 0), 
(599, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/link.png', 1432784898, 0), 
(600, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/logout.png', 1432784898, 0), 
(601, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/module.png', 1432784898, 0), 
(602, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/newspaper.png', 1432784898, 0), 
(603, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/page.png', 1432784898, 0), 
(604, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/refresh.png', 1432784898, 0), 
(605, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/search.png', 1432784898, 0), 
(606, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/sitemanager.gif', 1432784898, 0), 
(607, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/statistics.png', 1432784898, 0), 
(608, 'module', 'nvtools', 'modules/nvtools/theme/images/icons/warning.png', 1432784898, 0), 
(609, 'module', 'nvtools', 'modules/nvtools/theme/images/index.html', 1432784898, 0), 
(610, 'module', 'nvtools', 'modules/nvtools/theme/images/no_image.gif', 1432784898, 0), 
(611, 'module', 'nvtools', 'modules/nvtools/theme/index.html', 1432784898, 0), 
(612, 'module', 'nvtools', 'modules/nvtools/theme/layout/.htaccess', 1432784898, 0), 
(613, 'module', 'nvtools', 'modules/nvtools/theme/layout/block.default.tpl', 1432784898, 0), 
(614, 'module', 'nvtools', 'modules/nvtools/theme/layout/block.no_title.tpl', 1432784898, 0), 
(615, 'module', 'nvtools', 'modules/nvtools/theme/layout/index.html', 1432784898, 0), 
(616, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.body-left-right.tpl', 1432784898, 0), 
(617, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.body-right.tpl', 1432784898, 0), 
(618, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.body.tpl', 1432784898, 0), 
(619, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.equal.body-left-right.tpl', 1432784898, 0), 
(620, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.equal.body-right.tpl', 1432784898, 0), 
(621, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.equal.body.tpl', 1432784898, 0), 
(622, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.equal.left-body-right.tpl', 1432784898, 0), 
(623, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.equal.left-body.tpl', 1432784898, 0), 
(624, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.equal.left-right-body.tpl', 1432784898, 0), 
(625, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.left-body-right.tpl', 1432784898, 0), 
(626, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.left-body.tpl', 1432784898, 0), 
(627, 'module', 'nvtools', 'modules/nvtools/theme/layout/layout.left-right-body.tpl', 1432784898, 0), 
(628, 'module', 'nvtools', 'modules/nvtools/theme/system/.htaccess', 1432784898, 0), 
(629, 'module', 'nvtools', 'modules/nvtools/theme/system/error_info.tpl', 1432784898, 0), 
(630, 'module', 'nvtools', 'modules/nvtools/theme/system/flood_blocker.tpl', 1432784898, 0), 
(631, 'module', 'nvtools', 'modules/nvtools/theme/system/index.html', 1432784898, 0), 
(632, 'module', 'nvtools', 'modules/nvtools/theme/system/info_die.tpl', 1432784898, 0), 
(633, 'module', 'nvtools', 'modules/nvtools/theme/theme.tpl', 1432784898, 0), 
(634, 'module', 'nvtools', 'modules/nvtools/theme.php', 1432784898, 0), 
(635, 'module', 'nvtools', 'modules/nvtools/version.php', 1432784898, 0), 
(636, 'module', 'nvtools', 'themes/default/modules/nvtools/.htaccess', 1432784898, 0), 
(637, 'module', 'nvtools', 'themes/default/modules/nvtools/addfun.tpl', 1432784898, 0), 
(638, 'module', 'nvtools', 'themes/default/modules/nvtools/data.tpl', 1432784898, 0), 
(639, 'module', 'nvtools', 'themes/default/modules/nvtools/index.html', 1432784898, 0), 
(640, 'module', 'nvtools', 'themes/default/modules/nvtools/main.tpl', 1432784898, 0), 
(641, 'module', 'nvtools', 'themes/default/modules/nvtools/theme.tpl', 1432784898, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_googleplus`
--

DROP TABLE IF EXISTS `nv4_googleplus`;
CREATE TABLE `nv4_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `idprofile` varchar(25) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_groups`
--

DROP TABLE IF EXISTS `nv4_groups`;
CREATE TABLE `nv4_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `publics` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_groups`
--

INSERT INTO `nv4_groups` VALUES
(6, 'All', '', 1432349800, 0, 0, 1, 1, 0, 0, 0), 
(5, 'Guest', '', 1432349800, 0, 0, 2, 1, 0, 0, 0), 
(4, 'Users', '', 1432349800, 0, 0, 3, 1, 0, 2, 0), 
(1, 'Super admin', '', 1432349800, 0, 0, 4, 1, 0, 1, 0), 
(2, 'General admin', '', 1432349800, 0, 0, 5, 1, 0, 0, 0), 
(3, 'Module admin', '', 1432349800, 0, 0, 6, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_groups_users`
--

DROP TABLE IF EXISTS `nv4_groups_users`;
CREATE TABLE `nv4_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_groups_users`
--

INSERT INTO `nv4_groups_users` VALUES
(1, 1, '0');


-- ---------------------------------------


--
-- Table structure for table `nv4_language`
--

DROP TABLE IF EXISTS `nv4_language`;
CREATE TABLE `nv4_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_language_file`
--

DROP TABLE IF EXISTS `nv4_language_file`;
CREATE TABLE `nv4_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_logs`
--

DROP TABLE IF EXISTS `nv4_logs`;
CREATE TABLE `nv4_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=222  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_logs`
--

INSERT INTO `nv4_logs` VALUES
(1, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1432349831), 
(2, 'vi', 'modules', 'Thiết lập module mới shops', '', '', 1, 1432350307), 
(3, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1432350312), 
(4, 'vi', 'modules', 'Thứ tự module: shops', '13 -> 1', '', 1, 1432352175), 
(5, 'vi', 'modules', 'Cài lại module \"shops\"', '', '', 1, 1432353382), 
(6, 'vi', 'modules', 'Thiết lập module mới download', '', '', 1, 1432353414), 
(7, 'vi', 'modules', 'Sửa module &ldquo;download&rdquo;', '', '', 1, 1432353417), 
(8, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1432353424), 
(9, 'vi', 'modules', 'Cài lại module \"shops\"', '', '', 1, 1432353427), 
(10, 'vi', 'shops', 'log_add_catalog', 'id 1', '', 1, 1432353959), 
(11, 'vi', 'shops', 'log_del_catalog', 'id 1', '', 1, 1432362677), 
(12, 'vi', 'shops', 'log_add_catalog', 'id 2', '', 1, 1432362728), 
(13, 'vi', 'shops', 'log_add_catalog', 'id 3', '', 1, 1432362789), 
(14, 'vi', 'shops', 'log_edit_catalog', 'id 2', '', 1, 1432362803), 
(15, 'vi', 'shops', 'log_add_catalog', 'id 4', '', 1, 1432362835), 
(16, 'vi', 'shops', 'log_add_catalog', 'id 5', '', 1, 1432362887), 
(17, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432362971), 
(18, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/maya-dam-maxi-sang-trong-hoa-cao-cap-bm12-1m4g3-dbc487_simg_d0daf0_800x1200_max.jpg', '', 1, 1432363258), 
(19, 'vi', 'shops', 'Add A Product', 'ID: 1', '', 1, 1432363521), 
(20, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1432363552), 
(21, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1432363597), 
(22, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432363812), 
(23, 'vi', 'shops', 'log_add_catalog', 'id 6', '', 1, 1432364675), 
(24, 'vi', 'shops', 'log_add_catalog', 'id 7', '', 1, 1432364695), 
(25, 'vi', 'shops', 'log_add_catalog', 'id 8', '', 1, 1432364752), 
(26, 'vi', 'shops', 'log_add_catalog', 'id 9', '', 1, 1432364786), 
(27, 'vi', 'shops', 'log_edit_catalog', 'id 4', '', 1, 1432364806), 
(28, 'vi', 'shops', 'log_add_catalog', 'id 10', '', 1, 1432364825), 
(29, 'vi', 'shops', 'log_edit_catalog', 'id 10', '', 1, 1432364835), 
(30, 'vi', 'shops', 'log_edit_catalog', 'id 10', '', 1, 1432364843), 
(31, 'vi', 'shops', 'log_edit_catalog', 'id 10', '', 1, 1432364863), 
(32, 'vi', 'shops', 'log_add_catalog', 'id 11', '', 1, 1432364880), 
(33, 'vi', 'shops', 'log_add_catalog', 'id 12', '', 1, 1432364936), 
(34, 'vi', 'shops', 'log_add_catalog', 'id 13', '', 1, 1432364976), 
(35, 'vi', 'shops', 'log_add_catalog', 'id 14', '', 1, 1432365033), 
(36, 'vi', 'shops', 'log_add_catalog', 'id 15', '', 1, 1432365081), 
(37, 'vi', 'shops', 'log_add_catalog', 'id 16', '', 1, 1432365108), 
(38, 'vi', 'shops', 'log_add_catalog', 'id 17', '', 1, 1432365135), 
(39, 'vi', 'shops', 'log_edit_catalog', 'id 17', '', 1, 1432365145), 
(40, 'vi', 'shops', 'log_edit_catalog', 'id 17', '', 1, 1432365155), 
(41, 'vi', 'shops', 'log_add_catalog', 'id 18', '', 1, 1432365185), 
(42, 'vi', 'shops', 'log_del_catalog', 'id 17', '', 1, 1432365189), 
(43, 'vi', 'shops', 'log_add_catalog', 'id 19', '', 1, 1432365211), 
(44, 'vi', 'shops', 'log_add_catalog', 'id 20', '', 1, 1432365242), 
(45, 'vi', 'shops', 'log_add_catalog', 'id 21', '', 1, 1432365281), 
(46, 'vi', 'shops', 'log_add_catalog', 'id 22', '', 1, 1432365303), 
(47, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/hang-nhap-cao-cap-dam-maxi-hoa-tiet-cao-cap-1m4g3-dammaxihoatietcaocap2_2kgkkt5saqrg4_simg_d0daf0_800x1200_max.jpg', '', 1, 1432365402), 
(48, 'vi', 'shops', 'Add A Product', 'ID: 2', '', 1, 1432365534), 
(49, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1432365563), 
(50, 'vi', 'shops', 'Edit A Product', 'ID: 2', '', 1, 1432365626), 
(51, 'vi', 'shops', 'Edit A Product', 'ID: 2', '', 1, 1432365661), 
(52, 'vi', 'shops', 'Edit A Product', 'ID: 2', '', 1, 1432365688), 
(53, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432365718), 
(54, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432365765), 
(55, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432365814), 
(56, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/dam-cao-cap.jpg', '', 1, 1432365874), 
(57, 'vi', 'shops', 'Edit A Product', 'ID: 2', '', 1, 1432365879), 
(58, 'vi', 'shops', 'Edit A Product', 'ID: 2', '', 1, 1432365970), 
(59, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432366104), 
(60, 'vi', 'shops', 'Add A Product', 'ID: 3', '', 1, 1432366714), 
(61, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/chan-vay-cong-so.jpg', '', 1, 1432366735), 
(62, 'vi', 'shops', 'Edit A Product', 'ID: 3', '', 1, 1432366740), 
(63, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/chan-vay-caro.jpg', '', 1, 1432367020), 
(64, 'vi', 'shops', 'Add A Product', 'ID: 4', '', 1, 1432367089), 
(65, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/ao-so-mi-voan-lua.jpg', '', 1, 1432367304), 
(66, 'vi', 'shops', 'Add A Product', 'ID: 5', '', 1, 1432367366), 
(67, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/hang-nhap-cao-cap-ao-so-mi-voan-phoi-tay-ren.jpg', '', 1, 1432367538), 
(68, 'vi', 'shops', 'Add A Product', 'ID: 6', '', 1, 1432367846), 
(69, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/ao-thun-nu-4-chieu-xb417.jpg', '', 1, 1432369115), 
(70, 'vi', 'shops', 'Add A Product', 'ID: 7', '', 1, 1432369124), 
(71, 'vi', 'shops', 'Edit A Product', 'ID: 6', '', 1, 1432369290), 
(72, 'vi', 'shops', 'Edit A Product', 'ID: 6', '', 1, 1432369367), 
(73, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/ao-so-mi-voan.jpg', '', 1, 1432369405), 
(74, 'vi', 'shops', 'Edit A Product', 'ID: 6', '', 1, 1432369415), 
(75, 'vi', 'shops', 'Edit A Product', 'ID: 7', '', 1, 1432369433), 
(76, 'vi', 'shops', 'Edit A Product', 'ID: 6', '', 1, 1432369451), 
(77, 'vi', 'shops', 'Edit A Product', 'ID: 6', '', 1, 1432369571), 
(78, 'vi', 'shops', 'Edit A Product', 'ID: 6', '', 1, 1432370007), 
(79, 'vi', 'login', '[nguyenhue] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1432602431), 
(80, 'vi', 'login', '[nguyenhue] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1432602440), 
(81, 'vi', 'login', '[nguyenhue] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1432602442), 
(82, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1432602632), 
(83, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432605405), 
(84, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432605432), 
(85, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/ao-thun-nu-4-chieu.jpg', '', 1, 1432605593), 
(86, 'vi', 'shops', 'Add A Product', 'ID: 8', '', 1, 1432605984), 
(87, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/giay-da-nu-got-vuong.jpg', '', 1, 1432606198), 
(88, 'vi', 'shops', 'Add A Product', 'ID: 9', '', 1, 1432606317), 
(89, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4g3-giaycaogotcg666hcopy_2k4etslal2erb_simg_d0daf0_800x1200_max.png', '', 1, 1432606448), 
(90, 'vi', 'shops', 'Add A Product', 'ID: 10', '', 1, 1432606522), 
(91, 'vi', 'upload', 'Upload file', 'uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', '', 1, 1432606878), 
(92, 'vi', 'shops', 'Add A Product', 'ID: 11', '', 1, 1432607113), 
(93, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1432608722), 
(94, 'vi', 'login', '[nguyenhue] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1432608758), 
(95, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1432608769), 
(96, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1432609803), 
(97, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1432610243), 
(98, 'vi', 'themes', 'Thêm block', 'Name : Test', '', 1, 1432613583), 
(99, 'vi', 'themes', 'Thêm block', 'Name : Tin tiêu điểm', '', 1, 1432613873), 
(100, 'vi', 'themes', 'Thêm block', 'Name : global block groups marquee', '', 1, 1432614115), 
(101, 'vi', 'shops', 'log_add_group', 'id 1', '', 1, 1432623061), 
(102, 'vi', 'shops', 'log_add_group', 'id 2', '', 1, 1432623083), 
(103, 'vi', 'shops', 'log_add_group', 'id 3', '', 1, 1432623101), 
(104, 'vi', 'shops', 'log_add_group', 'id 4', '', 1, 1432623118), 
(105, 'vi', 'shops', 'log_add_group', 'id 5', '', 1, 1432623133), 
(106, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1432623613), 
(107, 'vi', 'users', 'Đăng ký thành viên', 'nguyenhue | 127.0.0.1 | Simple', '', 0, 1432623762), 
(108, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1432623898), 
(109, 'vi', 'shops', 'log_add_group', 'id 6', '', 1, 1432626862), 
(110, 'vi', 'shops', 'log_add_group', 'id 7', '', 1, 1432626882), 
(111, 'vi', 'shops', 'log_add_group', 'id 8', '', 1, 1432626899), 
(112, 'vi', 'shops', 'log_add_group', 'id 9', '', 1, 1432627013), 
(113, 'vi', 'shops', 'log_add_group', 'id 10', '', 1, 1432627027), 
(114, 'vi', 'shops', 'log_add_group', 'id 11', '', 1, 1432627053), 
(115, 'vi', 'shops', 'log_add_group', 'id 12', '', 1, 1432627064), 
(116, 'vi', 'shops', 'log_add_group', 'id 13', '', 1, 1432627070), 
(117, 'vi', 'shops', 'log_add_group', 'id 14', '', 1, 1432627085), 
(118, 'vi', 'shops', 'Xóa nhóm và các sản phẩm', 'VÀNG', '', 1, 1432627090), 
(119, 'vi', 'shops', 'log_add_group', 'id 15', '', 1, 1432627095), 
(120, 'vi', 'shops', 'log_add_group', 'id 16', '', 1, 1432627102), 
(121, 'vi', 'shops', 'log_add_group', 'id 17', '', 1, 1432627107), 
(122, 'vi', 'shops', 'log_add_group', 'id 18', '', 1, 1432627112), 
(123, 'vi', 'shops', 'log_add_group', 'id 19', '', 1, 1432627123), 
(124, 'vi', 'shops', 'log_add_group', 'id 20', '', 1, 1432627135), 
(125, 'vi', 'shops', 'log_add_group', 'id 21', '', 1, 1432627148), 
(126, 'vi', 'shops', 'log_add_group', 'id 22', '', 1, 1432627153), 
(127, 'vi', 'shops', 'log_add_group', 'id 23', '', 1, 1432627160), 
(128, 'vi', 'shops', 'log_add_group', 'id 24', '', 1, 1432627182), 
(129, 'vi', 'shops', 'log_add_group', 'id 25', '', 1, 1432627201), 
(130, 'vi', 'shops', 'log_add_group', 'id 26', '', 1, 1432627210), 
(131, 'vi', 'shops', 'log_add_group', 'id 27', '', 1, 1432627215), 
(132, 'vi', 'shops', 'log_add_group', 'id 28', '', 1, 1432627219), 
(133, 'vi', 'shops', 'log_add_group', 'id 29', '', 1, 1432627223), 
(134, 'vi', 'shops', 'log_add_group', 'id 30', '', 1, 1432627241), 
(135, 'vi', 'shops', 'log_add_group', 'id 31', '', 1, 1432627250), 
(136, 'vi', 'shops', 'log_add_group', 'id 32', '', 1, 1432627259), 
(137, 'vi', 'shops', 'log_add_group', 'id 33', '', 1, 1432627264), 
(138, 'vi', 'shops', 'log_add_group', 'id 34', '', 1, 1432627269), 
(139, 'vi', 'shops', 'log_add_group', 'id 35', '', 1, 1432627274), 
(140, 'vi', 'shops', 'log_add_group', 'id 36', '', 1, 1432627279), 
(141, 'vi', 'shops', 'log_add_group', 'id 37', '', 1, 1432627284), 
(142, 'vi', 'shops', 'log_add_group', 'id 38', '', 1, 1432627291), 
(143, 'vi', 'shops', 'log_add_group', 'id 39', '', 1, 1432627296), 
(144, 'vi', 'shops', 'log_add_group', 'id 40', '', 1, 1432627339), 
(145, 'vi', 'shops', 'log_add_group', 'id 41', '', 1, 1432627346), 
(146, 'vi', 'shops', 'log_add_group', 'id 42', '', 1, 1432627364), 
(147, 'vi', 'shops', 'log_add_group', 'id 43', '', 1, 1432627369), 
(148, 'vi', 'shops', 'log_add_group', 'id 44', '', 1, 1432627378), 
(149, 'vi', 'shops', 'log_add_group', 'id 45', '', 1, 1432627385), 
(150, 'vi', 'shops', 'log_add_group', 'id 46', '', 1, 1432627399), 
(151, 'vi', 'shops', 'log_add_group', 'id 47', '', 1, 1432627407), 
(152, 'vi', 'shops', 'log_add_group', 'id 48', '', 1, 1432627418), 
(153, 'vi', 'shops', 'log_add_group', 'id 49', '', 1, 1432627425), 
(154, 'vi', 'shops', 'log_add_group', 'id 50', '', 1, 1432627519), 
(155, 'vi', 'shops', 'log_add_group', 'id 51', '', 1, 1432627528), 
(156, 'vi', 'shops', 'log_add_group', 'id 52', '', 1, 1432627541), 
(157, 'vi', 'shops', 'log_add_group', 'id 53', '', 1, 1432627553), 
(158, 'vi', 'shops', 'log_add_group', 'id 54', '', 1, 1432627565), 
(159, 'vi', 'shops', 'log_add_group', 'id 55', '', 1, 1432627573), 
(160, 'vi', 'shops', 'log_add_group', 'id 56', '', 1, 1432627579), 
(161, 'vi', 'shops', 'log_add_group', 'id 57', '', 1, 1432627617), 
(162, 'vi', 'shops', 'Edit A Product', 'ID: 11', '', 1, 1432627760), 
(163, 'vi', 'shops', 'Edit A Product', 'ID: 11', '', 1, 1432629575), 
(164, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1432629616), 
(165, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1432629698), 
(166, 'vi', 'shops', 'Edit A Product', 'ID: 10', '', 1, 1432629769), 
(167, 'vi', 'shops', 'Edit A Product', 'ID: 10', '', 1, 1432629789), 
(168, 'vi', 'shops', 'Edit A Product', 'ID: 9', '', 1, 1432629809), 
(169, 'vi', 'shops', 'Log payment product', 'Order code: S000003', '', 1, 1432632209), 
(170, 'vi', 'shops', 'Drop payment product', 'Order code: S000003', '', 1, 1432632218), 
(171, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1432776715), 
(172, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1432776770), 
(173, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1432776949), 
(174, 'vi', 'shops', 'log_add_location', 'id 1', '', 1, 1432777101), 
(175, 'vi', 'shops', 'log_add_location', 'id 2', '', 1, 1432777561), 
(176, 'vi', 'shops', 'log_add_location', 'id 3', '', 1, 1432777583), 
(177, 'vi', 'shops', 'log_add_location', 'id 4', '', 1, 1432777602), 
(178, 'vi', 'shops', 'log_add_location', 'id 5', '', 1, 1432777609), 
(179, 'vi', 'shops', 'log_add_location', 'id 6', '', 1, 1432777631), 
(180, 'vi', 'shops', 'log_add_location', 'id 7', '', 1, 1432777638), 
(181, 'vi', 'shops', 'log_add_location', 'id 8', '', 1, 1432777659), 
(182, 'vi', 'shops', 'log_add_location', 'id 9', '', 1, 1432777667), 
(183, 'vi', 'shops', 'log_add_location', 'id 10', '', 1, 1432777678), 
(184, 'vi', 'shops', 'log_add_location', 'id 11', '', 1, 1432777685), 
(185, 'vi', 'shops', 'log_add_location', 'id 12', '', 1, 1432777692), 
(186, 'vi', 'shops', 'log_add_location', 'id 13', '', 1, 1432777700), 
(187, 'vi', 'shops', 'log_add_location', 'id 14', '', 1, 1432777710), 
(188, 'vi', 'shops', 'log_add_location', 'id 15', '', 1, 1432777736), 
(189, 'vi', 'shops', 'log_add_location', 'id 16', '', 1, 1432777749), 
(190, 'vi', 'extensions', 'Cài đặt ứng dụng', 'module-nvtools-master.zip', '', 1, 1432784885), 
(191, 'vi', 'modules', 'Thiết lập module mới nvtools', '', '', 1, 1432784905), 
(192, 'vi', 'modules', 'Sửa module &ldquo;nvtools&rdquo;', '', '', 1, 1432784918), 
(193, 'vi', 'modules', 'Thứ tự module: nvtools', '15 -> 2', '', 1, 1432784922), 
(194, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1432798834), 
(195, 'vi', 'login', '[ nguyenhue ] Đăng nhập Thất bại', ' Client IP:127.0.0.1', '', 0, 1433208601), 
(196, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1433208685), 
(197, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1433212712), 
(198, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1433213132), 
(199, 'vi', 'themes', 'Thêm block', 'Name : global block qc', '', 1, 1433213926), 
(200, 'vi', 'themes', 'Thêm block', 'Name : global block qc', '', 1, 1433213953), 
(201, 'vi', 'themes', 'Sửa block', 'Name : global block qc', '', 1, 1433214108), 
(202, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1433214501), 
(203, 'vi', 'themes', 'Thêm block', 'Name : global block groups marquee', '', 1, 1433214701), 
(204, 'vi', 'themes', 'Thêm block', 'Name : global block groups marquee', '', 1, 1433214920), 
(205, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1433214958), 
(206, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1433217093), 
(207, 'vi', 'themes', 'Thêm block', 'Name : global block groups marquee', '', 1, 1433217144), 
(208, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1433225623), 
(209, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1433225834), 
(210, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1433225853), 
(211, 'vi', 'themes', 'Sửa block', 'Name : global banners', '', 1, 1433225913), 
(212, 'vi', 'themes', 'Sửa block', 'Name : global banners', '', 1, 1433225926), 
(213, 'vi', 'themes', 'Sửa block', 'Name : Tin tiêu điểm', '', 1, 1433225957), 
(214, 'vi', 'themes', 'Thêm block', 'Name : global slide roundabout', '', 1, 1433227145), 
(215, 'vi', 'themes', 'Thêm block', 'Name : global block groups marquee', '', 1, 1433227827), 
(216, 'vi', 'themes', 'Sửa block', 'Name : Tin tiêu điểm', '', 1, 1433227850), 
(217, 'vi', 'themes', 'Sửa block', 'Name : global slide roundabout', '', 1, 1433227882), 
(218, 'vi', 'themes', 'Thêm block', 'Name : global slide roundabout', '', 1, 1433228048), 
(219, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1433228247), 
(220, 'vi', 'themes', 'Sửa block', 'Name : global slide roundabout', '', 1, 1433230818), 
(221, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearsession, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1433231604);


-- ---------------------------------------


--
-- Table structure for table `nv4_notification`
--

DROP TABLE IF EXISTS `nv4_notification`;
CREATE TABLE `nv4_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` mediumint(8) unsigned NOT NULL,
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(1) unsigned NOT NULL,
  `language` char(3) NOT NULL,
  `module` varchar(50) NOT NULL,
  `type` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_plugin`
--

DROP TABLE IF EXISTS `nv4_plugin`;
CREATE TABLE `nv4_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50) NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_sessions`
--

DROP TABLE IF EXISTS `nv4_sessions`;
CREATE TABLE `nv4_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_setup`
--

DROP TABLE IF EXISTS `nv4_setup`;
CREATE TABLE `nv4_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_extensions`
--

DROP TABLE IF EXISTS `nv4_setup_extensions`;
CREATE TABLE `nv4_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50) NOT NULL DEFAULT '',
  `table_prefix` varchar(55) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_setup_extensions`
--

INSERT INTO `nv4_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'shops', 0, 1, 'shops', 'shops', '4.0.13 1371948600', 1432350306, 'VINADES (contact@vinades.vn)', ''), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 0, 'users', 'users', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(25, 'module', 'download', 0, 1, 'download', 'download', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 1, 'menu', 'menu', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'default', 0, 0, 'default', 'default', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'modern', 0, 0, 'modern', 'modern', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'mobile_nukeviet', 0, 0, 'mobile_nukeviet', 'mobile_nukeviet', '4.0.13 1427991873', 1432349800, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'nvtools', 0, 0, 'nvtools', 'nvtools', '4.0.00 1432784898', 1432784898, 'VINADES.,JSC (nukeviet.store@vinades.vn)', 'Công cụ xây dựng site: Tạo module mẫu, làm form tự động');


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_language`
--

DROP TABLE IF EXISTS `nv4_setup_language`;
CREATE TABLE `nv4_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_setup_language`
--

INSERT INTO `nv4_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_block`
--

DROP TABLE IF EXISTS `nv4_shops_block`;
CREATE TABLE `nv4_shops_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_block_cat`
--

DROP TABLE IF EXISTS `nv4_shops_block_cat`;
CREATE TABLE `nv4_shops_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier`
--

DROP TABLE IF EXISTS `nv4_shops_carrier`;
CREATE TABLE `nv4_shops_carrier` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_carrier`
--

INSERT INTO `nv4_shops_carrier` VALUES
(10, 'Kerry Hà Nội', '0438436393', 'Nguyễn chí Thanh, Hà Nội', '', '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier_config`
--

DROP TABLE IF EXISTS `nv4_shops_carrier_config`;
CREATE TABLE `nv4_shops_carrier_config` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_carrier_config`
--

INSERT INTO `nv4_shops_carrier_config` VALUES
(3, 'kerry', '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier_config_items`
--

DROP TABLE IF EXISTS `nv4_shops_carrier_config_items`;
CREATE TABLE `nv4_shops_carrier_config_items` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `cid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `weight` smallint(4) unsigned NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier_config_location`
--

DROP TABLE IF EXISTS `nv4_shops_carrier_config_location`;
CREATE TABLE `nv4_shops_carrier_config_location` (
  `cid` tinyint(3) unsigned NOT NULL,
  `iid` smallint(4) unsigned NOT NULL,
  `lid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_carrier_config_weight`
--

DROP TABLE IF EXISTS `nv4_shops_carrier_config_weight`;
CREATE TABLE `nv4_shops_carrier_config_weight` (
  `iid` smallint(4) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  `weight_unit` varchar(20) NOT NULL,
  `carrier_price` float NOT NULL,
  `carrier_price_unit` char(3) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_catalogs`
--

DROP TABLE IF EXISTS `nv4_shops_catalogs`;
CREATE TABLE `nv4_shops_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(4) NOT NULL DEFAULT '3',
  `typeprice` tinyint(4) NOT NULL DEFAULT '2',
  `form` varchar(50) NOT NULL DEFAULT '',
  `group_price` text NOT NULL,
  `viewdescriptionhtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` mediumtext NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) NOT NULL DEFAULT '',
  `cat_allow_point` tinyint(1) NOT NULL DEFAULT '0',
  `cat_number_point` tinyint(4) NOT NULL DEFAULT '0',
  `cat_number_product` tinyint(4) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_descriptionhtml` text NOT NULL,
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=23  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_catalogs`
--

INSERT INTO `nv4_shops_catalogs` VALUES
(2, 0, '', 1, 1, 0, 'viewcat_page_list', 4, '6,7,8,9', 1, 4, 7, 1, '', '', 0, '', 1432362728, 1432362803, '6', 0, 0, 0, 'Váy', 'Vay-nu', '', '', 'váy, vay'), 
(3, 0, '', 2, 6, 0, 'viewcat_page_list', 4, '13,14,15,16', 1, 4, 7, 1, '', '', 0, '', 1432362789, 1432362789, '6', 0, 0, 0, 'Giày dép', 'Giay-dep', '', '', 'giay, dep, giày, dép'), 
(4, 0, '', 3, 11, 0, 'viewcat_page_list', 3, '10,11,12', 1, 4, 7, 1, '', '', 0, '', 1432362835, 1432364806, '6', 0, 0, 0, 'Áo', 'Ao', '', '', 'áo, ao'), 
(5, 0, '', 4, 15, 0, 'viewcat_page_list', 5, '18,19,20,21,22', 1, 4, 7, 1, '', '', 0, '', 1432362887, 1432362887, '6', 0, 0, 0, 'Phụ kiện', 'Phu-kien', '', '', 'Phụ kiện, Phu kien, kiện, kien, phu kien'), 
(6, 2, '', 1, 2, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364675, 1432364675, '6', 0, 0, 0, 'váy dài', 'vay-dai', '', '', 'váy dài, dài, vay dai'), 
(7, 2, '', 2, 3, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364695, 1432364695, '6', 0, 0, 0, 'váy ngắn', 'vay-ngan', '', '', 'váy ngắn, vay ngan'), 
(8, 2, '', 3, 4, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364752, 1432364752, '6', 0, 0, 0, 'đầm maxi', 'dam-maxi', '', '', 'đầm, maxi, Maxi, đầm maxi, Đầm maxi'), 
(9, 2, '', 4, 5, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364786, 1432364786, '6', 0, 0, 0, 'Váy chữ A', 'Vay-chu-A', '', '', 'Váy chữ A, váy chữ a'), 
(10, 4, '', 1, 12, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364825, 1432364863, '6', 0, 0, 0, 'Áo sơmi', 'Ao-somi', '', '', 'Áo sơmi,, sơmi. áo'), 
(11, 4, '', 2, 13, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364880, 1432364880, '6', 0, 0, 0, 'Áo phông', 'Ao-phong', '', '', ''), 
(12, 4, '', 3, 14, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364936, 1432364936, '6', 0, 0, 0, 'Áo dáng dài', 'Ao-dang-dai', '', '', 'Áo dáng dài, áo'), 
(13, 3, '', 1, 7, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432364976, 1432364976, '6', 0, 0, 0, 'Giày cao gót', 'Giay-cao-got', '', '', 'Giày cao gót, cao gót, cao got'), 
(14, 3, '', 2, 8, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365033, 1432365033, '6', 0, 0, 0, 'Giày sandal', 'Giay-sandal', '', '', 'sandal, Sandal, giày, giày sandal'), 
(15, 3, '', 3, 9, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365081, 1432365081, '6', 0, 0, 0, 'Giày búp bê', 'Giay-bup-be', '', '', 'giày búp bê, Giày búp bê, giay bup be, Giay bup be, búp bê, bup be'), 
(16, 3, '', 4, 10, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365108, 1432365108, '6', 0, 0, 0, 'Giày vải', 'Giay-vai', '', '', 'vải, giày vải, giay vai'), 
(19, 5, '', 2, 17, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365211, 1432365211, '6', 0, 0, 0, 'Lắc tay', 'Lac-tay', '', '', 'Lắc tay. lac tay, lắc'), 
(18, 5, '', 1, 16, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365185, 1432365185, '6', 0, 0, 0, 'Vòng cổ', 'Phu-kien-Vong-co', '', '', 'vòng cổ, Vòng cổ, vong co'), 
(20, 5, '', 3, 18, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365242, 1432365242, '6', 0, 0, 0, 'Thắt lưng', 'That-lung', '', '', 'Thắt lưng, that lung, thắt lưng'), 
(21, 5, '', 4, 19, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365281, 1432365281, '6', 0, 0, 0, 'Đồng hồ', 'Dong-ho', '', '', 'Đồng hồ, hồ, dong ho'), 
(22, 5, '', 5, 20, 1, 'viewcat_page_list', 0, '', 1, 4, 7, 1, '', '', 0, '', 1432365303, 1432365303, '6', 0, 0, 0, 'Ví nữ', 'Vi-nu', '', '', 'ví nữ, ví');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons`
--

DROP TABLE IF EXISTS `nv4_shops_coupons`;
CREATE TABLE `nv4_shops_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `code` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(1) NOT NULL DEFAULT 'p',
  `discount` float NOT NULL DEFAULT '0',
  `total_amount` float NOT NULL DEFAULT '0',
  `date_start` int(11) unsigned NOT NULL DEFAULT '0',
  `date_end` int(11) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon` int(11) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon_count` int(11) NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons_history`
--

DROP TABLE IF EXISTS `nv4_shops_coupons_history`;
CREATE TABLE `nv4_shops_coupons_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_coupons_product`
--

DROP TABLE IF EXISTS `nv4_shops_coupons_product`;
CREATE TABLE `nv4_shops_coupons_product` (
  `cid` int(11) unsigned NOT NULL,
  `pid` int(11) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_discounts`
--

DROP TABLE IF EXISTS `nv4_shops_discounts`;
CREATE TABLE `nv4_shops_discounts` (
  `did` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `begin_time` int(11) unsigned NOT NULL DEFAULT '0',
  `end_time` int(11) unsigned NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  `detail` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  KEY `begin_time` (`begin_time`,`end_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_discounts`
--

INSERT INTO `nv4_shops_discounts` VALUES
(1, 'giảm giá đầu hè', 1, 1432629531, 1432629531, 1432054800, 1434819599, 'a:1:{i:0;a:4:{s:13:\"discount_from\";i:1;s:11:\"discount_to\";i:20;s:15:\"discount_number\";d:15;s:13:\"discount_unit\";s:1:\"p\";}}', 1), 
(2, 'giám giá hot', 2, 1432629756, 1432629756, 1430413200, 1436374799, 'a:1:{i:0;a:4:{s:13:\"discount_from\";i:1;s:11:\"discount_to\";i:20;s:15:\"discount_number\";d:20;s:13:\"discount_unit\";s:1:\"p\";}}', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_field`
--

DROP TABLE IF EXISTS `nv4_shops_field`;
CREATE TABLE `nv4_shops_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `listtemplate` varchar(25) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `class` varchar(25) NOT NULL DEFAULT '',
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group`
--

DROP TABLE IF EXISTS `nv4_shops_group`;
CREATE TABLE `nv4_shops_group` (
  `groupid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewgroup` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubgroup` int(11) NOT NULL DEFAULT '0',
  `subgroupid` varchar(255) NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `indetail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `numpro` int(11) unsigned NOT NULL DEFAULT '0',
  `in_order` tinyint(2) NOT NULL DEFAULT '0',
  `is_require` tinyint(1) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_description` varchar(255) NOT NULL DEFAULT '',
  `vi_keywords` text NOT NULL,
  PRIMARY KEY (`groupid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=58  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_group`
--

INSERT INTO `nv4_shops_group` VALUES
(1, 0, '', 1, 1, 0, 'viewcat_page_list', 6, '6,7,8,9,10,11', 1, 1, 1432623061, 1432623061, 0, 1, 0, 'Thương hiệu', 'Thuong-hieu', '', ''), 
(2, 0, '', 2, 8, 0, 'viewcat_page_list', 12, '12,13,15,16,17,18,19,20,21,22,23,24', 1, 1, 1432623083, 1432623083, 0, 1, 0, 'Màu sắc', 'Mau-sac', '', ''), 
(3, 0, '', 3, 21, 0, 'viewcat_page_list', 15, '25,26,27,28,29,30,31,32,33,34,35,36,37,38,39', 1, 1, 1432623101, 1432623101, 0, 1, 0, 'Kích thước', 'Kich-thuoc', '', ''), 
(4, 0, '', 4, 37, 0, 'viewcat_page_list', 8, '40,41,42,43,44,45,46,47', 1, 1, 1432623118, 1432623118, 0, 1, 0, 'Chất liệu', 'Chat-lieu', '', ''), 
(5, 0, '', 5, 46, 0, 'viewcat_page_list', 10, '48,49,50,51,52,53,54,55,56,57', 1, 1, 1432623133, 1432623133, 0, 1, 0, 'Xuất xứ', 'Xuat-xu', '', ''), 
(6, 1, '', 1, 2, 1, 'viewcat_page_list', 0, '', 1, 1, 1432626862, 1432626862, 0, 1, 0, 'Việt Tiến', 'Viet-Tien', '', ''), 
(7, 1, '', 2, 3, 1, 'viewcat_page_list', 0, '', 1, 1, 1432626882, 1432626882, 3, 1, 0, 'ZARA', 'ZARA', '', ''), 
(8, 1, '', 3, 4, 1, 'viewcat_page_list', 0, '', 1, 1, 1432626899, 1432626899, 0, 1, 0, 'MATTANA', 'MATTANA', '', ''), 
(9, 1, '', 4, 5, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627013, 1432627013, 0, 1, 0, 'KELVIN', 'KELVIN', '', ''), 
(10, 1, '', 5, 6, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627027, 1432627027, 0, 1, 0, 'THÁI TUẤN', 'THAI-TUAN', '', ''), 
(11, 1, '', 6, 7, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627053, 1432627053, 0, 1, 0, 'VICTORIA SECRECT', 'VICTORIA-SECRECT', '', ''), 
(12, 2, '', 1, 9, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627064, 1432627064, 0, 1, 0, 'ĐỎ', 'DO', '', ''), 
(13, 2, '', 2, 10, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627070, 1432627070, 0, 1, 0, 'VÀNG', 'VANG', '', ''), 
(16, 2, '', 4, 12, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627102, 1432627102, 1, 1, 0, 'HỒNG PHẤN', 'HONG-PHAN', '', ''), 
(15, 2, '', 3, 11, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627095, 1432627095, 0, 1, 0, 'XANH NGỌC', 'XANH-NGOC', '', ''), 
(17, 2, '', 5, 13, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627107, 1432627107, 0, 1, 0, 'XANH RÊU', 'XANH-REU', '', ''), 
(18, 2, '', 6, 14, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627112, 1432627112, 0, 1, 0, 'TÍM', 'TIM', '', ''), 
(19, 2, '', 7, 15, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627123, 1432627123, 0, 1, 0, 'XÁM', 'XAM', '', ''), 
(20, 2, '', 8, 16, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627135, 1432627135, 0, 1, 0, 'XANH NƯỚC BIỂN', 'XANH-NUOC-BIEN', '', ''), 
(21, 2, '', 9, 17, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627148, 1432627148, 0, 1, 0, 'CAM', 'CAM', '', ''), 
(22, 2, '', 10, 18, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627153, 1432627153, 0, 1, 0, 'BẠC', 'BAC', '', ''), 
(23, 2, '', 11, 19, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627160, 1432627160, 0, 1, 0, 'MÀU DA', 'MAU-DA', '', ''), 
(24, 2, '', 12, 20, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627182, 1432627182, 2, 1, 0, 'ĐEN', 'DEN', '', ''), 
(25, 3, '', 1, 22, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627201, 1432627201, 0, 1, 0, 'F', 'F', '', ''), 
(26, 3, '', 2, 23, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627210, 1432627210, 0, 1, 0, 'L', 'L', '', ''), 
(27, 3, '', 3, 24, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627215, 1432627215, 0, 1, 0, 'M', 'M', '', ''), 
(28, 3, '', 4, 25, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627219, 1432627219, 0, 1, 0, 'S', 'S', '', ''), 
(29, 3, '', 5, 26, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627223, 1432627223, 0, 1, 0, 'XL', 'XL', '', ''), 
(30, 3, '', 6, 27, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627241, 1432627241, 0, 1, 0, 'XXL', 'XXL', '', ''), 
(31, 3, '', 7, 28, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627250, 1432627250, 0, 1, 0, 'XXXL', 'XXXL', '', ''), 
(32, 3, '', 8, 29, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627259, 1432627259, 2, 1, 0, '35', '35', '', ''), 
(33, 3, '', 9, 30, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627264, 1432627264, 2, 1, 0, '36', '36', '', ''), 
(34, 3, '', 10, 31, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627269, 1432627269, 2, 1, 0, '37', '37', '', ''), 
(35, 3, '', 11, 32, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627274, 1432627274, 3, 1, 0, '38', '38', '', ''), 
(36, 3, '', 12, 33, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627279, 1432627279, 0, 1, 0, '39', '39', '', ''), 
(37, 3, '', 13, 34, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627284, 1432627284, 0, 1, 0, '40', '40', '', ''), 
(38, 3, '', 14, 35, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627291, 1432627291, 0, 1, 0, '41', '41', '', ''), 
(39, 3, '', 15, 36, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627296, 1432627296, 0, 1, 0, '42', '42', '', ''), 
(40, 4, '', 1, 38, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627339, 1432627339, 0, 1, 0, 'COTTON', 'COTTON', '', ''), 
(41, 4, '', 2, 39, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627346, 1432627346, 0, 1, 0, 'DẠ', 'DA', '', ''), 
(42, 4, '', 3, 40, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627364, 1432627364, 0, 1, 0, 'JEANS', 'JEANS', '', ''), 
(43, 4, '', 4, 41, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627369, 1432627369, 0, 1, 0, 'BÒ', 'BO', '', ''), 
(44, 4, '', 5, 42, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627378, 1432627378, 0, 1, 0, 'LANH', 'LANH', '', ''), 
(45, 4, '', 6, 43, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627385, 1432627385, 0, 1, 0, 'TƠ TẰM', 'TO-TAM', '', ''), 
(46, 4, '', 7, 44, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627399, 1432627399, 0, 1, 0, 'THUN', 'THUN', '', ''), 
(47, 4, '', 8, 45, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627407, 1432627407, 0, 1, 0, 'LỤA', 'LUA', '', ''), 
(48, 5, '', 1, 47, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627418, 1432627418, 0, 1, 0, 'VIỆT NAM', 'VIET-NAM', '', ''), 
(49, 5, '', 2, 48, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627425, 1432627425, 0, 1, 0, 'HÀN QUỐC', 'HAN-QUOC', '', ''), 
(50, 5, '', 3, 49, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627519, 1432627519, 0, 1, 0, 'ĐỨC', 'DUC', '', ''), 
(51, 5, '', 4, 50, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627528, 1432627528, 1, 1, 0, 'NHẬT BẢN', 'NHAT-BAN', '', ''), 
(52, 5, '', 5, 51, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627541, 1432627541, 0, 1, 0, 'THÁI LAN', 'THAI-LAN', '', ''), 
(53, 5, '', 6, 52, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627553, 1432627553, 1, 1, 0, 'HONGKONG', 'HONGKONG', '', ''), 
(54, 5, '', 7, 53, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627565, 1432627565, 0, 1, 0, 'TRUNG QUỐC', 'TRUNG-QUOC', '', ''), 
(55, 5, '', 8, 54, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627573, 1432627573, 0, 1, 0, 'PHÁP', 'PHAP', '', ''), 
(56, 5, '', 9, 55, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627579, 1432627579, 0, 1, 0, 'ANH', 'ANH', '', ''), 
(57, 5, '', 10, 56, 1, 'viewcat_page_list', 0, '', 1, 1, 1432627617, 1432627617, 0, 1, 0, 'AUSTRALIA', 'AUSTRALIA', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group_cateid`
--

DROP TABLE IF EXISTS `nv4_shops_group_cateid`;
CREATE TABLE `nv4_shops_group_cateid` (
  `groupid` mediumint(8) unsigned NOT NULL,
  `cateid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `groupid` (`groupid`,`cateid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_group_cateid`
--

INSERT INTO `nv4_shops_group_cateid` VALUES
(1, 2), 
(1, 3), 
(1, 4), 
(1, 5), 
(2, 2), 
(2, 3), 
(2, 4), 
(2, 5), 
(3, 2), 
(3, 3), 
(3, 4), 
(3, 5), 
(4, 2), 
(4, 3), 
(4, 4), 
(4, 5), 
(5, 2), 
(5, 3), 
(5, 4), 
(5, 5);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group_items`
--

DROP TABLE IF EXISTS `nv4_shops_group_items`;
CREATE TABLE `nv4_shops_group_items` (
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `group_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pro_id`,`group_id`),
  KEY `pro_id` (`pro_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_group_items`
--

INSERT INTO `nv4_shops_group_items` VALUES
(9, 7), 
(9, 24), 
(9, 32), 
(9, 33), 
(9, 34), 
(9, 35), 
(9, 53), 
(10, 7), 
(10, 16), 
(10, 32), 
(10, 33), 
(10, 34), 
(10, 35), 
(10, 51), 
(11, 7), 
(11, 24), 
(11, 35);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_group_quantity`
--

DROP TABLE IF EXISTS `nv4_shops_group_quantity`;
CREATE TABLE `nv4_shops_group_quantity` (
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `listgroup` varchar(255) NOT NULL,
  `quantity` int(11) unsigned NOT NULL,
  UNIQUE KEY `pro_id` (`pro_id`,`listgroup`),
  KEY `listgroup` (`listgroup`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_info`
--

DROP TABLE IF EXISTS `nv4_shops_info`;
CREATE TABLE `nv4_shops_info` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `shopid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_location`
--

DROP TABLE IF EXISTS `nv4_shops_location`;
CREATE TABLE `nv4_shops_location` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsub` int(11) NOT NULL DEFAULT '0',
  `subid` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=17  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_location`
--

INSERT INTO `nv4_shops_location` VALUES
(1, 0, 'An Giang', 1, 1, 0, 0, ''), 
(2, 0, 'Vũng Tàu', 2, 2, 0, 0, ''), 
(3, 0, 'Bắc Cạn', 3, 3, 0, 0, ''), 
(4, 0, 'Bắc Giang', 4, 4, 0, 0, ''), 
(5, 0, 'Bạc Liêu', 5, 5, 0, 0, ''), 
(6, 0, 'Bắc Ninh', 6, 6, 0, 0, ''), 
(7, 0, 'Bến Tre', 7, 7, 0, 0, ''), 
(8, 0, 'Bình Định', 8, 8, 0, 0, ''), 
(9, 0, 'BÌnh Dương', 9, 9, 0, 0, ''), 
(10, 0, 'Bình Phước', 10, 10, 0, 0, ''), 
(11, 0, 'Bình Thuận', 11, 11, 0, 0, ''), 
(12, 0, 'Cà Mau', 12, 12, 0, 0, ''), 
(13, 0, 'Cần Thơ', 13, 13, 0, 0, ''), 
(14, 0, 'Cao Bằng', 14, 14, 0, 0, ''), 
(15, 0, 'Đà Nẵng', 15, 15, 0, 0, ''), 
(16, 0, 'ĐăkLak', 16, 16, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_money_vi`
--

DROP TABLE IF EXISTS `nv4_shops_money_vi`;
CREATE TABLE `nv4_shops_money_vi` (
  `id` mediumint(11) NOT NULL,
  `code` char(3) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `exchange` float NOT NULL DEFAULT '0',
  `round` varchar(10) NOT NULL,
  `number_format` varchar(5) NOT NULL DEFAULT ',||.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_money_vi`
--

INSERT INTO `nv4_shops_money_vi` VALUES
(840, 'USD', 'US Dollar', '21000', '0.01', ',||.'), 
(704, 'VND', 'Vietnam Dong', '1', '100', ',||.');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders`
--

DROP TABLE IF EXISTS `nv4_shops_orders`;
CREATE TABLE `nv4_shops_orders` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_code` varchar(30) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT 'en',
  `order_name` varchar(255) NOT NULL,
  `order_email` varchar(255) NOT NULL,
  `order_phone` varchar(20) NOT NULL,
  `order_note` text NOT NULL,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_id` int(11) unsigned NOT NULL DEFAULT '0',
  `shop_id` int(11) unsigned NOT NULL DEFAULT '0',
  `who_is` int(2) unsigned NOT NULL DEFAULT '0',
  `unit_total` char(3) NOT NULL,
  `order_total` double unsigned NOT NULL DEFAULT '0',
  `order_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `postip` varchar(100) NOT NULL,
  `order_view` tinyint(2) NOT NULL DEFAULT '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL DEFAULT '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_orders`
--

INSERT INTO `nv4_shops_orders` VALUES
(1, 'S000001', 'vi', 'Nguyễn Thị Huế nguyễn Thị Huế', 'believe.in.love135@gmail.com', '01234', '', 1, 0, 0, 0, 'VND', '270000', 1432624627, 0, '127.0.0.1', 1, 0, 0, 0), 
(2, 'S000002', 'vi', 'admin', 'a@gmail.com', '1234', '', 1, 0, 0, 0, 'VND', '340000', 1432630990, 0, '127.0.0.1', 1, 0, 0, 0), 
(3, 'S000003', 'vi', 'admin', 'admin@gmail.com', '1235', '', 1, 0, 0, 0, 'VND', '190000', 1432631815, 0, '127.0.0.1', 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders_id`
--

DROP TABLE IF EXISTS `nv4_shops_orders_id`;
CREATE TABLE `nv4_shops_orders_id` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `proid` mediumint(9) NOT NULL,
  `num` mediumint(9) NOT NULL,
  `price` int(11) NOT NULL,
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`order_id`,`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_orders_id`
--

INSERT INTO `nv4_shops_orders_id` VALUES
(1, 1, 3, 1, 100000, 0), 
(2, 1, 4, 1, 170000, 0), 
(3, 2, 4, 2, 170000, 0), 
(4, 3, 1, 1, 190000, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders_id_group`
--

DROP TABLE IF EXISTS `nv4_shops_orders_id_group`;
CREATE TABLE `nv4_shops_orders_id_group` (
  `order_i` int(11) NOT NULL,
  `group_id` mediumint(8) NOT NULL,
  UNIQUE KEY `orderid` (`order_i`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_orders_shipping`
--

DROP TABLE IF EXISTS `nv4_shops_orders_shipping`;
CREATE TABLE `nv4_shops_orders_shipping` (
  `id` tinyint(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` tinyint(11) unsigned NOT NULL,
  `ship_name` varchar(255) NOT NULL,
  `ship_phone` varchar(25) NOT NULL,
  `ship_location_id` mediumint(8) unsigned NOT NULL,
  `ship_address_extend` varchar(255) NOT NULL,
  `ship_shops_id` tinyint(3) unsigned NOT NULL,
  `ship_carrier_id` tinyint(3) unsigned NOT NULL,
  `weight` float NOT NULL DEFAULT '0',
  `weight_unit` char(20) NOT NULL DEFAULT '',
  `ship_price` float NOT NULL DEFAULT '0',
  `ship_price_unit` char(3) NOT NULL DEFAULT '',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_payment`
--

DROP TABLE IF EXISTS `nv4_shops_payment`;
CREATE TABLE `nv4_shops_payment` (
  `payment` varchar(100) NOT NULL,
  `paymentname` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  `images_button` varchar(255) NOT NULL,
  PRIMARY KEY (`payment`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_point`
--

DROP TABLE IF EXISTS `nv4_shops_point`;
CREATE TABLE `nv4_shops_point` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `point_total` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_point_history`
--

DROP TABLE IF EXISTS `nv4_shops_point_history`;
CREATE TABLE `nv4_shops_point_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL,
  `point` int(11) NOT NULL DEFAULT '0',
  `time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_point_queue`
--

DROP TABLE IF EXISTS `nv4_shops_point_queue`;
CREATE TABLE `nv4_shops_point_queue` (
  `order_id` int(11) NOT NULL,
  `point` mediumint(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_review`
--

DROP TABLE IF EXISTS `nv4_shops_review`;
CREATE TABLE `nv4_shops_review` (
  `review_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `sender` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `rating` int(1) NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`review_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_rows`
--

DROP TABLE IF EXISTS `nv4_shops_rows`;
CREATE TABLE `nv4_shops_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` int(11) NOT NULL DEFAULT '0',
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `product_code` varchar(255) NOT NULL DEFAULT '',
  `product_number` int(11) NOT NULL DEFAULT '0',
  `product_price` float NOT NULL DEFAULT '0',
  `price_config` text NOT NULL,
  `money_unit` char(3) NOT NULL,
  `product_unit` int(11) NOT NULL,
  `product_weight` float NOT NULL DEFAULT '0',
  `weight_unit` char(20) NOT NULL DEFAULT '',
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  `homeimgfile` varchar(255) NOT NULL DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `homeimgalt` varchar(255) NOT NULL,
  `otherimage` text NOT NULL,
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `gift_from` int(11) unsigned NOT NULL,
  `gift_to` int(11) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(255) NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_sell` mediumint(8) NOT NULL DEFAULT '0',
  `showprice` tinyint(2) NOT NULL DEFAULT '0',
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_hometext` text NOT NULL,
  `vi_bodytext` mediumtext NOT NULL,
  `vi_gift_content` text NOT NULL,
  `vi_address` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `listcatid` (`listcatid`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_rows`
--

INSERT INTO `nv4_shops_rows` VALUES
(1, 6, 1, 1432363521, 1432365563, 1, 1432363521, 0, 2, 'V01', 19, '100000', '', 'VND', 1, '20', 'g', 0, '2015_05/maya-dam-maxi-sang-trong-hoa-cao-cap-bm12-1m4g3-dbc487_simg_d0daf0_800x1200_max.jpg', 1, 'Váy Maxi sang trọng', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 11, 0, 0, 1, 1, 'Đầm Maxi sang trọng', 'Dam-Maxi-sang-trong', 'Đầm maxi thời trang', '<span style=\"font-size:14px;\"><span style=\"font-family: arial,helvetica,sans-serif;\">Mang đến bạn bộ sưu tập maxi phối thời trang, cao cấp và cá tính thích hợp cho bạn trong những buổi dạ tiệc hay vui chơi, dạo phố.<br  />Phong cách free stlye phù hợp cho cuộc sống năng động hằng ngày</span></span><p><span style=\"font-size:14px;\"><span style=\"font-family: arial,helvetica,sans-serif;\">Thích hợp để làm quà tặng cho ngườii thân cũng như bạn bè.</span></span></p>', '', ''), 
(2, 6, 1, 1432365534, 1432365970, 1, 1432365534, 0, 2, 'V02', 50, '100000', '', 'VND', 1, '250', 'g', 0, '2015_05/dam-cao-cap.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 1, 0, 0, 0, 1, 'Đầm maxi họa tiết', 'Dam-maxi-hoa-tiet', 'đầm maxi sang trọng', '<a href=\"https://www.sendo.vn/dam-maxi.htm\">Đầm maxi</a> họa tiết <a href=\"https://www.sendo.vn/cao-cap.htm\">cao cấp</a> ( hàng nhập cao cấp )Size S, M, L<br  />Chất liệu: voan lụa mịn đẹp, <a href=\"https://www.sendo.vn/hoa-tiet.htm\">họa tiết</a> sang trọng, eo bo thun, hàng chất giống hình 100% nhé các nàng!<br  /><br  /><img alt=\"Hàng nhập cao cấp - Đầm maxi họa tiết cao cấp 2\" src=\"https://media3.sendo.vn/img1/2015/3_22/hang-nhap-cao-cap-dam-maxi-hoa-tiet-cao-cap-1m4G3-dammaxihoatietcaocap1_2kgkktril7mhm_simg_d0daf0_800x1200_max.jpg\" /><br  /><br  /><img alt=\"Hàng nhập cao cấp - Đầm maxi họa tiết cao cấp 3\" src=\"https://media3.sendo.vn/img1/2015/3_22/hang-nhap-cao-cap-dam-maxi-hoa-tiet-cao-cap-1m4G3-dammaxihoatietcaocap2_2kgkkt5saqrg4_simg_d0daf0_800x1200_max.jpg\" /><br  /><br  /><img alt=\"Hàng nhập cao cấp - Đầm maxi họa tiết cao cấp 4\" src=\"https://media3.sendo.vn/img1/2015/3_22/hang-nhap-cao-cap-dam-maxi-hoa-tiet-cao-cap-1m4G3-dammaxihoatietcaocap3_2kgkktelfqn3d_simg_d0daf0_800x1200_max.jpg\" /><br  />&nbsp;', '', ''), 
(3, 7, 1, 1432366714, 1432366740, 1, 1432366714, 0, 2, 'V03', 14, '50000', '', 'VND', 1, '250', 'g', 0, '2015_05/chan-vay-cong-so.jpg', 1, 'Chân Váy Công Sở', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 4, 0, 0, 1, 1, 'Chân Váy Công Sở', 'Chan-Vay-Cong-So', 'chân váy công sở', '<span style=\"margin: 0px; padding: 0px; font-size: 18px;\"><span style=\"margin: 0px; padding: 0px; font-family: &#039;times new roman&#039;, times, serif;\">Kiểu dáng: <u><a href=\"https://www.sendo.vn/chan-vay-cong-so.htm\">chân váy công sở</a> </u>ôm body gợi cảm.</span></span><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: justify; background-color: rgb(242, 242, 242);\"><span style=\"margin: 0px; padding: 0px; font-size: 18px;\"><span style=\"margin: 0px; padding: 0px; font-family: &#039;times new roman&#039;, times, serif;\">- Trọng lượng: 250g</span></span></p><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: justify; background-color: rgb(242, 242, 242);\"><span style=\"margin: 0px; padding: 0px; font-size: 18px;\"><span style=\"margin: 0px; padding: 0px; font-family: &#039;times new roman&#039;, times, serif;\">- Form Ôm Tinh Tế, Chất Liệu Tuyết Mưa Đẹp – Tôn Dáng Cùng Phong Cách Công Sở Thanh Lịch.&nbsp;</span></span></p><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: center;\"><a href=\"https://ban.sendo.vn/product\" style=\"margin: 0px; padding: 0px; color: rgb(0, 0, 0); text-decoration: none;\"><span style=\"margin: 0px; padding: 0px; font-family: &#039;times new roman&#039;, times, serif;\"><span style=\"margin: 0px; padding: 0px; font-size: 18px;\"><img alt=\"BM402 Chân Váy Công Sở Tuyết Mưa thời trang 1\" src=\"https://media3.sendo.vn/img1/2015/4_7/bm402-chan-vay-cong-so-tuyet-mua-thoi-trang-1m4G3-958d7f.jpg\" style=\"border-style: none; margin: 0px; padding: 0px; max-width: 670px; height: 450px; width: 660px;\" /></span></span></a></p><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: center;\"><span style=\"margin: 0px; padding: 0px; font-family: &#039;times new roman&#039;, times, serif;\"><span style=\"margin: 0px; padding: 0px; font-size: 18px;\">-&nbsp;<a href=\"https://www.sendo.vn/chan-vay.htm\">Chân Váy</a> Công Sở Tuyết Mưa&nbsp;thiết kế form ôm body&nbsp;tôn lên phong cách thời trang thanh lịch, tinh tế của bạn gái.</span></span></p><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: center;\">&nbsp;</p><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: center;\"><a href=\"https://ban.sendo.vn/product\" style=\"margin: 0px; padding: 0px; color: rgb(0, 0, 0); text-decoration: none;\"><span style=\"margin: 0px; padding: 0px; font-family: &#039;times new roman&#039;, times, serif;\"><span style=\"margin: 0px; padding: 0px; font-size: 18px;\"><img alt=\"BM402 Chân Váy Công Sở Tuyết Mưa thời trang 2\" src=\"https://media3.sendo.vn/img1/2015/4_7/bm402-chan-vay-cong-so-tuyet-mua-thoi-trang-1m4G3-9b115b.jpg\" style=\"border-style: none; margin: 0px; padding: 0px; max-width: 670px; height: 701px; width: 660px;\" /></span></span></a></p><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: center;\">&nbsp;</p><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: center;\"><span style=\"margin: 0px; padding: 0px; color: rgb(255, 97, 0); text-decoration: none; font-family: &#039;times new roman&#039;, times, serif;\"><span style=\"margin: 0px; padding: 0px; font-size: 18px;\"><a href=\"https://ban.sendo.vn/product\" style=\"margin: 0px; padding: 0px; color: rgb(255, 97, 0); text-decoration: none;\"><img alt=\"BM402 Chân Váy Công Sở Tuyết Mưa thời trang 3\" src=\"https://media3.sendo.vn/img1/2015/4_7/bm402-chan-vay-cong-so-tuyet-mua-thoi-trang-1m4G3-13e1ad.jpg\" style=\"border-style: none; margin: 0px; padding: 0px; max-width: 670px; height: 737px; width: 660px;\" /></a></span></span></p><p>&nbsp;</p><p style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &#039;Open Sans&#039;; font-size: 15px; line-height: 30px; text-align: justify; background-color: rgb(242, 242, 242);\">&nbsp;</p>', '', ''), 
(4, 7, 1, 1432367089, 1432367089, 1, 1432367089, 0, 2, 'S000004', 17, '50000', '', 'VND', 1, '300', 'g', 0, '2015_05/chan-vay-caro.jpg', 1, 'chân váy caro', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 2, 0, 0, 3, 1, 'Chân váy caro', 'Chan-vay-caro', 'chân váy caro', '<div class=\"content_tab active\" id=\"pr-detail-inf\" itemprop=\"description\">&nbsp;<p style=\"margin: 0px 0px 10px; color: rgb(136, 136, 136); font-family: &#039;Open Sans&#039;, Helvetica, Arial, sans-serif; font-size: 12px; line-height: 20px; text-align: center;\"><span style=\"text-decoration: underline;\">Thông Tin Sản Phẩm :</span></p><p style=\"margin: 0px 0px 10px; color: rgb(136, 136, 136); font-family: &#039;Open Sans&#039;, Helvetica, Arial, sans-serif; font-size: 12px; line-height: 20px; text-align: center;\">Tên Sản Phẩm : &nbsp;<strong><a href=\"https://www.sendo.vn/chan-vay.htm\">CHÂN VÁY</a> CARO CÀI NÚT TRƯỚC</strong>&nbsp;- 90 - CV</p><p style=\"margin: 0px 0px 10px; color: rgb(136, 136, 136); font-family: &#039;Open Sans&#039;, Helvetica, Arial, sans-serif; font-size: 12px; line-height: 20px; text-align: center;\">Màu : CARO ĐEN TRẮNG</p><p style=\"margin: 0px 0px 10px; color: rgb(136, 136, 136); font-family: &#039;Open Sans&#039;, Helvetica, Arial, sans-serif; font-size: 12px; line-height: 20px; text-align: center;\">Chất liệu : KAKI NHUNG</p><p style=\"margin: 0px 0px 10px; color: rgb(136, 136, 136); font-family: &#039;Open Sans&#039;, Helvetica, Arial, sans-serif; font-size: 12px; line-height: 20px; text-align: center;\">Size :&nbsp;</p><table style=\"max-width: 100%; border-collapse: collapse; border-spacing: 0px; color: rgb(136, 136, 136); font-family: &#039;open sans&#039;; font-size: 15px; height: auto; line-height: 30px; margin: 0px; padding: 0px; text-align: justify; width: 660px;\">	<tbody>		<tr>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Màu sắc</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Size</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Chất liệu vải</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Vòng eo (cm)</span></span></p>			</td>			<td style=\"width: 98px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Vòng mông (cm)</span></span></p>			</td>			<td style=\"width: 84px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Chiều dài (cm)</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Co giãn</span></span></p>			</td>		</tr>		<tr>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Caro trắng đen</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">M</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Kaki nhung</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">66-70</span></span></p>			</td>			<td style=\"width: 98px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">84-88</span></span></p>			</td>			<td style=\"width: 84px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">50</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">Ít</span></span></p>			</td>		</tr>		<tr>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">L</span></span></p>			</td>			<td style=\"width: 91px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">70-74</span></span></p>			</td>			<td style=\"width: 98px;\">			<p style=\"margin: 0px 0px 10px; text-align: center;\"><span style=\"font-size: 14px;\"><span style=\"font-family: arial, helvetica, sans-serif;\">88-92</span></span></p>			</td>		</tr>	</tbody></table><p style=\"margin: 0px 0px 10px; color: rgb(136, 136, 136); font-family: &#039;Open Sans&#039;, Helvetica, Arial, sans-serif; font-size: 12px; line-height: 20px; text-align: center;\">&nbsp;</p><p style=\"margin: 0px 0px 10px; color: rgb(136, 136, 136); font-family: &#039;Open Sans&#039;, Helvetica, Arial, sans-serif; font-size: 12px; line-height: 20px; text-align: center;\"><span style=\"color: rgb(0, 0, 0); font-family: arial, helvetica, sans-serif; font-size: 14px;\">Kiểu dáng: chân váy caro có 2 túi trước cài nút trước.</span></p><p style=\"margin: 0px 0px 10px; color: rgb(136, 136, 136); font-family: &#039;Open Sans&#039;, Helvetica, Arial, sans-serif; font-size: 12px; line-height: 20px; text-align: center;\"><span style=\"color: rgb(0, 0, 0); font-family: arial, helvetica, sans-serif; font-size: 14px;\"><img alt=\"chan vay caro, chân váy,\" src=\"https://media3.sendo.vn/img1/2014/12_14/chan-vay-caro-cai-nut-truoc-1m4G3-a1koreanasianfashionshoppingmall00006927_2k2asshp3lj7q.jpg\" style=\"max-width: 100%; height: 500px; vertical-align: middle; width: 500px;\" /><img alt=\"chan vay caro cai nut, \" src=\"https://media3.sendo.vn/img1/2014/12_14/chan-vay-caro-cai-nut-truoc-1m4G3-c2korean-asian-fashion-shopping-mall-000_2k2assredkhdm.jpg\" style=\"max-width: 100%; height: 801px; vertical-align: middle; width: 600px;\" /><img alt=\"chan vay caro cai nút\" src=\"https://media3.sendo.vn/img1/2014/12_14/chan-vay-caro-cai-nut-truoc-1m4G3-c3korean-asian-fashion-shopping-mall-000_2k2asshkn7t1p.jpg\" style=\"max-width: 100%; height: 693px; vertical-align: middle; width: 600px;\" /><img alt=\"chan vay caro cai nut,\" src=\"https://media3.sendo.vn/img1/2014/12_14/chan-vay-caro-cai-nut-truoc-1m4G3-c4korean-asian-fashion-shopping-mall-000_2k2assmhaa4a6.jpg\" style=\"max-width: 100%; height: 677px; vertical-align: middle; width: 600px;\" /><img alt=\"chan vay caro cai nut, \" src=\"https://media3.sendo.vn/img1/2014/12_14/chan-vay-caro-cai-nut-truoc-1m4G3-c5korean-asian-fashion-shopping-mall-000_2k2asshtj4sna.jpg\" style=\"max-width: 100%; height: 690px; vertical-align: middle; width: 600px;\" /><img alt=\"chan vay caro cai nut,\" src=\"https://media3.sendo.vn/img1/2014/12_14/chan-vay-caro-cai-nut-truoc-1m4G3-c1korean-asian-fashion-shopping-mall-000_2k2asshe9rlh4.jpg\" style=\"max-width: 100%; height: 486px; vertical-align: middle; width: 600px;\" /></span></p></div>', '', ''), 
(5, 10, 1, 1432367366, 1432367366, 1, 1432367366, 0, 2, 'S000005', 30, '0', '', 'VND', 1, '220', 'g', 0, '2015_05/ao-so-mi-voan-lua.jpg', 1, 'áo somi lụa đẹp', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'Áo sơmi lụa', 'Ao-somi-lua', 'áo somi lụa đẹp', '<div class=\"breadcrumb_detail util-clearfix\" itemprop=\"breadcrumb\"><div class=\"br first\"><a href=\"https://www.sendo.vn/\" rel=\"v:url\" title=\"Sendo\">Sendo.vn </a></div><div class=\"br first link\"><a href=\"https://www.sendo.vn/sitemap/\" rel=\"v:url\" target=\"_blank\" title=\"Danh mục sản phẩm\">Danh mục sản phẩm</a></div><div class=\"br \"><a alt=\"Thời trang nữ\" href=\"https://www.sendo.vn/thoi-trang-nu/\" rel=\"v:url\" title=\"Thời trang nữ\">Thời trang nữ</a></div><div class=\"br \"><a alt=\"Áo nữ\" href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/\" rel=\"v:url\" title=\"Áo nữ\">Áo nữ</a></div><div class=\"br end\"><a alt=\"Áo sơ mi công sở\" href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/ao-so-mi-cong-so/\" rel=\"v:url\" title=\"Áo sơ mi công sở\">Áo sơ mi công sở</a></div></div><div class=\"left-col left_detail\" itemscope=\"\" itemtype=\"http://schema.org/Product\"><div class=\"box_img_attr \"><div class=\"box_img_product hoa-sen\">&nbsp;</div></div></div><div class=\"box_img_product hoa-sen\"><div class=\"bg-l\"><div class=\"zoomWrapper\" style=\"height:320px;width:320px;\"><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200\" data-title=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200\" data-zoom-image=\"https://media3.sendo.vn/img/2014/6_15/somi_voan_ren_2j5kla3a7pj44.jpg\" height=\"320\" id=\"zoom_detail\" itemprop=\"image\" src=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-somi_voan_ren_2j5kla3a7pj44_simg_5acd92_320x320_maxb.jpg\" style=\"position: absolute;\" width=\"320\" /></div></div><div class=\"zoom-desc\" id=\"gallery_01\"><a data-image=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-somi_voan_ren_2j5kla3a7pj44_simg_5acd92_320x320_maxb.jpg\" data-zoom-image=\"https://media3.sendo.vn/img/2014/6_15/somi_voan_ren_2j5kla3a7pj44.jpg\" title=\"\"> <img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200\" class=\"lazydetail\" height=\"50\" id=\"img_01\" src=\"https://media3.sendo.vn/img/2014/6_15/somi_voan_ren_2j5kla3a7pj44_simg_02d57e_50x50_maxb.jpg\" width=\"50\" /> </a></div><div class=\"box-fb-go social\"><div class=\"for-fb\"><div class=\"fb-like fb_iframe_widget\" data-action=\"like\" data-href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/ao-so-mi-cong-so/ao-so-mi-voan-lua-min-ren-het-hot-co-ao-116200-710081/\" data-layout=\"button_count\" data-share=\"true\" data-show-faces=\"false\">&nbsp;</div></div><div class=\"for-go\">&nbsp;</div></div></div><div class=\"box_attr_product\"><div class=\"name_product item\"><h1><a class=\"fn\" href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/ao-so-mi-cong-so/ao-so-mi-voan-lua-min-ren-het-hot-co-ao-116200-710081/\" itemprop=\"name\" title=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 - 116200\">áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 - 116200</a></h1></div><div class=\"rating_buy_view hreview-aggregate\"><div class=\"rating\"><a href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/ao-so-mi-cong-so/ao-so-mi-voan-lua-min-ren-het-hot-co-ao-116200-710081/#tabs_rate\" rel=\"nofollow\" title=\"\"><span class=\"bg_star\"><span class=\"rstar\" style=\"width:100%;\">&nbsp;</span> </span> </a> <strong> 100% </strong> <a class=\"dg \" href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/ao-so-mi-cong-so/ao-so-mi-voan-lua-min-ren-het-hot-co-ao-116200-710081/#tabs_rate\" rel=\"nofollow\" title=\"\">(21 đánh giá) </a></div><div class=\"buyview\">﻿<div class=\"separator\">&nbsp;</div><div class=\"buy\" title=\"Lượt mua\"><strong>73</strong> lượt mua</div><div class=\"separator\">&nbsp;</div><div class=\"view\" title=\"Lượt xem\"><strong>24,032</strong> lượt xem</div></div></div><div class=\"price_wirehouse_shopinfo\" itemprop=\"offers\" itemscope=\"\" itemtype=\"http://schema.org/Offer\"><div class=\"price\"><div class=\"current_price\" itemprop=\"price\">250,000 VNĐ</div><div class=\"old_price\">Giá cũ: 357,000 VNĐ</div><div class=\"update_price\" title=\"Ngày cập nhật giá\">3 ngày trước</div></div><div class=\"wirehouse\"><strong>Kho hàng :</strong> Hồ Chí Minh</div><div class=\"shopinfo\"><strong>Thông tin shop:</strong><img alt=\"\" height=\"17\" src=\"https://static.scdn.vn/images/ecom/img-thongtinshop.gif\" title=\"\" width=\"35\" /></div></div><div class=\"loyaltyDetail\"><p class=\"desLoyaltyDetail\" data-original-title=\"Là số điểm SEN bạn được thưởng khi mua đơn hàng này. Tích điểm để dùng thay cho tiền khi mua hàng trên Sendo.vn\" data-target=\"#modalPointSen\" data-toggle=\"modal\" title=\"\">Tặng ngay <span class=\"icLoyaltyDetail\">&nbsp;</span> <span class=\"pointSen\"> + 5,000</span></p></div><div class=\"grab-taxi-box\"><p>Tặng voucher <img alt=\"grabtaxi\" src=\"https://static.scdn.vn/images/ecom/grabtaxi-icon.png\" /> <b><i>Grab</i>taxi</b> khi mua sản phẩm này</p></div><form class=\"ng-pristine ng-valid\" id=\"product_detail_infomation\" method=\"POST\"><div class=\"box-attrs\"><div class=\"attrs est-shipping-fee\"><div class=\"attrs\"><label>Vận chuyển<br  />toàn quốc: </label><div class=\"vc-info\">Giao hàng đến <a class=\"usr_locale\" data-target=\"#modalShipping\" data-toggle=\"modal\" title=\"chọn nhà vận chuyển\"> <strong> Hồ Chí Minh </strong> </a> bằng <a data-target=\"#modalShipping\" data-toggle=\"modal\" title=\"chọn nhà vận chuyển\"> <strong class=\"usr_carrier\">Giao hàng nhanh</strong> </a> với phí: <strong>17,000 VNĐ</strong><p class=\"new_carrier_time\">Thời gian giao hàng 2 ngày.</p><p class=\"ic-ship\">Shop <strong>MIỄN PHÍ VẬN CHUYỂN</strong> cho đơn hàng từ <strong>700,000 VNĐ</strong> trở lên</p></div></div></div><div class=\"attrs\"><label class=\"label\">Màu sắc: </label><div class=\"attrs-item option\"><label class=\"check\" title=\"Trắng\"><input checked=\"checked\" name=\"options[19270582][]\" type=\"radio\" value=\"28430427\" /><span class=\"label\" style=\"background-color:rgb(255, 255, 255);\">&nbsp;</span></label></div></div><div class=\"attrs\"><label class=\"label\">Kích thước: </label><div class=\"attrs-item option\"><label title=\"\"><input name=\"options[19270584][]\" type=\"radio\" value=\"28430429\" /><span class=\"label\">S</span></label><label title=\"\"><input name=\"options[19270584][]\" type=\"radio\" value=\"28430430\" /><span class=\"label\">M</span></label><label title=\"\"><input name=\"options[19270584][]\" type=\"radio\" value=\"28430431\" /><span class=\"label\">L</span></label></div></div><div class=\"attrs\"><label class=\"label\">Chất liệu: </label><div class=\"attrs-item \">Voan</div></div><div class=\"attrs\"><label class=\"label\">Kiểu dáng: </label><div class=\"attrs-item \">Dài tay</div></div><div class=\"attrs\"><label class=\"label\">Xuất xứ: </label><div class=\"attrs-item \" itemprop=\"manufacturer\">Hàn Quốc</div></div><div class=\"attrs\"><label class=\"label\">Kiểu vạt áo: </label><div class=\"attrs-item \">Khác</div></div><div class=\"attrs quality\"><label>Số lượng: </label> <input name=\"qty\" type=\"text\" value=\"1\" /></div></div></form></div><div class=\"box-attrs\"><div class=\"attrs quality\">&nbsp;</div></div><div class=\"buybtn\">&nbsp;</div><div class=\"box_img_attr \"><div class=\"box_attr_product\"><form class=\"ng-pristine ng-valid\" id=\"product_detail_infomation\" method=\"POST\"><div class=\"buybtn\"><div class=\"overflow_box\"><a class=\"fav\" title=\"Thêm vào danh sách yêu thích\"><i>&nbsp;</i> Thêm vào danh sách yêu thích (<span class=\"wl-num\">0</span>) </a><div class=\"img-tmp\"><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200\" class=\"imgtodrag\" height=\"200\" src=\"https://media3.sendo.vn/img/2014/6_15/somi_voan_ren_2j5kla3a7pj44_simg_ce2f5e_200x200_maxb.jpg\" title=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200\" width=\"200\" /></div></div></div><div class=\"box-hoa-sen\"><h2>shop hoa sen</h2><span>Trả hàng - hoàn tiền khi không vừa ý với sản phẩm .</span> <span>Nhận hàng trong thời gian nhanh nhất. </span> <span class=\"shopLoyalty\">Được thưởng điểm SEN khi mua hàng. </span> <a class=\"view-more\" href=\"https://www.sendo.vn/huong-dan/shop-hoa-sen/\" title=\"Xem thêm\">Xem thêm</a></div></form></div><div class=\"cls\">&nbsp;</div></div><div class=\"help_btn_detail\"><div class=\"PagingWrapper\"><div class=\"PagingControl\"><div class=\"CenterWrapper\"><a class=\"buy_step\" href=\"https://www.sendo.vn/huong-dan/huong-dan-mua-hang/\" target=\"_blank\" title=\"Các bước mua hàng\">các bước mua hàng</a> <a class=\"howshipping\" href=\"https://www.sendo.vn/huong-dan/giao-hang-toan-quoc/\" target=\"_blank\" title=\"Phương thức vận chuyển\"> Phương thức vận chuyển</a> <a class=\"howpay\" href=\"https://www.sendo.vn/huong-dan/cach-thuc-thanh-toan/\" target=\"_blank\" title=\"Cách thức thanh toán\"> Cách thức thanh toán </a></div></div></div></div><div class=\"tab_li tab-scroll\"><ul>	<li class=\"tabs shop_border_color_hover active\"><a href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/ao-so-mi-cong-so/ao-so-mi-voan-lua-min-ren-het-hot-co-ao-116200-710081/#pr-detail-inf\" title=\"Chi tiết sản phẩm\">Chi tiết sản phẩm</a></li>	<li class=\"tabs shop_border_color_hover\"><a href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/ao-so-mi-cong-so/ao-so-mi-voan-lua-min-ren-het-hot-co-ao-116200-710081/#tabs_rate\" title=\"Đánh giá/phản hồi\">Đánh giá/phản hồi <span class=\"tabs_rate_total shop_color\">(21)</span></a></li>	<li class=\"tabs shop_border_color_hover\"><a href=\"https://www.sendo.vn/thoi-trang-nu/ao-nu/ao-so-mi-cong-so/ao-so-mi-voan-lua-min-ren-het-hot-co-ao-116200-710081/#hoi_dap\" title=\"Hỏi đáp\">Hỏi đáp <span class=\"shop_color\" id=\"qna_count\">(8)</span></a></li></ul></div><p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(51, 51, 51); font-family: arial; line-height: 12px; text-align: center; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</p><p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(51, 51, 51); font-family: arial; line-height: 12px; text-align: center; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: large; vertical-align: baseline; color: rgb(255, 0, 0); background: transparent;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 18px; vertical-align: baseline; background: transparent;\"><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 1\" src=\"https://media3.sendo.vn/img1/2015/4_2/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-94aacf_simg_d0daf0_800x1200_max.gif\" /></strong></span></p><p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(51, 51, 51); font-family: arial; line-height: 12px; text-align: center; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-size: large; color: rgb(255, 0, 0); background-color: rgb(255, 255, 0);\"><strong>áo <a href=\"https://www.sendo.vn/so-mi-voan.htm\">sơ mi voan</a> <a href=\"https://www.sendo.vn/lua.htm\">lụa</a> mịn+ren hết hột cổ áo 116200---250.000 VNĐ</strong></span></p><p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(51, 51, 51); font-family: arial; line-height: 12px; text-align: center; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: large; vertical-align: baseline; color: rgb(255, 0, 0); background: transparent;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 18px; vertical-align: baseline; background: transparent;\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: medium; vertical-align: baseline; color: rgb(51, 51, 51); font-family: Helvetica, Arial, sans-serif; font-weight: normal; line-height: 17px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">Size S, M, L</span></span><br style=\"box-sizing: border-box;\" /><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: medium; vertical-align: baseline; color: rgb(51, 51, 51); font-family: Helvetica, Arial, sans-serif; font-weight: normal; line-height: 17px; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; background: transparent;\">Chất liệu: <a href=\"https://www.sendo.vn/voan-lua.htm\">voan lụa</a> mịn , phối ren đính hạt cực xinh, hàng chất cực đẹp nhé các nàng!</span></span></strong></span></p><p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(51, 51, 51); font-family: arial; line-height: 12px; text-align: center; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</p><p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 12px; vertical-align: baseline; color: rgb(51, 51, 51); font-family: arial; line-height: 12px; text-align: center;\">&nbsp;</p><span style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: large; vertical-align: baseline; background-color: transparent; color: rgb(255, 0, 0); background-position: initial initial; background-repeat: initial initial;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 18px; vertical-align: baseline; background-color: transparent; background-position: initial initial; background-repeat: initial initial;\"><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 2\" src=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-so_mi_voan_lua_min_ren_het_hot_co_ao_116_2j5kl973hn9r7_simg_d0daf0_800x1200_max.jpg\" /><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 3\" src=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-so_mi_voan_lua_min_ren_het_hot_co_ao_116_2j5kl9ajj2ahj_simg_d0daf0_800x1200_max.jpg\" /><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 4\" src=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-so_mi_voan_lua_min_ren_het_hot_co_ao_116_2j5kl9e3kthmf_simg_d0daf0_800x1200_max.jpg\" /><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 5\" src=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-so_mi_voan_lua_min_ren_het_hot_co_ao_116_2j5kl9hgaq9c7_simg_d0daf0_800x1200_max.jpg\" /><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 6\" src=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-so_mi_voan_lua_min_ren_het_hot_co_ao_116_2j5kl9knel0g1_simg_d0daf0_800x1200_max.jpg\" /><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 7\" src=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-so_mi_voan_lua_min_ren_het_hot_co_ao_116_2j5kl9phgegc7_simg_d0daf0_800x1200_max.jpg\" /><img alt=\"áo sơ mi voan lụa mịn+ren hết hột cổ áo 116200 8\" src=\"https://media3.sendo.vn/img/2014/6_15/ao-so-mi-voan-lua-minren-het-hot-co-ao-116200-1m4G3-somi_voan_ren_2j5kla3a7pj44_simg_d0daf0_800x1200_max.jpg\" /></strong></span>', '', ''), 
(6, 10, 1, 1432367846, 1432370007, 1, 1432367846, 0, 2, 'S000006', 15, '0', '', 'VND', 1, '300', 'g', 0, '2015_05/ao-so-mi-voan.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 8, 0, 0, 0, 1, 'Áo sơ mi voan phối tay ren', 'Ao-so-mi-voan-phoi-tay-ren', '<h1><span style=\"font-size:14px;\">Áo sơ mi voan</span></h1>', '&nbsp;<p style=\"text-align: center;\"><span style=\"color: rgb(255, 0, 255);\"><strong><span style=\"font-size: large;\">MÃ SP: 15379</span></strong></span></p><p style=\"text-align: center;\"><strong><span style=\"font-size: large;\">CHẤT VOAN CÁT MỀM MẠI PHỐI REN Y HÌNH</span></strong></p><img alt=\"HÀNG NHẬP CAO CẤP---Áo sơ mi voan phối tay ren 15379 2\" src=\"https://media3.sendo.vn/img1/2015/3_31/hang-nhap-cao-cap-ao-so-mi-voan-phoi-tay-ren-15379-1m4G3-15379smlxl1_2khsrk67h2s7k_simg_d0daf0_800x1200_max.jpg\" style=\"display: block; margin-left: auto; margin-right: auto;\" /><img alt=\"HÀNG NHẬP CAO CẤP---Áo sơ mi voan phối tay ren 15379 3\" src=\"https://media3.sendo.vn/img1/2015/3_31/hang-nhap-cao-cap-ao-so-mi-voan-phoi-tay-ren-15379-1m4G3-15379smlxl2_2khsrla7cn26e_simg_d0daf0_800x1200_max.jpg\" style=\"display: block; margin-left: auto; margin-right: auto;\" /><img alt=\"HÀNG NHẬP CAO CẤP---Áo sơ mi voan phối tay ren 15379 4\" src=\"https://media3.sendo.vn/img1/2015/3_31/hang-nhap-cao-cap-ao-so-mi-voan-phoi-tay-ren-15379-1m4G3-15379smlxl3_2khsrlf5kgaj4_simg_d0daf0_800x1200_max.jpg\" style=\"display: block; margin-left: auto; margin-right: auto;\" /><img alt=\"HÀNG NHẬP CAO CẤP---Áo sơ mi voan phối tay ren 15379 5\" src=\"https://media3.sendo.vn/img1/2015/3_31/hang-nhap-cao-cap-ao-so-mi-voan-phoi-tay-ren-15379-1m4G3-15379smlxl5_2khsrljlal2a1_simg_d0daf0_800x1200_max.jpg\" /><img alt=\"HÀNG NHẬP CAO CẤP---Áo sơ mi voan phối tay ren 15379 6\" src=\"https://media3.sendo.vn/img1/2015/3_31/hang-nhap-cao-cap-ao-so-mi-voan-phoi-tay-ren-15379-1m4G3-15379smlxl7_2khsrkotscj2p_simg_d0daf0_800x1200_max.jpg\" />', '', ''), 
(8, 11, 1, 1432605984, 1432605984, 1, 1432605984, 0, 2, 'S000008', 15, '120000', '', 'VND', 1, '200', 'g', 0, '2015_05/ao-thun-nu-4-chieu.jpg', 1, 'áo thun nữ', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 0, 0, 0, 0, 1, 'áo thun nữ họa tiết độc đáo', 'ao-thun-nu-hoa-tiet-doc-dao', 'áo thun nữ họa tiết độc đáo', '<table cellpadding=\"0\" cellspacing=\"0\" class=\"technical\">	<tbody>		<tr class=\"data even\">			<td class=\"padding_right\">&nbsp;</td>			<td>&nbsp;</td>		</tr>		<tr class=\"data odd\">			<td class=\"padding_right\"><span class=\"label name\">Bảo hành:</span> Không có</td>			<td><span class=\"label name\">&nbsp;Nguồn gốc:</span> Chính hãng</td>		</tr>		<tr class=\"data odd\">			<td class=\"padding_right\"><span class=\"name\">Kiểu dáng:</span> Cộc tay,</td>			<td><span class=\"name\">Cổ áo:</span> Cổ tròn</td>		</tr>		<tr class=\"data even\">			<td class=\"padding_right\"><span class=\"name\">Kích cỡ:</span> Size S</td>			<td><span class=\"name\">Chất liệu:</span> <a class=\"text_link\" href=\"http://www.vatgia.com/s/thun\">Thun</a></td>		</tr>		<tr class=\"data odd\">			<td class=\"padding_right\">&nbsp;</td>			<td class=\"name\" colspan=\"2\">&nbsp;</td>		</tr>	</tbody></table>', '', ''), 
(9, 13, 1, 1432606317, 1432629809, 1, 1432606317, 0, 2, 'S000009', 10, '100000', '', 'VND', 1, '500', 'g', 1, '2015_05/giay-da-nu-got-vuong.jpg', 1, 'Giày da nữ gót vuông', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 1, 0, 0, 0, 1, 'Giày da nữ gót vuông', 'Giay-da-nu-got-vuong', 'Giày da nữ gót vuông', '<p><span style=\"color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; font-size: large; line-height: 18px;\"><a href=\"https://www.sendo.vn/giay-da-nu.htm\">Giày da nữ</a>, gót bọc da 5p</span></p><span style=\"color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; font-size: large; line-height: 18px;\"><img alt=\"Giày da nữ gót vuông 5p 7368 1\" src=\"https://media3.sendo.vn/img/2014/11_9/giay-da-nu-got-vuong-5p-7368-1m4G3-7368n1_2jr6k5oab3bhs_simg_d0daf0_800x1200_max.jpg\" style=\"margin: 0px auto; display: block;\" /><br  /><br  /><img alt=\"Giày da nữ gót vuông 5p 7368 2\" src=\"https://media3.sendo.vn/img/2014/11_9/giay-da-nu-got-vuong-5p-7368-1m4G3-7368n2_2jr6k66gt1atl_simg_d0daf0_800x1200_max.jpg\" style=\"margin: 0px auto; display: block;\" /><br  /><br  /><img alt=\"Giày da nữ gót vuông 5p 7368 3\" src=\"https://media3.sendo.vn/img/2014/11_9/giay-da-nu-got-vuong-5p-7368-1m4G3-7368n3_2jr6k6iir3hjj_simg_d0daf0_800x1200_max.jpg\" style=\"margin: 0px auto; display: block;\" /><br  /><br  /><img alt=\"Giày da nữ gót vuông 5p 7368 4\" src=\"https://media3.sendo.vn/img/2014/11_9/giay-da-nu-got-vuong-5p-7368-1m4G3-7368n4_2jr6k70bn5kk6_simg_d0daf0_800x1200_max.jpg\" style=\"margin: 0px auto; display: block;\" /><br  /><br  /><img alt=\"Giày da nữ gót vuông 5p 7368 5\" src=\"https://media3.sendo.vn/img/2014/11_9/giay-da-nu-got-vuong-5p-7368-1m4G3-7368n5_2jr6k79pl89qd_simg_d0daf0_800x1200_max.jpg\" style=\"margin: 0px auto; display: block;\" /></span>', '', ''), 
(10, 13, 1, 1432606522, 1432629789, 1, 1432606522, 0, 2, 'S000010', 10, '100000', '', 'VND', 2, '350', 'g', 2, '2015_05/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4g3-giaycaogotcg666hcopy_2k4etslal2erb_simg_d0daf0_800x1200_max.png', 1, 'Giày cao gót mũi nhọn màu hồng', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 1, 0, 0, 0, 1, 'Giày cao gót mũi nhọn màu hồng be quý phái', 'Giay-cao-got-mui-nhon-mau-hong-be-quy-phai', 'Giày cao gót mũi nhọn màu hồng be quý phái', '<div class=\"box-attrs\"><div class=\"attrs quality\">&nbsp;</div></div><div class=\"buybtn\">&nbsp;</div><div class=\"box_img_attr \"><div class=\"box_attr_product\"><form class=\"ng-pristine ng-valid\" id=\"product_detail_infomation\" method=\"POST\"><div class=\"buybtn\"><div class=\"overflow_box\"><a class=\"fav\" title=\"Thêm vào danh sách yêu thích\"><i>&nbsp;</i> Thêm vào danh sách yêu thích (<span class=\"wl-num\">0</span>) </a><div class=\"img-tmp\"><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H\" class=\"imgtodrag\" height=\"200\" src=\"https://media3.sendo.vn/img/2014/7_26/giaycaogot1png_2jble14eoqe22_simg_ce2f5e_200x200_maxb.png\" title=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H\" width=\"200\" /></div></div></div><div class=\"box-hoa-sen\"><h2>shop hoa sen</h2><span>Trả hàng - hoàn tiền khi không vừa ý với sản phẩm .</span> <span>Nhận hàng trong thời gian nhanh nhất. </span> <span class=\"shopLoyalty\">Được thưởng điểm SEN khi mua hàng. </span> <a class=\"view-more\" href=\"https://www.sendo.vn/huong-dan/shop-hoa-sen/\" title=\"Xem thêm\">Xem thêm</a></div></form></div><div class=\"cls\">&nbsp;</div></div><div class=\"help_btn_detail\"><div class=\"PagingWrapper\"><div class=\"PagingControl\"><div class=\"CenterWrapper\"><a class=\"buy_step\" href=\"https://www.sendo.vn/huong-dan/huong-dan-mua-hang/\" target=\"_blank\" title=\"Các bước mua hàng\">các bước mua hàng</a> <a class=\"howshipping\" href=\"https://www.sendo.vn/huong-dan/giao-hang-toan-quoc/\" target=\"_blank\" title=\"Phương thức vận chuyển\"> Phương thức vận chuyển</a> <a class=\"howpay\" href=\"https://www.sendo.vn/huong-dan/cach-thuc-thanh-toan/\" target=\"_blank\" title=\"Cách thức thanh toán\"> Cách thức thanh toán </a></div></div></div></div><div class=\"tab_li tab-scroll\"><ul>	<li class=\"tabs shop_border_color_hover active\"><a href=\"https://www.sendo.vn/thoi-trang-nu/giay-dep-nu/giay-cao-got/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-787871/#pr-detail-inf\" title=\"Chi tiết sản phẩm\">Chi tiết sản phẩm</a></li>	<li class=\"tabs shop_border_color_hover\"><a href=\"https://www.sendo.vn/thoi-trang-nu/giay-dep-nu/giay-cao-got/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-787871/#tabs_rate\" title=\"Đánh giá/phản hồi\">Đánh giá/phản hồi <span class=\"tabs_rate_total shop_color\">(14)</span></a></li>	<li class=\"tabs shop_border_color_hover\"><a href=\"https://www.sendo.vn/thoi-trang-nu/giay-dep-nu/giay-cao-got/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-787871/#hoi_dap\" title=\"Hỏi đáp\">Hỏi đáp <span class=\"shop_color\" id=\"qna_count\">(5)</span></a></li></ul></div><div style=\"text-align: center;\">&nbsp;</div><div><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Tên Sản phẩm</strong>:&nbsp;<a href=\"https://www.sendo.vn/giay-cao-got.htm\">Giày cao gót</a> mũi nhọn <a href=\"https://www.sendo.vn/mau-hong.htm\">màu hồng</a> be quý phái CG-666H</span></div><p>&nbsp;</p><p><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Kích cỡ (Size)</strong></span></p><p>&nbsp;</p><p><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Sau 1 thời gian dài bán sản phẩm chúng tôi lưu ý Quý khách khi mua hàng trực tuyến nên giảm bớt đi 1 Size. Ví dụ quý khách đi giày cỡ bình thường là 37 thì mua giày này 36 là vừa chân.&nbsp;</strong></span></p><p>&nbsp;</p><p style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px none; outline: none 0px; font-size: 12px; vertical-align: baseline; color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; line-height: 12px; text-align: center; background-image: none; background-attachment: scroll; background-size: initial; background-origin: initial; background-clip: initial; background-position: 0% 0%; background-repeat: repeat;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 13px; vertical-align: baseline; background: transparent;\"><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 1\" src=\"https://media3.sendo.vn/img1/2015/5_6/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-hang-nhap-giay-sandal-cao-got-dinh-cuom-sang-trong-cg300-1m4G3-a7df74_simg_d0daf0_800x1200_max.png\" /></strong></span></p><p>&nbsp;</p><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px none; outline: none 0px; font-size: 12px; vertical-align: baseline; color: rgb(51, 51, 51); font-family: Arial, Helvetica, sans-serif; line-height: 12px; text-align: center; background-image: none; background-attachment: scroll; background-size: initial; background-origin: initial; background-clip: initial; background-position: 0% 0%; background-repeat: repeat;\"><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 13px; vertical-align: baseline; background: transparent;\">&nbsp;</strong></span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Chất liệu:</strong>&nbsp;Da tổng hợp</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Xuất xứ:&nbsp;</strong>Hongkong</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Chiều <a href=\"https://www.sendo.vn/cao-got.htm\">cao gót</a>:</strong>&nbsp;8cm</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Kiểu dáng:&nbsp;</strong>Thiết kế dạng <a href=\"https://www.sendo.vn/giay-cao.htm\">giày cao</a> gót, kiểu dáng sang trong và nổi bật, da mềm, đi rất &nbsp;&nbsp;</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\">êm chân tạo sự thoải mái cho người đi</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\">Thiết kế với tiêu chí nhẹ nhàng, thoải mái, tôn vinh nét duyên dáng của người phụ nữ hiện</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\">đại.&nbsp;Phong cách trẻ trung, sang trọng, hiện đại, thích hợp cho phụ nữ văn phòng, nhân viên&nbsp;</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\">công sở.</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; line-height: normal; text-align: start;\">&nbsp;</strong>Hàng cao cấp chính hãng không như hàng face, nhái trên thị trường, cho nên màu sắc,</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\">kiểu dáng, chết liệu thực như hình mẫu</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"color: rgb(0, 0, 0); font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; line-height: normal; text-align: start;\">&nbsp;</strong>Shop hỗ trợ miễn phí vận chuyển cho đơn hàng này.</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\">Phương thức thanh toán trả sau: COD - Thanh toán khi nhận hàng theo địa chỉ bạn cung cấp</span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Màu sắc: Có 3 màu</strong></span></div>&nbsp;<div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 13px; vertical-align: baseline; background: transparent;\">&nbsp;</strong></span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 13px; vertical-align: baseline; background: transparent;\">&nbsp;</strong></span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px none; outline: none 0px; vertical-align: baseline; background-image: none; background-attachment: scroll; background-size: initial; background-origin: initial; background-clip: initial; background-position: 0% 0%; background-repeat: repeat;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 13px; vertical-align: baseline; background: transparent;\"><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 2\" src=\"https://media3.sendo.vn/img/2014/10_30/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-6661_2jpln7s3ncmfr_simg_d0daf0_800x1200_max.png\" style=\"display: block; margin-left: auto; margin-right: auto;\" /></strong></span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 13px; vertical-align: baseline; background: transparent;\">&nbsp;</strong></span></div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div><div style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; vertical-align: baseline; text-align: justify; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\">&nbsp;</div>&nbsp;<p style=\"box-sizing: border-box; margin: 0px; padding: 6px 0px; border: 0px none; outline: none 0px; font-size: 13px; vertical-align: baseline; line-height: normal; color: rgb(44, 43, 43); font-family: arial, verdana, tahoma; background-image: initial; background-attachment: initial; background-size: initial; background-origin: initial; background-clip: initial; background-position: initial; background-repeat: initial;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><a href=\"http://www.sendo.vn/shop/thoi-trang-han-quoc/thoi-trang-nu/giay-dep-nu/\"><strong style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; outline: 0px; font-size: 13px; vertical-align: baseline; background: transparent;\"><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 3\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-666h2jltlnkh4ispcd0daf0800x1200max_2k4eckrt284ib_simg_d0daf0_800x1200_max.png\" /></strong></a></span></p></div><p>&nbsp;</p><p><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong>Hình ảnh sản phẩm:</strong></span></p><p>&nbsp;</p><p>&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 4\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-giaycaogotcg666hcopy_2k4etslal2erb_simg_d0daf0_800x1200_max.png\" /></strong></span></p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 5\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-giaycaogotcg666h1copy_2k4ett531ojpn_simg_d0daf0_800x1200_max.png\" /></strong></span></p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 6\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-giaycaogotcg666h2copy_2k4etst9jntgd_simg_d0daf0_800x1200_max.png\" /></strong></span></p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 7\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-giaycaogotcg666h3copy_2k4ettc62g3q3_simg_d0daf0_800x1200_max.png\" /></strong></span></p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 8\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-giaycaogotcg666h4copy_2k4ett6ldee8a_simg_d0daf0_800x1200_max.png\" /></strong></span></p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 9\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-giaycaogotcg666h8copy_2k4f0070d1ec7_simg_d0daf0_800x1200_max.png\" /><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 10\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-giaycaogotcg666h9copy_2k4f01agfhf8a_simg_d0daf0_800x1200_max.png\" /></strong></span></p><p style=\"text-align: center;\">&nbsp;</p><p style=\"text-align: center;\"><span style=\"font-family: tahoma, arial, helvetica, sans-serif; font-size: medium;\"><strong style=\"font-family: verdana, geneva; font-size: medium;\"><img alt=\"Giày cao gót mũi nhọn màu hồng be quý phái CG-666H 11\" src=\"https://media3.sendo.vn/img1/2014/12_29/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4G3-giaycaogotcg666h7copy_2k4ettnpidlkl_simg_d0daf0_800x1200_max.png\" /></strong></span></p>', '', ''), 
(7, 11, 1, 1432369124, 1432369433, 1, 1432369124, 0, 2, 'S000007', 50, '120000', '', 'VND', 1, '150', 'g', 0, '2015_05/ao-thun-nu-4-chieu-xb417.jpg', 1, '', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 2, 0, 0, 0, 1, 'áo thun nữ', 'ao-thun-nu', 'áo thun nữ', '<table cellpadding=\"0\" cellspacing=\"0\" class=\"technical\">	<tbody>		<tr class=\"data even\">			<td class=\"padding_right\">&nbsp;</td>			<td>&nbsp;</td>		</tr>		<tr class=\"data odd\">			<td class=\"padding_right\"><span class=\"label name\">Bảo hành:</span> Không có</td>			<td><span class=\"label name\">Nguồn gốc:</span> Chính hãng</td>		</tr>		<tr class=\"data odd\">			<td class=\"padding_right\"><span class=\"name\">Kiểu dáng:</span> Cộc tay,</td>			<td><span class=\"name\">Cổ áo:</span> Cổ tròn</td>		</tr>		<tr class=\"data even\">			<td class=\"padding_right\"><span class=\"name\">Kích cỡ:</span> Size S</td>			<td><span class=\"name\">Chất liệu:</span> <a class=\"text_link\" href=\"http://www.vatgia.com/s/thun\">Thun</a></td>		</tr>		<tr class=\"data odd\">			<td class=\"padding_right\"><span class=\"name\">Màu:</span> Trắng, Tím, Xám,</td>			<td class=\"name\" colspan=\"2\">&nbsp;</td>		</tr>	</tbody></table><div><b>Thông tin về sản phẩm:</b></div><p><img alt=\"\" src=\"http://g.vatgia.vn/gallery_img/15/medium_syj1394438249.jpg\" style=\"margin: 2px; cursor: pointer;\" /><img alt=\"\" src=\"http://g.vatgia.vn/gallery_img/15/medium_kdg1388409143.jpg\" style=\"margin: 2px; cursor: pointer;\" /><img alt=\"\" src=\"http://g.vatgia.vn/gallery_img/15/medium_pxf1388409144.jpg\" style=\"margin: 2px; cursor: pointer;\" /></p>', '', ''), 
(11, 15, 1, 1432607113, 1432629575, 1, 1432607113, 0, 2, 'S000011', 20, '100000', '', 'VND', 2, '250', 'g', 1, '2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1, 'GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU', '', 0, 0, 0, 0, 1, 4, 1, '0', 1, 1, 1, 1, 0, 0, 0, 1, 'GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU', 'GIAY-BUP-BE-NGOI-SAO-NHAP-KHAU', 'GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU', '<img alt=\"GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU G16 -HÀNG CAO CẤP LOẠI 1 3\" src=\"https://media3.sendo.vn/img1/2015/4_28/giay-bup-be-ngoi-sao-nhap-khau-g16-hang-cao-cap-loai-1-1m4G3-9b82fa_simg_d0daf0_800x1200_max.jpg\" /><br  /><br  /><img alt=\"GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU G16 -HÀNG CAO CẤP LOẠI 1 4\" src=\"https://media3.sendo.vn/img1/2015/4_28/giay-bup-be-ngoi-sao-nhap-khau-g16-hang-cao-cap-loai-1-1m4G3-f802da_simg_d0daf0_800x1200_max.jpg\" /><br  /><br  /><img alt=\"GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU G16 -HÀNG CAO CẤP LOẠI 1 5\" src=\"https://media3.sendo.vn/img1/2015/4_28/giay-bup-be-ngoi-sao-nhap-khau-g16-hang-cao-cap-loai-1-1m4G3-166dba_simg_d0daf0_800x1200_max.jpg\" /><br  /><img alt=\"GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU G16 -HÀNG CAO CẤP LOẠI 1 6\" src=\"https://media3.sendo.vn/img1/2015/4_28/giay-bup-be-ngoi-sao-nhap-khau-g16-hang-cao-cap-loai-1-1m4G3-62836f_simg_d0daf0_800x1200_max.jpg\" /><br  /><img alt=\"GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU G16 -HÀNG CAO CẤP LOẠI 1 7\" src=\"https://media3.sendo.vn/img1/2015/4_28/giay-bup-be-ngoi-sao-nhap-khau-g16-hang-cao-cap-loai-1-1m4G3-e719fa_simg_d0daf0_800x1200_max.jpg\" /><br  /><br  /><img alt=\"GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU G16 -HÀNG CAO CẤP LOẠI 1 8\" src=\"https://media3.sendo.vn/img1/2015/4_28/giay-bup-be-ngoi-sao-nhap-khau-g16-hang-cao-cap-loai-1-1m4G3-c77041_simg_d0daf0_800x1200_max.jpg\" /><br  /><img alt=\"GIÀY BÚP BÊ NGÔI SAO NHẬP KHẨU G16 -HÀNG CAO CẤP LOẠI 1 9\" src=\"https://media3.sendo.vn/img1/2015/4_28/giay-bup-be-ngoi-sao-nhap-khau-g16-hang-cao-cap-loai-1-1m4G3-a9c5e4_simg_d0daf0_800x1200_max.jpg\" /><br  /><br  />&nbsp;', '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_shops`
--

DROP TABLE IF EXISTS `nv4_shops_shops`;
CREATE TABLE `nv4_shops_shops` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `location` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `address` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_shops`
--

INSERT INTO `nv4_shops_shops` VALUES
(1, 'An Giang', 1, 'An Giang', '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_shops_carrier`
--

DROP TABLE IF EXISTS `nv4_shops_shops_carrier`;
CREATE TABLE `nv4_shops_shops_carrier` (
  `shops_id` tinyint(3) unsigned NOT NULL,
  `carrier_id` tinyint(3) unsigned NOT NULL,
  `config_id` tinyint(3) unsigned NOT NULL,
  UNIQUE KEY `shops_id` (`shops_id`,`carrier_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_shops_carrier`
--

INSERT INTO `nv4_shops_shops_carrier` VALUES
(1, 10, 3);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_tags`
--

DROP TABLE IF EXISTS `nv4_shops_tags`;
CREATE TABLE `nv4_shops_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vi_numpro` mediumint(8) NOT NULL DEFAULT '0',
  `vi_alias` varchar(255) NOT NULL DEFAULT '',
  `vi_image` varchar(255) DEFAULT '',
  `vi_description` text,
  `vi_keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_tags`
--

INSERT INTO `nv4_shops_tags` VALUES
(1, 1, 'thời-trang', '', '', 'thời trang'), 
(2, 1, 'sang-trọng', '', '', 'sang trọng'), 
(3, 1, 'phù-hợp', '', '', 'phù hợp'), 
(4, 1, 'đi-chơi', '', '', 'đi chơi'), 
(5, 1, 'áo-sơ-mi', '', '', 'áo sơ mi'), 
(6, 1, 'mũi-nhọn', '', '', 'mũi nhọn'), 
(7, 1, 'búp-bê', '', '', 'búp bê');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_tags_id`
--

DROP TABLE IF EXISTS `nv4_shops_tags_id`;
CREATE TABLE `nv4_shops_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `vi_keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_tags_id`
--

INSERT INTO `nv4_shops_tags_id` VALUES
(1, 1, 'thời trang'), 
(1, 2, 'sang trọng'), 
(1, 3, 'phù hợp'), 
(1, 4, 'đi chơi'), 
(6, 5, 'áo sơ mi'), 
(10, 6, 'mũi nhọn'), 
(11, 7, 'búp bê');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_template`
--

DROP TABLE IF EXISTS `nv4_shops_template`;
CREATE TABLE `nv4_shops_template` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_transaction`
--

DROP TABLE IF EXISTS `nv4_shops_transaction`;
CREATE TABLE `nv4_shops_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_time` int(11) NOT NULL DEFAULT '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `payment` varchar(100) NOT NULL DEFAULT '0',
  `payment_id` varchar(22) NOT NULL DEFAULT '0',
  `payment_time` int(11) NOT NULL DEFAULT '0',
  `payment_amount` float NOT NULL DEFAULT '0',
  `payment_data` text NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_units`
--

DROP TABLE IF EXISTS `nv4_shops_units`;
CREATE TABLE `nv4_shops_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vi_title` varchar(255) NOT NULL DEFAULT '',
  `vi_note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_units`
--

INSERT INTO `nv4_shops_units` VALUES
(1, 'cai', ''), 
(2, 'đôi', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_updateprice`
--

DROP TABLE IF EXISTS `nv4_shops_updateprice`;
CREATE TABLE `nv4_shops_updateprice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Mã sản phẩm',
  `cateid` mediumint(11) NOT NULL COMMENT 'Loại sản phẩm',
  `newprice` int(11) NOT NULL COMMENT 'Giá mới',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_updateprice`
--

INSERT INTO `nv4_shops_updateprice` VALUES
(2, 3, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_warehouse`
--

DROP TABLE IF EXISTS `nv4_shops_warehouse`;
CREATE TABLE `nv4_shops_warehouse` (
  `wid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `note` text NOT NULL,
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_warehouse`
--

INSERT INTO `nv4_shops_warehouse` VALUES
(1, 'Nhập kho ngày 23/05/2015', '', 1, 1432364016), 
(2, 'Nhập kho ngày 23/05/2015', '', 1, 1432365552), 
(3, 'Nhập kho ngày 23/05/2015', '', 1, 1432366753), 
(4, 'Nhập kho ngày 23/05/2015', '', 1, 1432367106), 
(5, 'Nhập kho ngày 23/05/2015', '', 1, 1432367387), 
(6, 'Nhập kho ngày 23/05/2015', '', 1, 1432367857), 
(7, 'Nhập kho ngày 23/05/2015', '', 1, 1432369139), 
(8, 'Nhập kho ngày 26/05/2015', '', 1, 1432608794), 
(9, 'Nhập kho ngày 26/05/2015', '', 1, 1432608805), 
(10, 'Nhập kho ngày 26/05/2015', '', 1, 1432608819), 
(11, 'Nhập kho ngày 26/05/2015', '', 1, 1432608835);


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_warehouse_logs`
--

DROP TABLE IF EXISTS `nv4_shops_warehouse_logs`;
CREATE TABLE `nv4_shops_warehouse_logs` (
  `logid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(11) unsigned NOT NULL DEFAULT '0',
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `quantity` int(11) unsigned NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `money_unit` char(3) NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `wid` (`wid`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_warehouse_logs`
--

INSERT INTO `nv4_shops_warehouse_logs` VALUES
(1, 1, 1, 20, '150000', 'VND'), 
(2, 2, 2, 50, '250000', 'VND'), 
(3, 3, 3, 15, '70000', 'VND'), 
(4, 4, 4, 20, '120000', 'VND'), 
(5, 5, 5, 30, '120000', 'VND'), 
(6, 6, 6, 15, '180000', 'VND'), 
(7, 7, 7, 50, '50000', 'VND'), 
(8, 8, 11, 20, '80', 'VND'), 
(9, 9, 10, 10, '180', 'VND'), 
(10, 10, 9, 10, '150', 'VND'), 
(11, 11, 8, 15, '50000', 'VND');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_warehouse_logs_group`
--

DROP TABLE IF EXISTS `nv4_shops_warehouse_logs_group`;
CREATE TABLE `nv4_shops_warehouse_logs_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `logid` int(11) unsigned NOT NULL DEFAULT '0',
  `listgroup` varchar(255) NOT NULL,
  `quantity` int(11) unsigned NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `money_unit` char(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `logid` (`logid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_weight_vi`
--

DROP TABLE IF EXISTS `nv4_shops_weight_vi`;
CREATE TABLE `nv4_shops_weight_vi` (
  `id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `exchange` float NOT NULL DEFAULT '0',
  `round` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_shops_weight_vi`
--

INSERT INTO `nv4_shops_weight_vi` VALUES
(1, 'g', 'Gram', '1', '0.1'), 
(2, 'kg', 'Kilogam', '1000', '0.1');


-- ---------------------------------------


--
-- Table structure for table `nv4_shops_wishlist`
--

DROP TABLE IF EXISTS `nv4_shops_wishlist`;
CREATE TABLE `nv4_shops_wishlist` (
  `wid` smallint(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `listid` text,
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_dir`
--

DROP TABLE IF EXISTS `nv4_upload_dir`;
CREATE TABLE `nv4_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(255) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=23  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_upload_dir`
--

INSERT INTO `nv4_upload_dir` VALUES
(0, '', 0, 3, 100, 150, 90), 
(1, 'uploads/menu', 0, 0, 0, 0, 0), 
(2, 'images', 0, 0, 0, 0, 0), 
(3, 'images/rank', 0, 0, 0, 0, 0), 
(4, 'uploads', 0, 0, 0, 0, 0), 
(5, 'uploads/about', 0, 0, 0, 0, 0), 
(6, 'uploads/banners', 0, 0, 0, 0, 0), 
(7, 'uploads/contact', 0, 0, 0, 0, 0), 
(8, 'uploads/news', 0, 0, 0, 0, 0), 
(9, 'uploads/news/2015_03', 0, 0, 0, 0, 0), 
(10, 'uploads/news/source', 0, 0, 0, 0, 0), 
(11, 'uploads/news/temp_pic', 0, 0, 0, 0, 0), 
(12, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(13, 'uploads/page', 0, 0, 0, 0, 0), 
(14, 'uploads/users', 0, 0, 0, 0, 0), 
(15, 'uploads/shops', 1432353244, 0, 0, 0, 0), 
(16, 'uploads/shops/temp_pic', 0, 0, 0, 0, 0), 
(17, 'uploads/shops/2015_05', 1432363235, 0, 0, 0, 0), 
(18, 'uploads/download', 0, 0, 0, 0, 0), 
(19, 'uploads/download/files', 0, 0, 0, 0, 0), 
(20, 'uploads/download/images', 0, 0, 0, 0, 0), 
(21, 'uploads/download/temp', 0, 0, 0, 0, 0), 
(22, 'uploads/nvtools', 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_file`
--

DROP TABLE IF EXISTS `nv4_upload_file`;
CREATE TABLE `nv4_upload_file` (
  `name` varchar(255) NOT NULL,
  `ext` varchar(10) NOT NULL DEFAULT '',
  `type` varchar(5) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255) NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alt` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_upload_file`
--

INSERT INTO `nv4_upload_file` VALUES
('maya-dam-m...jpg', 'jpg', 'image', 42817, 'files/shops/2015_05/maya-dam-maxi-sang-trong-hoa-cao-cap-bm12-1m4g3-dbc487_simg_d0daf0_800x1200_max.jpg', 60, 80, '540|720', 1, 1432363258, 17, 'maya-dam-maxi-sang-trong-hoa-cao-cap-bm12-1m4g3-dbc487_simg_d0daf0_800x1200_max.jpg', 'maya dam maxi sang trong hoa cao cap bm12 1m4G3 dbc487 simg d0daf0 800x1200 max'), 
('hang-nhap-...jpg', 'jpg', 'image', 97932, 'files/shops/2015_05/hang-nhap-cao-cap-dam-maxi-hoa-tiet-cao-cap-1m4g3-dammaxihoatietcaocap2_2kgkkt5saqrg4_simg_d0daf0_800x1200_max.jpg', 60, 80, '550|729', 1, 1432365402, 17, 'hang-nhap-cao-cap-dam-maxi-hoa-tiet-cao-cap-1m4g3-dammaxihoatietcaocap2_2kgkkt5saqrg4_simg_d0daf0_800x1200_max.jpg', 'hang nhap cao cap dam maxi hoa tiet cao cap 1m4G3 dammaxihoatietcaocap2 2kgkkt5saqrg4 simg d0daf0 800x1200 max'), 
('dam-cao-cap.jpg', 'jpg', 'image', 97820, 'files/shops/2015_05/dam-cao-cap.jpg', 63, 80, '556|710', 1, 1432365875, 17, 'dam-cao-cap.jpg', 'dam cao cap'), 
('chan-vay-c...jpg', 'jpg', 'image', 64758, 'files/shops/2015_05/chan-vay-cong-so.jpg', 80, 55, '660|450', 1, 1432366735, 17, 'chan-vay-cong-so.jpg', 'chan vay cong so'), 
('chan-vay-caro.jpg', 'jpg', 'image', 112788, 'files/shops/2015_05/chan-vay-caro.jpg', 80, 80, '500|500', 1, 1432367020, 17, 'chan-vay-caro.jpg', 'chân váy caro'), 
('ao-so-mi-v...jpg', 'jpg', 'image', 66155, 'files/shops/2015_05/ao-so-mi-voan-lua.jpg', 74, 80, '718|767', 1, 1432367304, 17, 'ao-so-mi-voan-lua.jpg', 'ao so mi voan lua'), 
('hang-nhap-...jpg', 'jpg', 'image', 99686, 'files/shops/2015_05/hang-nhap-cao-cap-ao-so-mi-voan-phoi-tay-ren.jpg', 77, 80, '790|822', 1, 1432367538, 17, 'hang-nhap-cao-cap-ao-so-mi-voan-phoi-tay-ren.jpg', 'hang nhap cao cap ao so mi voan phoi tay ren'), 
('ao-thun-nu...jpg', 'jpg', 'image', 49803, 'files/shops/2015_05/ao-thun-nu-4-chieu-xb417.jpg', 80, 78, '418|406', 1, 1432369115, 17, 'ao-thun-nu-4-chieu-xb417.jpg', 'ao thun nu 4 chieu xb417'), 
('ao-so-mi-voan.jpg', 'jpg', 'image', 99686, 'files/shops/2015_05/ao-so-mi-voan.jpg', 77, 80, '790|822', 1, 1432369405, 17, 'ao-so-mi-voan.jpg', 'ao so mi voan'), 
('ao-thun-nu...jpg', 'jpg', 'image', 59807, 'files/shops/2015_05/ao-thun-nu-4-chieu.jpg', 60, 80, '314|418', 1, 1432605593, 17, 'ao-thun-nu-4-chieu.jpg', 'ao thun nu 4 chieu'), 
('giay-da-nu...jpg', 'jpg', 'image', 62761, 'files/shops/2015_05/giay-da-nu-got-vuong.jpg', 80, 60, '800|600', 1, 1432606198, 17, 'giay-da-nu-got-vuong.jpg', 'giay da nu got vuong'), 
('giay-cao-g...png', 'png', 'image', 437154, 'files/shops/2015_05/giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4g3-giaycaogotcg666hcopy_2k4etslal2erb_simg_d0daf0_800x1200_max.png', 80, 64, '668|531', 1, 1432606448, 17, 'giay-cao-got-mui-nhon-mau-hong-be-quy-phai-cg-666h-1m4g3-giaycaogotcg666hcopy_2k4etslal2erb_simg_d0daf0_800x1200_max.png', 'giay cao got mui nhon mau hong be quy phai cg 666h 1m4G3 giaycaogotcg666hcopy 2k4etslal2erb simg d0daf0 800x1200 max'), 
('giay-bup-b...jpg', 'jpg', 'image', 131547, 'files/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 80, 80, '800|800', 1, 1432606878, 17, 'giay-bup-be-ngoi-sao-nhap-khau.jpg', 'giay bup be ngoi sao nhap khau');


-- ---------------------------------------


--
-- Table structure for table `nv4_users`
--

DROP TABLE IF EXISTS `nv4_users`;
CREATE TABLE `nv4_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(100) NOT NULL DEFAULT '',
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `gender` char(1) DEFAULT '',
  `photo` varchar(255) DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(50) DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  `last_openid` varchar(255) DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users`
--

INSERT INTO `nv4_users` VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '{SSHA}iQaHj674cqNszXFswb/V0HXx0N9wSWMz', 'admin@gmail.com', 'admin', '', '', '', 0, '', 1432349823, '1', '1', '', 0, 1, '', 1, '', 1432349823, '', '', '', 0), 
(2, 'nguyenhue', '80241b142d1b505044f9c08cafd0ddee', '{SSHA}quk/03y0noSHDspW0OZdjCJsv/o1VGZH', 'believe.in.love135@gmail.com', 'Nguyễn Thị Huế', 'nguyễn Thị Huế', '', '', 0, NULL, 1432623762, 'Bạn thích môn thể thao nào nhất', 'bóng đá', '', 0, 1, '', 1, 'e99fa92d6fe2d69195f706a5af6510e8', 1432623776, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0', '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_config`
--

DROP TABLE IF EXISTS `nv4_users_config`;
CREATE TABLE `nv4_users_config` (
  `config` varchar(100) NOT NULL,
  `content` text,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_config`
--

INSERT INTO `nv4_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|654321|696969|1234567|12345678|123456789|1234567890|aaaaaa|abc123|abc123@|abc@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman', 1432349800), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1432349800), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1432349800), 
('avatar_width', '80', 1432349800), 
('avatar_height', '80', 1432349800), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_field`
--

DROP TABLE IF EXISTS `nv4_users_field`;
CREATE TABLE `nv4_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50) NOT NULL,
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_info`
--

DROP TABLE IF EXISTS `nv4_users_info`;
CREATE TABLE `nv4_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_info`
--

INSERT INTO `nv4_users_info` VALUES
(1), 
(2);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_openid`
--

DROP TABLE IF EXISTS `nv4_users_openid`;
CREATE TABLE `nv4_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_question`
--

DROP TABLE IF EXISTS `nv4_users_question`;
CREATE TABLE `nv4_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_question`
--

INSERT INTO `nv4_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_reg`
--

DROP TABLE IF EXISTS `nv4_users_reg`;
CREATE TABLE `nv4_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  `users_info` text,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_about`
--

DROP TABLE IF EXISTS `nv4_vi_about`;
CREATE TABLE `nv4_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_about`
--

INSERT INTO `nv4_vi_about` VALUES
(1, 'Giới thiệu về NukeViet 3.0', 'Gioi-thieu-ve-NukeViet-3-0', '', '', '', '<p> NukeViet 3.0 là thế hệ CMS hoàn toàn mới do người Việt phát triển. Lần đầu tiên ở Việt Nam, một bộ nhân mã nguồn mở được đầu tư bài bản và chuyên nghiệp cả về tài chính, nhân lực và thời gian. Kết quả là 100% dòng code của NukeViet được viết mới hoàn toàn, NukeViet 3 sử dụng xHTML, CSS với Xtemplate và jquery cho phép vận dụng Ajax uyển chuyển cả trong công nghệ nhân.</p><p> Tận dụng các thành tựu mã nguồn mở có sẵn nhưng NukeViet 3 vẫn đảm bảo rằng từng dòng code là được code tay (NukeViet 3 không sử dụng bất cứ một nền tảng (framework) nào). Điều này có nghĩa là NukeViet 3 hoàn toàn không phụ thuộc vào bất cứ framework nào trong quá trình phát triển của mình; Bạn hoàn toàn có thể đọc hiểu để tự lập trình trên NukeViet 3 nếu bạn biết PHP và MySQL (đồng nghĩa với việc NukeViet 3 hoàn toàn mở và dễ nghiên cứu cho bất cứ ai muốn tìm hiểu về code của NukeViet).</p><p style=\"text-align: justify;\"> Bộ nhân NukeViet 3 ngoài việc thừa hưởng sự đơn giản vốn có của NukeViet nhưng không vì thế mà quên nâng cấp mình. Hệ thống NukeViet 3 hỗ trợ công nghệ đa nhân module. Chúng tôi gọi đó là công nghệ ảo hóa module. Công nghệ này cho phép người sử dụng có thể khởi tạo hàng ngàn module một cách tự động mà không cần động đến một dòng code. Các module được sinh ra từ công nghệ này gọi là module ảo. Module ảo là module được nhân bản từ một module bất kỳ của hệ thống nukeviet nếu module đó cho phép tạo module ảo.</p><p style=\"text-align: justify;\"> NukeViet 3 cũng hỗ trợ việc cài đặt từ động 100% các module, block, theme từ Admin Control Panel, người sử dụng có thể cài module mà không cần làm bất cứ thao tác phức tạp nào. NukeViet 3 còn cho phép bạn đóng gói module để chia sẻ cho người khác.</p><p style=\"text-align: justify;\"> NukeViet 3 đa ngôn ngữ 100% với 2 loại: đa ngôn ngữ giao diện và đa ngôn ngữ database. NukeViet 3 có tính năng&nbsp; cho phép người quản trị tự xây dựng ngôn ngữ mới cho site. Cho&nbsp; phép đóng gói file ngôn ngữ để chia sẻ cho cộng đồng... câu chuyện về nukeviet 3 sẽ còn dài vì một loạt các tính năng cao cấp vẫn đang được phát triển. Hãy sử dụng và phổ biến NukeViet 3 để tự mình tận hưởng những thành quả mới nhất từ công nghệ web mã nguồn mở. Cuối cùng NukeViet 3 là món của của <a href=\"http://vinades.vn\" target=\"_blank\">VINADES.,JSC</a> gửi tới cộng đồng để cảm ơn cộng đồng đã ủng hộ thời gian qua, bây giờ NukeViet 3 được đưa trở lại cộng đồng để cộng đồng tiếp tục nuôi nấng và chăm sóc NukeViet lớn mạnh hơn.</p><p style=\"text-align: justify;\"> Mọi ý kiến và yêu cầu trợ giúp về NukeViet 3 các bạn có thể gửi lên diễn đàn NukeViet tại địa chỉ: <a href=\"http://nukeviet.vn/phpbb/\" target=\"_blank\">http://nukeviet.vn/phpbb/</a>. Việc giúp đỡ hoàn toàn miễn phí và mọi góp ý của bạn đều được hoan nghênh.</p> <div style=\"text-align: center;\"> <object height=\"400\" width=\"480\"><param name=\"movie\" value=\"//www.youtube.com/v/dG66RocXSeY?rel=0&amp;autoplay=1&amp;hl=pt_BR&amp;version=3\" /><param name=\"allowFullScreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><embed allowfullscreen=\"true\" allowscriptaccess=\"always\" height=\"400\" src=\"//www.youtube.com/v/dG66RocXSeY?rel=0&amp;autoplay=1&amp;hl=pt_BR&amp;version=3\" type=\"application/x-shockwave-flash\" width=\"480\"></embed></object>	<br /> Video clip Giới thiệu mã nguồn mở NukeViet trong bản tin Tiêu điểm của chương trình Xã hội thông tin<br /> (Đài truyền hình kỹ thuật số VTC) phát sóng lúc 20h chủ nhật, ngày 05-09-2010 trên VTC1</div>', '', 0, '4', '', 0, 1, 1, 1275320174, 1275320174, 1), 
(2, 'Giới thiệu về công ty chuyên quản NukeViet', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '', '', '', '<p style=\"text-align: justify;\"> <strong>Công ty cổ phần phát triển nguồn mở Việt Nam</strong> (VINADES.,JSC) là công ty mã nguồn mở đầu tiên của Việt Nam sở hữu riêng một mã nguồn mở nổi tiếng và đang được sử dụng ở hàng ngàn website lớn nhỏ trong mọi lĩnh vực.<br /> <br /> Ra đời từ hoạt động của tổ chức nguồn mở NukeViet (từ năm 2004) và chính thức được thành lập đầu 2010 tại Hà Nội, khi đó báo chí đã gọi VINADES.,JSC là &quot;Công ty mã nguồn mở đầu tiên tại Việt Nam&quot;.<br /> <br /> Ngay sau khi thành lập, VINADES.,JSC đã thành công trong việc xây dựng <strong><a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a></strong> thành một <a href=\"http://nukeviet.vn/\" target=\"_blank\">mã nguồn mở</a> thuần Việt. Với khả năng mạnh mẽ, cùng các ưu điểm vượt trội về công nghệ, độ an toàn và bảo mật, NukeViet đã được hàng ngàn website lựa chọn sử dụng trong năm qua. Ngay khi ra mắt phiên bản mới năm 2010, NukeViet đã tạo nên hiệu ứng truyền thông chưa từng có trong lịch sử mã nguồn mở Việt Nam. Tiếp đó, năm 2011 Mã nguồn mở NukeViet đã giành giải thưởng Nhân tài đất Việt cho sản phẩm Công nghệ thông tin đã được ứng dụng rộng rãi.<br /></p><div style=\"text-align: center;\"> <object height=\"400\" width=\"480\"><param name=\"movie\" value=\"//www.youtube.com/v/ZOhu2bLE-eA?rel=0&amp;autoplay=1&amp;hl=pt_BR&amp;version=3\" /><param name=\"allowFullScreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><embed allowfullscreen=\"true\" allowscriptaccess=\"always\" height=\"400\" src=\"//www.youtube.com/v/ZOhu2bLE-eA?rel=0&amp;autoplay=1&amp;hl=pt_BR&amp;version=3\" type=\"application/x-shockwave-flash\" width=\"480\"></embed></object><br /> <strong>Video clip trao giải Nhân tài đất Việt 2011.</strong><br /> Sản phẩm &quot;Mã nguồn mở NukeViet&quot; đã nhận giải cao nhất (Giải ba, không có giải nhất, giải nhì) của Giải thưởng Nhân Tài Đất Việt 2011 ở lĩnh vực Công nghệ thông tin - Sản phẩm đã có ứng dụng rộng rãi.</div><p style=\"text-align: justify;\"><br /> Tự chuyên nghiệp hóa mình, thoát khỏi mô hình phát triển tự phát, công ty đã nỗ lực vươn mình ra thế giới và đang phấn đấu trở thành một trong những hiện tượng của thời &quot;dotcom&quot; ở Việt Nam.<br /> <br /> Để phục vụ hoạt động của công ty, công ty liên tục mở rộng và tuyển thêm nhân sự ở các vị trí: Lập trình viên, chuyên viên đồ họa, nhân viên kinh doanh... Hãy liên hệ ngay để gia nhập VINADES.,JSC và cùng chúng tôi trở thành một công ty phát triển nguồn mở thành công nhất Việt Nam.</p> <p>Nếu bạn có nhu cầu triển khai các hệ thống <a href=\"http://toasoandientu.vn\" target=\"_blank\">Tòa Soạn Điện Tử</a>, <a href=\"http://webnhanh.vn\" target=\"_blank\">phần mềm trực tuyến</a>, <a href=\"http://vinades.vn\" target=\"_blank\">thiết kế web</a> theo yêu cầu hoặc dịch vụ có liên quan, hãy liên hệ công ty chuyên quản NukeViet theo thông tin dưới đây:</p><p><strong><span style=\"font-family: Tahoma; color: rgb(255, 69, 0); font-size: 14px;\">CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM</span></strong><br /> <strong>VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY</strong> (<strong>VINADES.,JSC</strong>)<br />Website: <a href=\"http://vinades.vn/\">http://vinades.vn</a> | <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a> | <a href=\"http://webnhanh.vn/\">http://webnhanh.vn</a><br />Trụ sở: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br /> - Tel: +84-4-85872007<br /> - Fax: +84-4-35500914<br /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', '', 0, '4', '', 0, 2, 1, 1275320224, 1275320224, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_about_config`
--

DROP TABLE IF EXISTS `nv4_vi_about_config`;
CREATE TABLE `nv4_vi_about_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_about_config`
--

INSERT INTO `nv4_vi_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_blocks_groups`
--

DROP TABLE IF EXISTS `nv4_vi_blocks_groups`;
CREATE TABLE `nv4_vi_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` tinyint(4) DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=39  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_blocks_groups`
--

INSERT INTO `nv4_vi_blocks_groups` VALUES
(1, 'default', 'news', 'global.block_category.php', 'Chủ đề', '', 'no_title', '[LEFT]', 0, 1, '6', 1, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:25;}'), 
(2, 'default', 'statistics', 'global.counter.php', 'Thống kê truy cập', '', 'primary', '[LEFT]', 0, 1, '6', 1, 2, ''), 
(3, 'default', 'banners', 'global.banners.php', 'Quảng cáo trái', '', 'no_title', '[LEFT]', 0, 1, '6', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(5, 'default', 'users', 'global.login.php', 'Đăng nhập thành viên', '', 'primary', '[RIGHT]', 0, 1, '6', 1, 2, ''), 
(6, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', 'primary', '[RIGHT]', 0, 1, '6', 1, 3, ''), 
(7, 'default', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[TOP]', 0, 1, '6', 0, 1, 'a:3:{s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(8, 'default', 'banners', 'global.banners.php', 'Quảng cáo giữa trang', '', 'no_title', '[TOP]', 0, 1, '6', 1, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(17, 'default', 'menu', 'global.bootstrap.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(19, 'default', 'page', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:231:\"<p class=\"footer\"> © Copyright NukeViet 4. All right reserved.</p><p> Powered by <a href=\"http://nukeviet.vn/\" title=\"NukeViet CMS\">NukeViet CMS</a>. Design by <a href=\"http://vinades.vn/\" title=\"VINADES.,JSC\">VINADES.,JSC</a></p>\";}'), 
(21, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, 1, '6', 0, 1, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(22, 'default', 'theme', 'global.menu_footer.php', 'Menu footer', '', 'no_title', '[MENU_FOOTER]', 0, 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:4:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";}}'), 
(9, 'modern', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[HEADER]', 0, 1, '6', 0, 1, 'a:3:{s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(10, 'modern', 'about', 'global.about.php', 'Giới thiệu', '', 'no_title_html', '[RIGHT]', 0, 1, '6', 1, 1, ''), 
(11, 'modern', 'users', 'global.login.php', 'Đăng nhập', '', '', '[RIGHT]', 0, 1, '0', 1, 2, ''), 
(12, 'modern', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', '', '[RIGHT]', 0, 1, '6', 1, 3, ''), 
(13, 'modern', 'statistics', 'global.counter.php', 'Bộ đếm', '', '', '[RIGHT]', 0, 1, '0', 1, 4, ''), 
(14, 'modern', 'news', 'module.block_newsright.php', 'News Right', '', 'no_title', '[RIGHT]', 0, 1, '6', 0, 5, ''), 
(15, 'modern', 'banners', 'global.banners.php', 'Quảng cáo top banner', '', 'no_title', '[TOPADV]', 0, 1, '6', 1, 1, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(16, 'modern', 'menu', 'global.superfish.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(18, 'modern', 'page', 'global.html.php', 'footer site', '', 'no_title', '[FOOTER_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:274:\"© Copyright NukeViet 4. All right reserved.<br  />Xây dựng trên nền tảng <a href=\"http://nukeviet.vn/\" title=\"Mã nguồn mở NukeViet\">Mã nguồn mở NukeViet</a>. <a href=\"http://vinades.vn/\" title=\"Thiết kế web\">Thiết kế website</a> bởi VINADES.,JSC\";}'), 
(20, 'mobile_nukeviet', 'theme', 'global.menu.php', 'global menu', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:6:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:10:\"statistics\";i:5;s:6:\"voting\";}}'), 
(27, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, 1, '6', 0, 4, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(38, 'default', 'theme', 'global.slide_roundabout.php', 'global slide roundabout', '', 'no_title', '[MENU_SITE]', 0, 1, '6', 1, 2, 'a:213:{s:6:\"title1\";s:27:\"Lorem ipsum dolor sit amet.\";s:6:\"style1\";s:8:\"toBottom\";s:8:\"atarget1\";s:4:\"_top\";s:13:\"checkDisplay1\";s:1:\"1\";s:6:\"ahref1\";s:18:\"http://nukeviet.vn\";s:7:\"imgsrc1\";s:102:\"https://lh5.googleusercontent.com/-vFABiXVOnjw/VJPVIGNxSqI/AAAAAAAAAQA/hv9xpAwlsmY/s500/kagaya_110.jpg\";s:8:\"excerpt1\";s:126:\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. In, omnis rem eligendi sed beatae perferendis hic. Quia, cum, quasi.\";s:6:\"title2\";s:52:\"Lorem ipsum dolor sit amet, consectetur adipisicing.\";s:6:\"style2\";s:5:\"toTop\";s:8:\"atarget2\";s:6:\"_blank\";s:13:\"checkDisplay2\";s:1:\"1\";s:6:\"ahref2\";s:9:\"#nukeviet\";s:7:\"imgsrc2\";s:102:\"https://lh3.googleusercontent.com/-rj0-8HHSqAo/VJPVIlB5Z1I/AAAAAAAAAQE/RGNlCUzBxuU/s500/kagaya_111.jpg\";s:8:\"excerpt2\";s:144:\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt, assumenda, obcaecati ipsam corrupti voluptatibus hic alias tenetur incidunt!\";s:6:\"title3\";s:57:\"Lorem ipsum dolor sit amet, consectetur adipisicing elit.\";s:6:\"style3\";s:7:\"toRight\";s:8:\"atarget3\";s:4:\"_top\";s:13:\"checkDisplay3\";s:1:\"1\";s:6:\"ahref3\";s:1:\"#\";s:7:\"imgsrc3\";s:102:\"https://lh3.googleusercontent.com/-bvFmvCYqETI/VJPVDgZtGpI/AAAAAAAAAPI/qq5IjGyOAQg/s500/kagaya_101.jpg\";s:8:\"excerpt3\";s:127:\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus, pariatur eius quis molestiae sit sequi quo explicabo.\";s:6:\"title4\";s:40:\"Lorem ipsum dolor sit amet, consectetur.\";s:6:\"style4\";s:6:\"toLeft\";s:8:\"atarget4\";s:6:\"_blank\";s:13:\"checkDisplay4\";s:1:\"1\";s:6:\"ahref4\";s:0:\"\";s:7:\"imgsrc4\";s:102:\"https://lh6.googleusercontent.com/-TBzM2ICZqTA/VJPUKxnPYQI/AAAAAAAAANA/ya7-bI9BJs8/s500/kagaya_087.jpg\";s:8:\"excerpt4\";s:150:\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate, quos repellendus mollitia et dolorum quo nulla facilis libero accusamus delectus.\";s:6:\"title5\";s:18:\"Lorem ipsum dolor.\";s:6:\"style5\";s:6:\"toLeft\";s:8:\"atarget5\";s:6:\"_blank\";s:13:\"checkDisplay5\";s:1:\"1\";s:6:\"ahref5\";s:0:\"\";s:7:\"imgsrc5\";s:102:\"https://lh4.googleusercontent.com/-jsbGHnXJHlA/VJPVI3_BtjI/AAAAAAAAAQI/IhF9hsGbFwA/s500/kagaya_112.jpg\";s:8:\"excerpt5\";s:134:\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ex praesentium tempore incidunt aliquid beatae officia voluptates rerum!\";s:6:\"title6\";s:22:\"Lorem ipsum dolor sit.\";s:6:\"style6\";s:8:\"fixedBot\";s:8:\"atarget6\";s:0:\"\";s:13:\"checkDisplay6\";s:1:\"1\";s:6:\"ahref6\";s:0:\"\";s:7:\"imgsrc6\";s:102:\"https://lh6.googleusercontent.com/-MNRvG-FHjnM/VJPVFUtZPXI/AAAAAAAAAPU/N-SAQ3_mNoY/s500/kagaya_105.jpg\";s:8:\"excerpt6\";s:142:\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt, reiciendis labore ratione ab dolorum consequuntur sit quam voluptates qui.\";s:6:\"title7\";s:27:\"Lorem ipsum dolor sit amet.\";s:6:\"style7\";s:6:\"hidden\";s:8:\"atarget7\";s:0:\"\";s:13:\"checkDisplay7\";s:1:\"1\";s:6:\"ahref7\";s:0:\"\";s:7:\"imgsrc7\";s:102:\"https://lh6.googleusercontent.com/-Vf7S6_I-7Po/VJPVFus4kWI/AAAAAAAAAPc/wK7MZPOV_DQ/s500/kagaya_106.jpg\";s:8:\"excerpt7\";s:105:\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim, cumque recusandae ipsa nisi minima magni?\";s:6:\"title8\";s:0:\"\";s:6:\"style8\";s:0:\"\";s:8:\"atarget8\";s:0:\"\";s:13:\"checkDisplay8\";s:0:\"\";s:6:\"ahref8\";s:0:\"\";s:7:\"imgsrc8\";s:0:\"\";s:8:\"excerpt8\";s:0:\"\";s:6:\"title9\";s:0:\"\";s:6:\"style9\";s:0:\"\";s:8:\"atarget9\";s:0:\"\";s:13:\"checkDisplay9\";s:0:\"\";s:6:\"ahref9\";s:0:\"\";s:7:\"imgsrc9\";s:0:\"\";s:8:\"excerpt9\";s:0:\"\";s:7:\"title10\";s:0:\"\";s:7:\"style10\";s:0:\"\";s:9:\"atarget10\";s:0:\"\";s:14:\"checkDisplay10\";s:0:\"\";s:7:\"ahref10\";s:0:\"\";s:8:\"imgsrc10\";s:0:\"\";s:9:\"excerpt10\";s:0:\"\";s:7:\"title11\";s:0:\"\";s:7:\"style11\";s:0:\"\";s:9:\"atarget11\";s:0:\"\";s:14:\"checkDisplay11\";s:0:\"\";s:7:\"ahref11\";s:0:\"\";s:8:\"imgsrc11\";s:0:\"\";s:9:\"excerpt11\";s:0:\"\";s:7:\"title12\";s:0:\"\";s:7:\"style12\";s:0:\"\";s:9:\"atarget12\";s:0:\"\";s:14:\"checkDisplay12\";s:0:\"\";s:7:\"ahref12\";s:0:\"\";s:8:\"imgsrc12\";s:0:\"\";s:9:\"excerpt12\";s:0:\"\";s:7:\"title13\";s:0:\"\";s:7:\"style13\";s:0:\"\";s:9:\"atarget13\";s:0:\"\";s:14:\"checkDisplay13\";s:0:\"\";s:7:\"ahref13\";s:0:\"\";s:8:\"imgsrc13\";s:0:\"\";s:9:\"excerpt13\";s:0:\"\";s:7:\"title14\";s:0:\"\";s:7:\"style14\";s:0:\"\";s:9:\"atarget14\";s:0:\"\";s:14:\"checkDisplay14\";s:0:\"\";s:7:\"ahref14\";s:0:\"\";s:8:\"imgsrc14\";s:0:\"\";s:9:\"excerpt14\";s:0:\"\";s:7:\"title15\";s:0:\"\";s:7:\"style15\";s:0:\"\";s:9:\"atarget15\";s:0:\"\";s:14:\"checkDisplay15\";s:0:\"\";s:7:\"ahref15\";s:0:\"\";s:8:\"imgsrc15\";s:0:\"\";s:9:\"excerpt15\";s:0:\"\";s:7:\"title16\";s:0:\"\";s:7:\"style16\";s:0:\"\";s:9:\"atarget16\";s:0:\"\";s:14:\"checkDisplay16\";s:0:\"\";s:7:\"ahref16\";s:0:\"\";s:8:\"imgsrc16\";s:0:\"\";s:9:\"excerpt16\";s:0:\"\";s:7:\"title17\";s:0:\"\";s:7:\"style17\";s:0:\"\";s:9:\"atarget17\";s:0:\"\";s:14:\"checkDisplay17\";s:0:\"\";s:7:\"ahref17\";s:0:\"\";s:8:\"imgsrc17\";s:0:\"\";s:9:\"excerpt17\";s:0:\"\";s:7:\"title18\";s:0:\"\";s:7:\"style18\";s:0:\"\";s:9:\"atarget18\";s:0:\"\";s:14:\"checkDisplay18\";s:0:\"\";s:7:\"ahref18\";s:0:\"\";s:8:\"imgsrc18\";s:0:\"\";s:9:\"excerpt18\";s:0:\"\";s:7:\"title19\";s:0:\"\";s:7:\"style19\";s:0:\"\";s:9:\"atarget19\";s:0:\"\";s:14:\"checkDisplay19\";s:0:\"\";s:7:\"ahref19\";s:0:\"\";s:8:\"imgsrc19\";s:0:\"\";s:9:\"excerpt19\";s:0:\"\";s:7:\"title20\";s:0:\"\";s:7:\"style20\";s:0:\"\";s:9:\"atarget20\";s:0:\"\";s:14:\"checkDisplay20\";s:0:\"\";s:7:\"ahref20\";s:0:\"\";s:8:\"imgsrc20\";s:0:\"\";s:9:\"excerpt20\";s:0:\"\";s:7:\"title21\";s:0:\"\";s:7:\"style21\";s:0:\"\";s:9:\"atarget21\";s:0:\"\";s:14:\"checkDisplay21\";s:0:\"\";s:7:\"ahref21\";s:0:\"\";s:8:\"imgsrc21\";s:0:\"\";s:9:\"excerpt21\";s:0:\"\";s:7:\"title22\";s:0:\"\";s:7:\"style22\";s:0:\"\";s:9:\"atarget22\";s:0:\"\";s:14:\"checkDisplay22\";s:0:\"\";s:7:\"ahref22\";s:0:\"\";s:8:\"imgsrc22\";s:0:\"\";s:9:\"excerpt22\";s:0:\"\";s:7:\"title23\";s:0:\"\";s:7:\"style23\";s:0:\"\";s:9:\"atarget23\";s:0:\"\";s:14:\"checkDisplay23\";s:0:\"\";s:7:\"ahref23\";s:0:\"\";s:8:\"imgsrc23\";s:0:\"\";s:9:\"excerpt23\";s:0:\"\";s:7:\"title24\";s:0:\"\";s:7:\"style24\";s:0:\"\";s:9:\"atarget24\";s:0:\"\";s:14:\"checkDisplay24\";s:0:\"\";s:7:\"ahref24\";s:0:\"\";s:8:\"imgsrc24\";s:0:\"\";s:9:\"excerpt24\";s:0:\"\";s:7:\"title25\";s:0:\"\";s:7:\"style25\";s:0:\"\";s:9:\"atarget25\";s:0:\"\";s:14:\"checkDisplay25\";s:0:\"\";s:7:\"ahref25\";s:0:\"\";s:8:\"imgsrc25\";s:0:\"\";s:9:\"excerpt25\";s:0:\"\";s:7:\"title26\";s:0:\"\";s:7:\"style26\";s:0:\"\";s:9:\"atarget26\";s:0:\"\";s:14:\"checkDisplay26\";s:0:\"\";s:7:\"ahref26\";s:0:\"\";s:8:\"imgsrc26\";s:0:\"\";s:9:\"excerpt26\";s:0:\"\";s:7:\"title27\";s:0:\"\";s:7:\"style27\";s:0:\"\";s:9:\"atarget27\";s:0:\"\";s:14:\"checkDisplay27\";s:0:\"\";s:7:\"ahref27\";s:0:\"\";s:8:\"imgsrc27\";s:0:\"\";s:9:\"excerpt27\";s:0:\"\";s:7:\"title28\";s:0:\"\";s:7:\"style28\";s:0:\"\";s:9:\"atarget28\";s:0:\"\";s:14:\"checkDisplay28\";s:0:\"\";s:7:\"ahref28\";s:0:\"\";s:8:\"imgsrc28\";s:0:\"\";s:9:\"excerpt28\";s:0:\"\";s:7:\"title29\";s:0:\"\";s:7:\"style29\";s:0:\"\";s:9:\"atarget29\";s:0:\"\";s:14:\"checkDisplay29\";s:0:\"\";s:7:\"ahref29\";s:0:\"\";s:8:\"imgsrc29\";s:0:\"\";s:9:\"excerpt29\";s:0:\"\";s:10:\"background\";s:16:\"rgba(51,51,51,1)\";s:10:\"colorTitle\";s:7:\"#FFF000\";s:12:\"colorExcerpt\";s:7:\"#ffffff\";s:11:\"colorTitleH\";s:7:\"#00ff00\";s:13:\"colorExcerptH\";s:7:\"#ffffff\";s:8:\"duration\";s:4:\"2500\";s:7:\"toRight\";s:2:\"15\";s:6:\"toLeft\";s:2:\"15\";s:8:\"toBottom\";s:2:\"51\";s:5:\"toTop\";s:2:\"42\";}'), 
(37, 'default', 'news', 'global.block_groups_marquee.php', 'Tin tiêu điểm', '/groups/Tin-tieu-diem/', '', '[HEADER]', 0, 1, '6', 1, 1, 'a:4:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:5;s:6:\"scroll\";i:1;s:9:\"direction\";s:4:\"left\";}');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_blocks_weight`
--

DROP TABLE IF EXISTS `nv4_vi_blocks_weight`;
CREATE TABLE `nv4_vi_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_blocks_weight`
--

INSERT INTO `nv4_vi_blocks_weight` VALUES
(19, 2, 1), 
(19, 36, 1), 
(19, 39, 1), 
(19, 42, 1), 
(19, 43, 1), 
(19, 54, 1), 
(19, 55, 1), 
(19, 56, 1), 
(19, 57, 1), 
(19, 27, 1), 
(19, 47, 1), 
(19, 11, 1), 
(19, 52, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 13, 1), 
(19, 15, 1), 
(19, 16, 1), 
(19, 51, 1), 
(19, 53, 1), 
(19, 46, 1), 
(19, 33, 1), 
(19, 32, 1), 
(19, 30, 1), 
(19, 29, 1), 
(19, 31, 1), 
(19, 28, 1), 
(19, 34, 1), 
(19, 24, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 26, 1), 
(19, 23, 1), 
(19, 18, 1), 
(19, 25, 1), 
(19, 17, 1), 
(19, 22, 1), 
(19, 19, 1), 
(19, 48, 1), 
(19, 50, 1), 
(19, 58, 1), 
(19, 35, 1), 
(1, 2, 1), 
(1, 36, 1), 
(1, 39, 1), 
(1, 42, 1), 
(1, 43, 1), 
(1, 54, 1), 
(1, 55, 1), 
(1, 56, 1), 
(1, 57, 1), 
(1, 27, 1), 
(1, 47, 1), 
(1, 11, 1), 
(1, 52, 1), 
(1, 5, 1), 
(1, 6, 1), 
(1, 7, 1), 
(1, 13, 1), 
(1, 15, 1), 
(1, 16, 1), 
(1, 51, 1), 
(1, 53, 1), 
(1, 46, 1), 
(1, 33, 1), 
(1, 32, 1), 
(1, 30, 1), 
(1, 29, 1), 
(1, 31, 1), 
(1, 28, 1), 
(1, 34, 1), 
(1, 24, 1), 
(1, 20, 1), 
(1, 21, 1), 
(1, 26, 1), 
(1, 23, 1), 
(1, 18, 1), 
(1, 25, 1), 
(1, 17, 1), 
(1, 22, 1), 
(1, 19, 1), 
(1, 48, 1), 
(1, 50, 1), 
(1, 58, 1), 
(1, 35, 1), 
(2, 2, 2), 
(2, 36, 2), 
(2, 39, 2), 
(2, 42, 2), 
(2, 43, 2), 
(2, 54, 2), 
(2, 55, 2), 
(2, 56, 2), 
(2, 57, 2), 
(2, 27, 2), 
(2, 47, 2), 
(2, 11, 2), 
(2, 52, 2), 
(2, 5, 2), 
(2, 6, 2), 
(2, 7, 2), 
(2, 13, 2), 
(2, 15, 2), 
(2, 16, 2), 
(2, 51, 2), 
(2, 53, 2), 
(2, 46, 2), 
(2, 33, 2), 
(2, 32, 2), 
(2, 30, 2), 
(2, 29, 2), 
(2, 31, 2), 
(2, 28, 2), 
(2, 34, 2), 
(2, 24, 2), 
(2, 20, 2), 
(2, 21, 2), 
(2, 26, 2), 
(2, 23, 2), 
(2, 18, 2), 
(2, 25, 2), 
(2, 17, 2), 
(2, 22, 2), 
(2, 19, 2), 
(2, 48, 2), 
(2, 50, 2), 
(2, 58, 2), 
(2, 35, 2), 
(3, 2, 3), 
(3, 36, 3), 
(3, 39, 3), 
(3, 42, 3), 
(3, 43, 3), 
(3, 54, 3), 
(3, 55, 3), 
(3, 56, 3), 
(3, 57, 3), 
(3, 27, 3), 
(3, 47, 3), 
(3, 11, 3), 
(3, 52, 3), 
(3, 5, 3), 
(3, 6, 3), 
(3, 7, 3), 
(3, 13, 3), 
(3, 15, 3), 
(3, 16, 3), 
(3, 51, 3), 
(3, 53, 3), 
(3, 46, 3), 
(3, 33, 3), 
(3, 32, 3), 
(3, 30, 3), 
(3, 29, 3), 
(3, 31, 3), 
(3, 28, 3), 
(3, 34, 3), 
(3, 24, 3), 
(3, 20, 3), 
(3, 21, 3), 
(3, 26, 3), 
(3, 23, 3), 
(3, 18, 3), 
(3, 25, 3), 
(3, 17, 3), 
(3, 22, 3), 
(3, 19, 3), 
(3, 48, 3), 
(3, 50, 3), 
(3, 58, 3), 
(3, 35, 3), 
(22, 2, 1), 
(22, 36, 1), 
(22, 39, 1), 
(22, 42, 1), 
(22, 43, 1), 
(22, 54, 1), 
(22, 55, 1), 
(22, 56, 1), 
(22, 57, 1), 
(22, 27, 1), 
(22, 47, 1), 
(22, 11, 1), 
(22, 52, 1), 
(22, 5, 1), 
(22, 6, 1), 
(22, 7, 1), 
(22, 13, 1), 
(22, 15, 1), 
(22, 16, 1), 
(22, 51, 1), 
(22, 53, 1), 
(22, 46, 1), 
(22, 33, 1), 
(22, 32, 1), 
(22, 30, 1), 
(22, 29, 1), 
(22, 31, 1), 
(22, 28, 1), 
(22, 34, 1), 
(22, 24, 1), 
(22, 20, 1), 
(22, 21, 1), 
(22, 26, 1), 
(22, 23, 1), 
(22, 18, 1), 
(22, 25, 1), 
(22, 17, 1), 
(22, 22, 1), 
(22, 19, 1), 
(22, 48, 1), 
(22, 50, 1), 
(22, 58, 1), 
(22, 35, 1), 
(17, 2, 1), 
(17, 36, 1), 
(17, 39, 1), 
(17, 42, 1), 
(17, 43, 1), 
(17, 54, 1), 
(17, 55, 1), 
(17, 56, 1), 
(17, 57, 1), 
(17, 27, 1), 
(17, 47, 1), 
(17, 11, 1), 
(17, 52, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 13, 1), 
(17, 15, 1), 
(17, 16, 1), 
(17, 51, 1), 
(17, 53, 1), 
(17, 46, 1), 
(17, 33, 1), 
(17, 32, 1), 
(17, 30, 1), 
(17, 29, 1), 
(17, 31, 1), 
(17, 28, 1), 
(17, 34, 1), 
(17, 24, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 26, 1), 
(17, 23, 1), 
(17, 18, 1), 
(17, 25, 1), 
(17, 17, 1), 
(17, 22, 1), 
(17, 19, 1), 
(17, 48, 1), 
(17, 50, 1), 
(17, 58, 1), 
(17, 35, 1), 
(5, 2, 1), 
(5, 36, 1), 
(5, 39, 1), 
(5, 42, 1), 
(5, 43, 1), 
(5, 54, 1), 
(5, 55, 1), 
(5, 56, 1), 
(5, 57, 1), 
(5, 27, 1), 
(5, 47, 1), 
(5, 11, 1), 
(5, 52, 1), 
(5, 5, 1), 
(5, 6, 1), 
(5, 7, 1), 
(5, 13, 1), 
(5, 15, 1), 
(5, 16, 1), 
(5, 51, 1), 
(5, 53, 1), 
(5, 46, 1), 
(5, 33, 1), 
(5, 32, 1), 
(5, 30, 1), 
(5, 29, 1), 
(5, 31, 1), 
(5, 28, 1), 
(5, 34, 1), 
(5, 24, 1), 
(5, 20, 1), 
(5, 21, 1), 
(5, 26, 1), 
(5, 23, 1), 
(5, 18, 1), 
(5, 25, 1), 
(5, 17, 1), 
(5, 22, 1), 
(5, 19, 1), 
(5, 48, 1), 
(5, 50, 1), 
(5, 58, 1), 
(5, 35, 1), 
(6, 2, 2), 
(6, 36, 2), 
(6, 39, 2), 
(6, 42, 2), 
(6, 43, 2), 
(6, 54, 2), 
(6, 55, 2), 
(6, 56, 2), 
(6, 57, 2), 
(6, 27, 2), 
(6, 47, 2), 
(6, 11, 2), 
(6, 52, 2), 
(6, 5, 2), 
(6, 6, 2), 
(6, 7, 2), 
(6, 13, 2), 
(6, 15, 2), 
(6, 16, 2), 
(6, 51, 2), 
(6, 53, 2), 
(6, 46, 2), 
(6, 33, 2), 
(6, 32, 2), 
(6, 30, 2), 
(6, 29, 2), 
(6, 31, 2), 
(6, 28, 2), 
(6, 34, 2), 
(6, 24, 2), 
(6, 20, 2), 
(6, 21, 2), 
(6, 26, 2), 
(6, 23, 2), 
(6, 18, 2), 
(6, 25, 2), 
(6, 17, 2), 
(6, 22, 2), 
(6, 19, 2), 
(6, 48, 2), 
(6, 50, 2), 
(6, 58, 2), 
(6, 35, 2), 
(21, 2, 1), 
(21, 36, 1), 
(21, 39, 1), 
(21, 42, 1), 
(21, 43, 1), 
(21, 54, 1), 
(21, 55, 1), 
(21, 56, 1), 
(21, 57, 1), 
(21, 27, 1), 
(21, 47, 1), 
(21, 11, 1), 
(21, 52, 1), 
(21, 5, 1), 
(21, 6, 1), 
(27, 7, 1), 
(21, 13, 1), 
(21, 15, 1), 
(21, 16, 1), 
(21, 51, 1), 
(21, 53, 1), 
(21, 46, 1), 
(21, 33, 1), 
(21, 32, 1), 
(21, 30, 1), 
(21, 29, 1), 
(21, 31, 1), 
(21, 28, 1), 
(21, 34, 1), 
(21, 24, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 26, 1), 
(21, 23, 1), 
(21, 18, 1), 
(21, 25, 1), 
(21, 17, 1), 
(21, 22, 1), 
(21, 19, 1), 
(21, 48, 1), 
(21, 50, 1), 
(21, 58, 1), 
(21, 35, 1), 
(7, 7, 1), 
(8, 2, 1), 
(8, 36, 1), 
(8, 39, 1), 
(8, 42, 1), 
(8, 43, 1), 
(8, 54, 1), 
(8, 55, 1), 
(8, 56, 1), 
(8, 57, 1), 
(8, 27, 1), 
(8, 47, 1), 
(8, 11, 1), 
(8, 52, 1), 
(8, 5, 1), 
(8, 6, 1), 
(8, 7, 2), 
(8, 13, 1), 
(8, 15, 1), 
(8, 16, 1), 
(8, 51, 1), 
(8, 53, 1), 
(8, 46, 1), 
(8, 33, 1), 
(8, 32, 1), 
(8, 30, 1), 
(8, 29, 1), 
(8, 31, 1), 
(8, 28, 1), 
(8, 34, 1), 
(8, 24, 1), 
(8, 20, 1), 
(8, 21, 1), 
(8, 26, 1), 
(8, 23, 1), 
(8, 18, 1), 
(8, 25, 1), 
(8, 17, 1), 
(8, 22, 1), 
(8, 19, 1), 
(8, 48, 1), 
(8, 50, 1), 
(8, 58, 1), 
(8, 35, 1), 
(20, 2, 1), 
(20, 36, 1), 
(20, 39, 1), 
(20, 42, 1), 
(20, 43, 1), 
(20, 54, 1), 
(20, 55, 1), 
(20, 56, 1), 
(20, 57, 1), 
(20, 27, 1), 
(20, 47, 1), 
(20, 11, 1), 
(20, 52, 1), 
(20, 5, 1), 
(20, 6, 1), 
(20, 7, 1), 
(20, 13, 1), 
(20, 15, 1), 
(20, 16, 1), 
(20, 51, 1), 
(20, 53, 1), 
(20, 46, 1), 
(20, 33, 1), 
(20, 32, 1), 
(20, 30, 1), 
(20, 29, 1), 
(20, 31, 1), 
(20, 28, 1), 
(20, 34, 1), 
(20, 24, 1), 
(20, 20, 1), 
(20, 21, 1), 
(20, 26, 1), 
(20, 23, 1), 
(20, 18, 1), 
(20, 25, 1), 
(20, 17, 1), 
(20, 22, 1), 
(20, 19, 1), 
(20, 48, 1), 
(20, 50, 1), 
(20, 58, 1), 
(20, 35, 1), 
(18, 2, 1), 
(18, 36, 1), 
(18, 39, 1), 
(18, 42, 1), 
(18, 43, 1), 
(18, 54, 1), 
(18, 55, 1), 
(18, 56, 1), 
(18, 57, 1), 
(18, 27, 1), 
(18, 47, 1), 
(18, 11, 1), 
(18, 52, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 13, 1), 
(18, 15, 1), 
(18, 16, 1), 
(18, 51, 1), 
(18, 53, 1), 
(18, 46, 1), 
(18, 33, 1), 
(18, 32, 1), 
(18, 30, 1), 
(18, 29, 1), 
(18, 31, 1), 
(18, 28, 1), 
(18, 34, 1), 
(18, 24, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 26, 1), 
(18, 23, 1), 
(18, 18, 1), 
(18, 25, 1), 
(18, 17, 1), 
(18, 22, 1), 
(18, 19, 1), 
(18, 48, 1), 
(18, 50, 1), 
(18, 58, 1), 
(18, 35, 1), 
(9, 7, 1), 
(16, 2, 1), 
(16, 36, 1), 
(16, 39, 1), 
(16, 42, 1), 
(16, 43, 1), 
(16, 54, 1), 
(16, 55, 1), 
(16, 56, 1), 
(16, 57, 1), 
(16, 27, 1), 
(16, 47, 1), 
(16, 11, 1), 
(16, 52, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 13, 1), 
(16, 15, 1), 
(16, 16, 1), 
(16, 51, 1), 
(16, 53, 1), 
(16, 46, 1), 
(16, 33, 1), 
(16, 32, 1), 
(16, 30, 1), 
(16, 29, 1), 
(16, 31, 1), 
(16, 28, 1), 
(16, 34, 1), 
(16, 24, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 26, 1), 
(16, 23, 1), 
(16, 18, 1), 
(16, 25, 1), 
(16, 17, 1), 
(16, 22, 1), 
(16, 19, 1), 
(16, 48, 1), 
(16, 50, 1), 
(16, 58, 1), 
(16, 35, 1), 
(10, 2, 1), 
(10, 36, 1), 
(10, 39, 1), 
(10, 42, 1), 
(10, 43, 1), 
(10, 54, 1), 
(10, 55, 1), 
(10, 56, 1), 
(10, 57, 1), 
(10, 27, 1), 
(10, 47, 1), 
(10, 11, 1), 
(10, 52, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 13, 1), 
(10, 15, 1), 
(10, 16, 1), 
(10, 51, 1), 
(10, 53, 1), 
(10, 46, 1), 
(10, 33, 1), 
(10, 32, 1), 
(10, 30, 1), 
(10, 29, 1), 
(10, 31, 1), 
(10, 28, 1), 
(10, 34, 1), 
(10, 24, 1), 
(10, 20, 1), 
(10, 21, 1), 
(10, 26, 1), 
(10, 23, 1), 
(10, 18, 1), 
(10, 25, 1), 
(10, 17, 1), 
(10, 22, 1), 
(10, 19, 1), 
(10, 48, 1), 
(10, 50, 1), 
(10, 58, 1), 
(10, 35, 1), 
(11, 2, 2), 
(11, 36, 2), 
(11, 39, 2), 
(11, 42, 2), 
(11, 43, 2), 
(11, 54, 2), 
(11, 55, 2), 
(11, 56, 2), 
(11, 57, 2), 
(11, 27, 2), 
(11, 47, 2), 
(11, 11, 2), 
(11, 52, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 13, 2), 
(11, 15, 2), 
(11, 16, 2), 
(11, 51, 2), 
(11, 53, 2), 
(11, 46, 2), 
(11, 33, 2), 
(11, 32, 2), 
(11, 30, 2), 
(11, 29, 2), 
(11, 31, 2), 
(11, 28, 2), 
(11, 34, 2), 
(11, 24, 2), 
(11, 20, 2), 
(11, 21, 2), 
(11, 26, 2), 
(11, 23, 2), 
(11, 18, 2), 
(11, 25, 2), 
(11, 17, 2), 
(11, 22, 2), 
(11, 19, 2), 
(11, 48, 2), 
(11, 50, 2), 
(11, 58, 2), 
(11, 35, 2), 
(12, 2, 3), 
(12, 36, 3), 
(12, 39, 3), 
(12, 42, 3), 
(12, 43, 3), 
(12, 54, 3), 
(12, 55, 3), 
(12, 56, 3), 
(12, 57, 3), 
(12, 27, 3), 
(12, 47, 3), 
(12, 11, 3), 
(12, 52, 3), 
(12, 5, 3), 
(12, 6, 3), 
(12, 7, 3), 
(12, 13, 3), 
(12, 15, 3), 
(12, 16, 3), 
(12, 51, 3), 
(12, 53, 3), 
(12, 46, 3), 
(12, 33, 3), 
(12, 32, 3), 
(12, 30, 3), 
(12, 29, 3), 
(12, 31, 3), 
(12, 28, 3), 
(12, 34, 3), 
(12, 24, 3), 
(12, 20, 3), 
(12, 21, 3), 
(12, 26, 3), 
(12, 23, 3), 
(12, 18, 3), 
(12, 25, 3), 
(12, 17, 3), 
(12, 22, 3), 
(12, 19, 3), 
(12, 48, 3), 
(12, 50, 3), 
(12, 58, 3), 
(12, 35, 3), 
(13, 2, 4), 
(13, 36, 4), 
(13, 39, 4), 
(13, 42, 4), 
(13, 43, 4), 
(13, 54, 4), 
(13, 55, 4), 
(13, 56, 4), 
(13, 57, 4), 
(13, 27, 4), 
(13, 47, 4), 
(13, 11, 4), 
(13, 52, 4), 
(13, 5, 4), 
(13, 6, 4), 
(13, 7, 4), 
(13, 13, 4), 
(13, 15, 4), 
(13, 16, 4), 
(13, 51, 4), 
(13, 53, 4), 
(13, 46, 4), 
(13, 33, 4), 
(13, 32, 4), 
(13, 30, 4), 
(13, 29, 4), 
(13, 31, 4), 
(13, 28, 4), 
(13, 34, 4), 
(13, 24, 4), 
(13, 20, 4), 
(13, 21, 4), 
(13, 26, 4), 
(13, 23, 4), 
(13, 18, 4), 
(13, 25, 4), 
(13, 17, 4), 
(13, 22, 4), 
(13, 19, 4), 
(13, 48, 4), 
(13, 50, 4), 
(13, 58, 4), 
(13, 35, 4), 
(14, 5, 5), 
(14, 6, 5), 
(14, 7, 5), 
(14, 11, 5), 
(14, 13, 5), 
(14, 15, 5), 
(14, 16, 5), 
(14, 51, 5), 
(14, 52, 5), 
(15, 2, 1), 
(15, 36, 1), 
(15, 39, 1), 
(15, 42, 1), 
(15, 43, 1), 
(15, 54, 1), 
(15, 55, 1), 
(15, 56, 1), 
(15, 57, 1), 
(15, 27, 1), 
(15, 47, 1), 
(15, 11, 1), 
(15, 52, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 13, 1), 
(15, 15, 1), 
(15, 16, 1), 
(15, 51, 1), 
(15, 53, 1), 
(15, 46, 1), 
(15, 33, 1), 
(15, 32, 1), 
(15, 30, 1), 
(15, 29, 1), 
(15, 31, 1), 
(15, 28, 1), 
(15, 34, 1), 
(15, 24, 1), 
(15, 20, 1), 
(15, 21, 1), 
(15, 26, 1), 
(15, 23, 1), 
(15, 18, 1), 
(15, 25, 1), 
(15, 17, 1), 
(15, 22, 1), 
(15, 19, 1), 
(15, 48, 1), 
(15, 50, 1), 
(15, 58, 1), 
(15, 35, 1), 
(19, 69, 1), 
(19, 86, 1), 
(19, 65, 1), 
(19, 78, 1), 
(19, 60, 1), 
(19, 70, 1), 
(19, 71, 1), 
(19, 63, 1), 
(19, 67, 1), 
(19, 66, 1), 
(19, 79, 1), 
(19, 62, 1), 
(19, 87, 1), 
(19, 85, 1), 
(19, 72, 1), 
(19, 83, 1), 
(1, 69, 1), 
(1, 86, 1), 
(1, 65, 1), 
(1, 78, 1), 
(1, 60, 1), 
(1, 70, 1), 
(1, 71, 1), 
(1, 63, 1), 
(1, 67, 1), 
(1, 66, 1), 
(1, 79, 1), 
(1, 62, 1), 
(1, 87, 1), 
(1, 85, 1), 
(1, 72, 1), 
(1, 83, 1), 
(2, 69, 2), 
(2, 86, 2), 
(2, 65, 2), 
(2, 78, 2), 
(2, 60, 2), 
(2, 70, 2), 
(2, 71, 2), 
(2, 63, 2), 
(2, 67, 2), 
(2, 66, 2), 
(2, 79, 2), 
(2, 62, 2), 
(2, 87, 2), 
(2, 85, 2), 
(2, 72, 2), 
(2, 83, 2), 
(3, 69, 3), 
(3, 86, 3), 
(3, 65, 3), 
(3, 78, 3), 
(3, 60, 3), 
(3, 70, 3), 
(3, 71, 3), 
(3, 63, 3), 
(3, 67, 3), 
(3, 66, 3), 
(3, 79, 3), 
(3, 62, 3), 
(3, 87, 3), 
(3, 85, 3), 
(3, 72, 3), 
(3, 83, 3), 
(22, 69, 1), 
(22, 86, 1), 
(22, 65, 1), 
(22, 78, 1), 
(22, 60, 1), 
(22, 70, 1), 
(22, 71, 1), 
(22, 63, 1), 
(22, 67, 1), 
(22, 66, 1), 
(22, 79, 1), 
(22, 62, 1), 
(22, 87, 1), 
(22, 85, 1), 
(22, 72, 1), 
(22, 83, 1), 
(17, 69, 1), 
(17, 86, 1), 
(17, 65, 1), 
(17, 78, 1), 
(17, 60, 1), 
(17, 70, 1), 
(17, 71, 1), 
(17, 63, 1), 
(17, 67, 1), 
(17, 66, 1), 
(17, 79, 1), 
(17, 62, 1), 
(17, 87, 1), 
(17, 85, 1), 
(17, 72, 1), 
(17, 83, 1), 
(5, 69, 1), 
(5, 86, 1), 
(5, 65, 1), 
(5, 78, 1), 
(5, 60, 1), 
(5, 70, 1), 
(5, 71, 1), 
(5, 63, 1), 
(5, 67, 1), 
(5, 66, 1), 
(5, 79, 1), 
(5, 62, 1), 
(5, 87, 1), 
(5, 85, 1), 
(5, 72, 1), 
(5, 83, 1), 
(6, 69, 2), 
(6, 86, 2), 
(6, 65, 2), 
(6, 78, 2), 
(6, 60, 2), 
(6, 70, 2), 
(6, 71, 2), 
(6, 63, 2), 
(6, 67, 2), 
(6, 66, 2), 
(6, 79, 2), 
(6, 62, 2), 
(6, 87, 2), 
(6, 85, 2), 
(6, 72, 2), 
(6, 83, 2), 
(21, 69, 1), 
(21, 86, 1), 
(21, 65, 1), 
(21, 78, 1), 
(21, 60, 1), 
(21, 70, 1), 
(21, 71, 1), 
(21, 63, 1), 
(21, 67, 1), 
(21, 66, 1), 
(21, 79, 1), 
(21, 62, 1), 
(21, 87, 1), 
(21, 85, 1), 
(21, 72, 1), 
(21, 83, 1), 
(8, 69, 1), 
(8, 86, 1), 
(8, 65, 1), 
(8, 78, 1), 
(8, 60, 1), 
(8, 70, 1), 
(8, 71, 1), 
(8, 63, 1), 
(8, 67, 1), 
(8, 66, 1), 
(8, 79, 1), 
(8, 62, 1), 
(8, 87, 1), 
(8, 85, 1), 
(8, 72, 1), 
(8, 83, 1), 
(20, 69, 1), 
(20, 86, 1), 
(20, 65, 1), 
(20, 78, 1), 
(20, 60, 1), 
(20, 70, 1), 
(20, 71, 1), 
(20, 63, 1), 
(20, 67, 1), 
(20, 66, 1), 
(20, 79, 1), 
(20, 62, 1), 
(20, 87, 1), 
(20, 85, 1), 
(20, 72, 1), 
(20, 83, 1), 
(18, 69, 1), 
(18, 86, 1), 
(18, 65, 1), 
(18, 78, 1), 
(18, 60, 1), 
(18, 70, 1), 
(18, 71, 1), 
(18, 63, 1), 
(18, 67, 1), 
(18, 66, 1), 
(18, 79, 1), 
(18, 62, 1), 
(18, 87, 1), 
(18, 85, 1), 
(18, 72, 1), 
(18, 83, 1), 
(16, 69, 1), 
(16, 86, 1), 
(16, 65, 1), 
(16, 78, 1), 
(16, 60, 1), 
(16, 70, 1), 
(16, 71, 1), 
(16, 63, 1), 
(16, 67, 1), 
(16, 66, 1), 
(16, 79, 1), 
(16, 62, 1), 
(16, 87, 1), 
(16, 85, 1), 
(16, 72, 1), 
(16, 83, 1), 
(10, 69, 1), 
(10, 86, 1), 
(10, 65, 1), 
(10, 78, 1), 
(10, 60, 1), 
(10, 70, 1), 
(10, 71, 1), 
(10, 63, 1), 
(10, 67, 1), 
(10, 66, 1), 
(10, 79, 1), 
(10, 62, 1), 
(10, 87, 1), 
(10, 85, 1), 
(10, 72, 1), 
(10, 83, 1), 
(11, 69, 2), 
(11, 86, 2), 
(11, 65, 2), 
(11, 78, 2), 
(11, 60, 2), 
(11, 70, 2), 
(11, 71, 2), 
(11, 63, 2), 
(11, 67, 2), 
(11, 66, 2), 
(11, 79, 2), 
(11, 62, 2), 
(11, 87, 2), 
(11, 85, 2), 
(11, 72, 2), 
(11, 83, 2), 
(12, 69, 3), 
(12, 86, 3), 
(12, 65, 3), 
(12, 78, 3), 
(12, 60, 3), 
(12, 70, 3), 
(12, 71, 3), 
(12, 63, 3), 
(12, 67, 3), 
(12, 66, 3), 
(12, 79, 3), 
(12, 62, 3), 
(12, 87, 3), 
(12, 85, 3), 
(12, 72, 3), 
(12, 83, 3), 
(13, 69, 4), 
(13, 86, 4), 
(13, 65, 4), 
(13, 78, 4), 
(13, 60, 4), 
(13, 70, 4), 
(13, 71, 4), 
(13, 63, 4), 
(13, 67, 4), 
(13, 66, 4), 
(13, 79, 4), 
(13, 62, 4), 
(13, 87, 4), 
(13, 85, 4), 
(13, 72, 4), 
(13, 83, 4), 
(15, 69, 1), 
(15, 86, 1), 
(15, 65, 1), 
(15, 78, 1), 
(15, 60, 1), 
(15, 70, 1), 
(15, 71, 1), 
(15, 63, 1), 
(15, 67, 1), 
(15, 66, 1), 
(15, 79, 1), 
(15, 62, 1), 
(15, 87, 1), 
(15, 85, 1), 
(15, 72, 1), 
(15, 83, 1), 
(19, 90, 1), 
(19, 96, 1), 
(19, 97, 1), 
(19, 89, 1), 
(19, 95, 1), 
(19, 91, 1), 
(19, 93, 1), 
(1, 90, 1), 
(1, 96, 1), 
(1, 97, 1), 
(1, 89, 1), 
(1, 95, 1), 
(1, 91, 1), 
(1, 93, 1), 
(2, 90, 2), 
(2, 96, 2), 
(2, 97, 2), 
(2, 89, 2), 
(2, 95, 2), 
(2, 91, 2), 
(2, 93, 2), 
(3, 90, 3), 
(3, 96, 3), 
(3, 97, 3), 
(3, 89, 3), 
(3, 95, 3), 
(3, 91, 3), 
(3, 93, 3), 
(22, 90, 1), 
(22, 96, 1), 
(22, 97, 1), 
(22, 89, 1), 
(22, 95, 1), 
(22, 91, 1), 
(22, 93, 1), 
(17, 90, 1), 
(17, 96, 1), 
(17, 97, 1), 
(17, 89, 1), 
(17, 95, 1), 
(17, 91, 1), 
(17, 93, 1), 
(5, 90, 1), 
(5, 96, 1), 
(5, 97, 1), 
(5, 89, 1), 
(5, 95, 1), 
(5, 91, 1), 
(5, 93, 1), 
(6, 90, 2), 
(6, 96, 2), 
(6, 97, 2), 
(6, 89, 2), 
(6, 95, 2), 
(6, 91, 2), 
(6, 93, 2), 
(21, 90, 1), 
(21, 96, 1), 
(21, 97, 1), 
(21, 89, 1), 
(21, 95, 1), 
(21, 91, 1), 
(21, 93, 1), 
(8, 90, 1), 
(8, 96, 1), 
(8, 97, 1), 
(8, 89, 1), 
(8, 95, 1), 
(8, 91, 1), 
(8, 93, 1), 
(20, 90, 1), 
(20, 96, 1), 
(20, 97, 1), 
(20, 89, 1), 
(20, 95, 1), 
(20, 91, 1), 
(20, 93, 1), 
(18, 90, 1), 
(18, 96, 1), 
(18, 97, 1), 
(18, 89, 1), 
(18, 95, 1), 
(18, 91, 1), 
(18, 93, 1), 
(16, 90, 1), 
(16, 96, 1), 
(16, 97, 1), 
(16, 89, 1), 
(16, 95, 1), 
(16, 91, 1), 
(16, 93, 1), 
(10, 90, 1), 
(10, 96, 1), 
(10, 97, 1), 
(10, 89, 1), 
(10, 95, 1), 
(10, 91, 1), 
(10, 93, 1), 
(11, 90, 2), 
(11, 96, 2), 
(11, 97, 2), 
(11, 89, 2), 
(11, 95, 2), 
(11, 91, 2), 
(11, 93, 2), 
(12, 90, 3), 
(12, 96, 3), 
(12, 97, 3), 
(12, 89, 3), 
(12, 95, 3), 
(12, 91, 3), 
(12, 93, 3), 
(13, 90, 4), 
(13, 96, 4), 
(13, 97, 4), 
(13, 89, 4), 
(13, 95, 4), 
(13, 91, 4), 
(13, 93, 4), 
(15, 90, 1), 
(15, 96, 1), 
(15, 97, 1), 
(15, 89, 1), 
(15, 95, 1), 
(15, 91, 1), 
(15, 93, 1), 
(19, 101, 1), 
(19, 102, 1), 
(19, 100, 1), 
(19, 98, 1), 
(1, 101, 1), 
(1, 102, 1), 
(1, 100, 1), 
(1, 98, 1), 
(2, 101, 2), 
(2, 102, 2), 
(2, 100, 2), 
(2, 98, 2), 
(3, 101, 3), 
(3, 102, 3), 
(3, 100, 3), 
(3, 98, 3), 
(22, 101, 1), 
(22, 102, 1), 
(22, 100, 1), 
(22, 98, 1), 
(17, 101, 1), 
(17, 102, 1), 
(17, 100, 1), 
(17, 98, 1), 
(5, 101, 1), 
(5, 102, 1), 
(5, 100, 1), 
(5, 98, 1), 
(6, 101, 2), 
(6, 102, 2), 
(6, 100, 2), 
(6, 98, 2), 
(8, 101, 1), 
(8, 102, 1), 
(8, 100, 1), 
(8, 98, 1), 
(20, 101, 1), 
(20, 102, 1), 
(20, 100, 1), 
(20, 98, 1), 
(18, 101, 1), 
(18, 102, 1), 
(18, 100, 1), 
(18, 98, 1), 
(16, 101, 1), 
(16, 102, 1), 
(16, 100, 1), 
(16, 98, 1), 
(10, 101, 1), 
(10, 102, 1), 
(10, 100, 1), 
(10, 98, 1), 
(11, 101, 2), 
(11, 102, 2), 
(11, 100, 2), 
(11, 98, 2), 
(12, 101, 3), 
(12, 102, 3), 
(12, 100, 3), 
(12, 98, 3), 
(13, 101, 4), 
(13, 102, 4), 
(13, 100, 4), 
(13, 98, 4), 
(15, 101, 1), 
(15, 102, 1), 
(15, 100, 1), 
(15, 98, 1), 
(38, 2, 2), 
(38, 87, 2), 
(38, 5, 2), 
(38, 101, 2), 
(38, 13, 2), 
(38, 98, 2), 
(38, 100, 2), 
(38, 6, 2), 
(38, 11, 2), 
(38, 52, 2), 
(38, 83, 2), 
(38, 7, 2), 
(38, 62, 2), 
(38, 85, 2), 
(38, 102, 2), 
(38, 72, 2), 
(38, 86, 2), 
(38, 69, 2), 
(38, 65, 2), 
(38, 78, 2), 
(38, 55, 2), 
(38, 36, 2), 
(38, 46, 2), 
(38, 43, 2), 
(38, 34, 2), 
(38, 39, 2), 
(38, 53, 2), 
(38, 35, 2), 
(38, 54, 2), 
(38, 42, 2), 
(38, 47, 2), 
(38, 23, 2), 
(38, 26, 2), 
(38, 15, 2), 
(38, 28, 2), 
(38, 27, 2), 
(38, 33, 2), 
(38, 30, 2), 
(38, 29, 2), 
(38, 32, 2), 
(38, 31, 2), 
(38, 58, 2), 
(38, 50, 2), 
(38, 48, 2), 
(38, 19, 2), 
(38, 22, 2), 
(38, 17, 2), 
(38, 25, 2), 
(38, 18, 2), 
(38, 21, 2), 
(38, 20, 2), 
(38, 24, 2), 
(38, 51, 2), 
(38, 16, 2), 
(38, 66, 2), 
(38, 70, 2), 
(38, 60, 2), 
(38, 79, 2), 
(38, 71, 2), 
(38, 67, 2), 
(38, 63, 2), 
(37, 69, 1), 
(37, 86, 1), 
(37, 65, 1), 
(37, 78, 1), 
(37, 60, 1), 
(37, 70, 1), 
(37, 71, 1), 
(37, 63, 1), 
(37, 67, 1), 
(37, 66, 1), 
(37, 79, 1), 
(37, 62, 1), 
(37, 87, 1), 
(37, 85, 1), 
(37, 72, 1), 
(37, 83, 1), 
(37, 101, 1), 
(37, 102, 1), 
(37, 100, 1), 
(37, 98, 1), 
(37, 2, 1), 
(37, 11, 1), 
(37, 52, 1), 
(37, 5, 1), 
(37, 6, 1), 
(37, 7, 1), 
(37, 13, 1), 
(37, 15, 1), 
(37, 16, 1), 
(37, 51, 1), 
(37, 24, 1), 
(37, 20, 1), 
(37, 21, 1), 
(37, 26, 1), 
(37, 23, 1), 
(37, 18, 1), 
(37, 25, 1), 
(37, 17, 1), 
(37, 22, 1), 
(37, 19, 1), 
(37, 48, 1), 
(37, 50, 1), 
(37, 58, 1), 
(37, 27, 1), 
(37, 33, 1), 
(37, 32, 1), 
(37, 30, 1), 
(37, 29, 1), 
(37, 31, 1), 
(37, 28, 1), 
(37, 34, 1), 
(37, 35, 1), 
(37, 36, 1), 
(37, 39, 1), 
(37, 42, 1), 
(37, 43, 1), 
(37, 46, 1), 
(37, 47, 1), 
(37, 53, 1), 
(37, 54, 1), 
(37, 55, 1), 
(37, 56, 1), 
(37, 57, 1), 
(37, 90, 1), 
(37, 96, 1), 
(37, 97, 1), 
(37, 89, 1), 
(37, 95, 1), 
(37, 91, 1), 
(37, 93, 1), 
(38, 56, 2), 
(38, 57, 2), 
(38, 90, 2), 
(38, 96, 2), 
(38, 97, 2), 
(38, 89, 2), 
(38, 95, 2), 
(38, 91, 2), 
(38, 93, 2);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_comments`
--

DROP TABLE IF EXISTS `nv4_vi_comments`;
CREATE TABLE `nv4_vi_comments` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `url_comment` varchar(250) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_department`
--

DROP TABLE IF EXISTS `nv4_vi_contact_department`;
CREATE TABLE `nv4_vi_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `yahoo` varchar(100) NOT NULL,
  `skype` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `admins` text NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_contact_department`
--

INSERT INTO `nv4_vi_contact_department` VALUES
(1, 'Webmaster', 'Webmaster', '', '', '', '', '', '', '1/1/1/0;', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_reply`
--

DROP TABLE IF EXISTS `nv4_vi_contact_reply`;
CREATE TABLE `nv4_vi_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_contact_send`
--

DROP TABLE IF EXISTS `nv4_vi_contact_send`;
CREATE TABLE `nv4_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(255) DEFAULT '',
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_download`
--

DROP TABLE IF EXISTS `nv4_vi_download`;
CREATE TABLE `nv4_vi_download` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `introtext` text NOT NULL,
  `uploadtime` int(11) unsigned NOT NULL,
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` mediumint(8) unsigned NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `author_email` varchar(60) NOT NULL,
  `author_url` varchar(255) NOT NULL,
  `fileupload` text NOT NULL,
  `linkdirect` text NOT NULL,
  `version` varchar(20) NOT NULL,
  `filesize` int(11) NOT NULL DEFAULT '0',
  `fileimage` varchar(255) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `copyright` varchar(255) NOT NULL,
  `view_hits` int(11) NOT NULL DEFAULT '0',
  `download_hits` int(11) NOT NULL DEFAULT '0',
  `groups_comment` varchar(255) NOT NULL,
  `groups_view` varchar(255) NOT NULL,
  `groups_download` varchar(255) NOT NULL,
  `comment_hits` int(11) NOT NULL DEFAULT '0',
  `rating_detail` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `catid` (`catid`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_download_categories`
--

DROP TABLE IF EXISTS `nv4_vi_download_categories`;
CREATE TABLE `nv4_vi_download_categories` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `groups_view` varchar(255) DEFAULT '',
  `groups_download` varchar(255) DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_download_config`
--

DROP TABLE IF EXISTS `nv4_vi_download_config`;
CREATE TABLE `nv4_vi_download_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_download_config`
--

INSERT INTO `nv4_vi_download_config` VALUES
('is_addfile', '1'), 
('is_upload', '1'), 
('groups_upload', ''), 
('maxfilesize', '2097152'), 
('upload_filetype', 'doc,xls,zip,rar'), 
('upload_dir', 'files'), 
('temp_dir', 'temp'), 
('groups_addfile', ''), 
('is_zip', '1'), 
('is_resume', '1'), 
('max_speed', '0');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_download_report`
--

DROP TABLE IF EXISTS `nv4_vi_download_report`;
CREATE TABLE `nv4_vi_download_report` (
  `fid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_ip` varchar(45) NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `fid` (`fid`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_download_tmp`
--

DROP TABLE IF EXISTS `nv4_vi_download_tmp`;
CREATE TABLE `nv4_vi_download_tmp` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `introtext` text NOT NULL,
  `uploadtime` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(100) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `author_email` varchar(60) NOT NULL,
  `author_url` varchar(255) NOT NULL,
  `fileupload` text NOT NULL,
  `linkdirect` text NOT NULL,
  `version` varchar(20) NOT NULL,
  `filesize` varchar(255) NOT NULL,
  `fileimage` varchar(255) NOT NULL,
  `copyright` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_menu`
--

DROP TABLE IF EXISTS `nv4_vi_menu`;
CREATE TABLE `nv4_vi_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_menu`
--

INSERT INTO `nv4_vi_menu` VALUES
(1, 'Top Menu');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_menu_rows`
--

DROP TABLE IF EXISTS `nv4_vi_menu_rows`;
CREATE TABLE `nv4_vi_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `note` varchar(255) DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text,
  `groups_view` varchar(255) DEFAULT '',
  `module_name` varchar(255) DEFAULT '',
  `op` varchar(255) DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255) DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=39  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_menu_rows`
--

INSERT INTO `nv4_vi_menu_rows` VALUES
(1, 0, 1, 'Giới thiệu', '/index.php?language=vi&nv=about', '', '', 2, 2, 0, '2,3', '6', 'about', '', 1, '', 1, 1), 
(2, 1, 1, 'Giới thiệu về NukeViet 3.0', '/index.php?language=vi&nv=about&amp;op=Gioi-thieu-ve-NukeViet-3-0', '', '', 1, 3, 1, '', '6', 'about', 'Gioi-thieu-ve-NukeViet-3-0', 1, '', 1, 1), 
(3, 1, 1, 'Giới thiệu về công ty chuyên quản NukeViet', '/index.php?language=vi&nv=about&amp;op=Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '', '', 2, 4, 1, '', '6', 'about', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', 1, '', 1, 1), 
(4, 0, 1, 'Tin Tức', '/index.php?language=vi&nv=news', '', '', 3, 5, 0, '5,6,7,8,30,31,32', '6', 'news', '', 1, '', 1, 1), 
(5, 4, 1, 'Tin tức', '/index.php?language=vi&nv=news&amp;op=Tin-tuc', '', '', 1, 6, 1, '', '6', 'news', 'Tin-tuc', 1, '', 1, 1), 
(6, 4, 1, 'Sản phẩm', '/index.php?language=vi&nv=news&amp;op=San-pham', '', '', 2, 7, 1, '', '6', 'news', 'San-pham', 1, '', 1, 1), 
(7, 4, 1, 'Đối tác', '/index.php?language=vi&nv=news&amp;op=Doi-tac', '', '', 3, 8, 1, '', '6', 'news', 'Doi-tac', 1, '', 1, 1), 
(8, 4, 1, 'Tuyển dụng', '/index.php?language=vi&nv=news&amp;op=Tuyen-dung', '', '', 4, 9, 1, '', '6', 'news', 'Tuyen-dung', 1, '', 1, 1), 
(9, 0, 1, 'Thành viên', '/index.php?language=vi&nv=users', '', '', 4, 13, 0, '10,11,12,13,14,15,16', '6', 'users', '', 1, '', 1, 1), 
(10, 9, 1, 'Đăng nhập', '/index.php?language=vi&nv=users&op=login', '', '', 1, 14, 1, '', '5', 'users', 'login', 1, '', 1, 1), 
(11, 9, 1, 'Logout', '/index.php?language=vi&nv=users&op=logout', '', '', 2, 15, 1, '', '4', 'users', 'logout', 1, '', 1, 1), 
(12, 9, 1, 'Đăng ký', '/index.php?language=vi&nv=users&op=register', '', '', 3, 16, 1, '', '5', 'users', 'register', 1, '', 1, 1), 
(13, 9, 1, 'Quên mật khẩu', '/index.php?language=vi&nv=users&op=lostpass', '', '', 4, 17, 1, '', '5', 'users', 'lostpass', 1, '', 1, 1), 
(14, 9, 1, 'Đổi mật khẩu', '/index.php?language=vi&nv=users&op=changepass', '', '', 5, 18, 1, '', '4', 'users', 'changepass', 1, '', 1, 1), 
(15, 9, 1, 'Openid', '/index.php?language=vi&nv=users&op=openid', '', '', 6, 19, 1, '', '4', 'users', 'openid', 1, '', 1, 1), 
(16, 9, 1, 'Danh sách thành viên', '/index.php?language=vi&nv=users&op=memberlist', '', '', 7, 20, 1, '', '4', 'users', 'memberlist', 1, '', 1, 1), 
(17, 0, 1, 'Liên hệ', '/index.php?language=vi&nv=contact', '', '', 8, 29, 0, '18', '6', 'contact', '', 1, '', 1, 1), 
(18, 17, 1, 'Webmaster', '/index.php?language=vi&nv=contact&amp;op=1', '', '', 1, 30, 1, '', '6', 'contact', '1', 1, '', 1, 1), 
(19, 0, 1, 'Thống kê', '/index.php?language=vi&nv=statistics', '', '', 5, 21, 0, '20,21,22,23,24', '2', 'statistics', '', 1, '', 1, 1), 
(20, 19, 1, 'Theo đường dẫn đến site', '/index.php?language=vi&nv=statistics&amp;op=allreferers', '', '', 1, 22, 1, '', '2', 'statistics', 'allreferers', 1, '', 1, 1), 
(21, 19, 1, 'Theo quốc gia', '/index.php?language=vi&nv=statistics&amp;op=allcountries', '', '', 2, 23, 1, '', '2', 'statistics', 'allcountries', 1, '', 1, 1), 
(22, 19, 1, 'Theo trình duyệt', '/index.php?language=vi&nv=statistics&amp;op=allbrowsers', '', '', 3, 24, 1, '', '2', 'statistics', 'allbrowsers', 1, '', 1, 1), 
(23, 19, 1, 'Theo hệ điều hành', '/index.php?language=vi&nv=statistics&amp;op=allos', '', '', 4, 25, 1, '', '2', 'statistics', 'allos', 1, '', 1, 1), 
(24, 19, 1, 'Máy chủ tìm kiếm', '/index.php?language=vi&nv=statistics&amp;op=allbots', '', '', 5, 26, 1, '', '2', 'statistics', 'allbots', 1, '', 1, 1), 
(25, 0, 1, 'Thăm dò ý kiến', '/index.php?language=vi&nv=voting', '', '', 6, 27, 0, '', '6', 'voting', '', 1, '', 1, 1), 
(30, 4, 1, 'Rss', '/index.php?language=vi&nv=news&op=rss', '', '', 5, 10, 1, '', '6', 'news', 'rss', 1, '', 0, 1), 
(27, 0, 1, 'Tìm kiếm', '/index.php?language=vi&nv=seek', '', '', 7, 28, 0, '', '6', 'seek', '', 1, '', 1, 1), 
(31, 4, 1, 'Đăng bài viết', '/index.php?language=vi&nv=news&op=content', '', '', 6, 11, 1, '', '6', 'news', 'content', 1, '', 0, 1), 
(32, 4, 1, 'Tìm kiếm', '/index.php?language=vi&nv=news&op=search', '', '', 7, 12, 1, '', '6', 'news', 'search', 1, '', 0, 1), 
(33, 0, 1, 'shops', '/index.php?language=vi&nv=shops', '', '', 1, 1, 0, '', '6', '', '', 1, '', 0, 1), 
(38, 0, 1, 'Addfun', '/index.php?language=vi&nv=nvtools&op=addfun', '', '', 10, 32, 0, '', '6', 'nvtools', '', 1, '', 0, 1), 
(37, 0, 1, 'Data', '/index.php?language=vi&nv=nvtools&op=data', '', '', 9, 31, 0, '', '6', 'nvtools', 'data', 1, '', 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modfuncs`
--

DROP TABLE IF EXISTS `nv4_vi_modfuncs`;
CREATE TABLE `nv4_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `alias` varchar(55) NOT NULL DEFAULT '',
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=103  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modfuncs`
--

INSERT INTO `nv4_vi_modfuncs` VALUES
(1, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(2, 'main', 'main', 'Main', 'about', 1, 0, 1, ''), 
(3, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(5, 'content', 'content', 'Content', 'news', 1, 1, 3, ''), 
(6, 'detail', 'detail', 'Detail', 'news', 1, 0, 4, ''), 
(7, 'main', 'main', 'Main', 'news', 1, 0, 5, ''), 
(9, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(10, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(11, 'rss', 'rss', 'Rss', 'news', 1, 1, 1, ''), 
(12, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(13, 'search', 'search', 'Search', 'news', 1, 1, 6, ''), 
(14, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(15, 'topic', 'topic', 'Topic', 'news', 1, 0, 7, ''), 
(16, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 8, ''), 
(17, 'active', 'active', 'Active', 'users', 1, 1, 8, ''), 
(18, 'changepass', 'changepass', 'Đổi mật khẩu', 'users', 1, 1, 6, ''), 
(19, 'editinfo', 'editinfo', 'Editinfo', 'users', 1, 0, 10, ''), 
(20, 'login', 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(21, 'logout', 'logout', 'Logout', 'users', 1, 1, 3, ''), 
(22, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 9, ''), 
(23, 'lostpass', 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 5, ''), 
(24, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(25, 'openid', 'openid', 'Openid', 'users', 1, 1, 7, ''), 
(26, 'register', 'register', 'Đăng ký', 'users', 1, 1, 4, ''), 
(27, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(28, 'allbots', 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(29, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(30, 'allcountries', 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(31, 'allos', 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(32, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(33, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(34, 'referer', 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(35, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(36, 'addads', 'addads', 'Addads', 'banners', 1, 0, 1, ''), 
(37, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(38, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(39, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 2, ''), 
(40, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(41, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(42, 'main', 'main', 'Main', 'banners', 1, 0, 3, ''), 
(43, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(44, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(46, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(47, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''), 
(48, 'regroups', 'regroups', 'Nhóm thành viên', 'users', 1, 0, 11, ''), 
(50, 'memberlist', 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 12, ''), 
(51, 'groups', 'groups', 'Groups', 'news', 1, 0, 9, ''), 
(52, 'tag', 'tag', 'Tag', 'news', 1, 0, 2, ''), 
(53, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(54, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(55, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(56, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(57, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(58, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 13, ''), 
(59, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''), 
(60, 'cart', 'cart', 'Cart', 'shops', 1, 0, 5, ''), 
(61, 'checkorder', 'checkorder', 'Checkorder', 'shops', 0, 0, 0, ''), 
(62, 'compare', 'compare', 'Compare', 'shops', 1, 0, 12, ''), 
(63, 'complete', 'complete', 'Complete', 'shops', 1, 0, 8, ''), 
(64, 'delhis', 'delhis', 'Delhis', 'shops', 0, 0, 0, ''), 
(65, 'detail', 'detail', 'Detail', 'shops', 1, 0, 3, ''), 
(66, 'group', 'group', 'Group', 'shops', 1, 0, 10, ''), 
(67, 'history', 'history', 'History', 'shops', 1, 0, 9, ''), 
(68, 'loadcart', 'loadcart', 'Loadcart', 'shops', 0, 0, 0, ''), 
(69, 'main', 'main', 'Main', 'shops', 1, 0, 1, ''), 
(70, 'order', 'order', 'Order', 'shops', 1, 0, 6, ''), 
(71, 'payment', 'payment', 'Payment', 'shops', 1, 0, 7, ''), 
(72, 'point', 'point', 'Point', 'shops', 1, 0, 15, ''), 
(73, 'print', 'print', 'Print', 'shops', 0, 0, 0, ''), 
(74, 'print_pro', 'print_pro', 'Print_pro', 'shops', 0, 0, 0, ''), 
(75, 'remove', 'remove', 'Remove', 'shops', 0, 0, 0, ''), 
(76, 'review', 'review', 'Review', 'shops', 0, 0, 0, ''), 
(77, 'rss', 'rss', 'Rss', 'shops', 0, 0, 0, ''), 
(78, 'search', 'search', 'Search', 'shops', 1, 0, 4, ''), 
(79, 'search_result', 'search_result', 'Search_result', 'shops', 1, 0, 11, ''), 
(80, 'sendmail', 'sendmail', 'Sendmail', 'shops', 0, 0, 0, ''), 
(81, 'service', 'service', 'Service', 'shops', 0, 0, 0, ''), 
(82, 'setcart', 'setcart', 'Setcart', 'shops', 0, 0, 0, ''), 
(83, 'shippingajax', 'shippingajax', 'Shippingajax', 'shops', 1, 0, 16, ''), 
(84, 'sitemap', 'sitemap', 'Sitemap', 'shops', 0, 0, 0, ''), 
(85, 'tag', 'tag', 'Tag', 'shops', 1, 0, 14, ''), 
(86, 'viewcat', 'viewcat', 'Viewcat', 'shops', 1, 0, 2, ''), 
(87, 'wishlist', 'wishlist', 'Wishlist', 'shops', 1, 0, 13, ''), 
(88, 'wishlist_update', 'wishlist_update', 'Wishlist_update', 'shops', 0, 0, 0, ''), 
(89, 'down', 'down', 'Down', 'download', 1, 0, 4, ''), 
(90, 'main', 'main', 'Main', 'download', 1, 1, 1, ''), 
(91, 'report', 'report', 'Report', 'download', 1, 0, 6, ''), 
(92, 'rss', 'rss', 'Rss', 'download', 0, 0, 0, ''), 
(93, 'search', 'search', 'Search', 'download', 1, 1, 7, ''), 
(94, 'sitemap', 'sitemap', 'Sitemap', 'download', 0, 0, 0, ''), 
(95, 'upload', 'upload', 'Upload', 'download', 1, 1, 5, ''), 
(96, 'viewcat', 'viewcat', 'Viewcat', 'download', 1, 0, 2, ''), 
(97, 'viewfile', 'viewfile', 'Viewfile', 'download', 1, 0, 3, ''), 
(98, 'addfun', 'addfun', 'Addfun', 'nvtools', 1, 1, 4, ''), 
(99, 'checktable', 'checktable', 'Checktable', 'nvtools', 0, 0, 0, ''), 
(100, 'data', 'data', 'Data', 'nvtools', 1, 1, 3, ''), 
(101, 'main', 'main', 'Main', 'nvtools', 1, 1, 1, ''), 
(102, 'theme', 'theme', 'Theme', 'nvtools', 1, 1, 2, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modthemes`
--

DROP TABLE IF EXISTS `nv4_vi_modthemes`;
CREATE TABLE `nv4_vi_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modthemes`
--

INSERT INTO `nv4_vi_modthemes` VALUES
(0, 'body', 'mobile_nukeviet'), 
(0, 'body-right', 'modern'), 
(0, 'left-body-right', 'default'), 
(2, 'body', 'mobile_nukeviet'), 
(2, 'body', 'modern'), 
(2, 'left-body-right', 'default'), 
(5, 'body', 'mobile_nukeviet'), 
(5, 'body-right', 'modern'), 
(5, 'left-body-right', 'default'), 
(6, 'body', 'mobile_nukeviet'), 
(6, 'body-right', 'modern'), 
(6, 'left-body-right', 'default'), 
(7, 'body', 'mobile_nukeviet'), 
(7, 'body-right', 'modern'), 
(7, 'left-body-right', 'default'), 
(11, 'body-right', 'modern'), 
(11, 'left-body-right', 'default'), 
(13, 'body', 'mobile_nukeviet'), 
(13, 'body-right', 'modern'), 
(13, 'left-body-right', 'default'), 
(15, 'body', 'mobile_nukeviet'), 
(15, 'body-right', 'modern'), 
(15, 'left-body-right', 'default'), 
(16, 'body', 'mobile_nukeviet'), 
(16, 'body-right', 'modern'), 
(16, 'left-body-right', 'default'), 
(17, 'body', 'mobile_nukeviet'), 
(17, 'body-right', 'modern'), 
(17, 'left-body-right', 'default'), 
(18, 'body', 'mobile_nukeviet'), 
(18, 'body-right', 'modern'), 
(18, 'left-body-right', 'default'), 
(19, 'body', 'mobile_nukeviet'), 
(19, 'body-right', 'modern'), 
(19, 'left-body-right', 'default'), 
(20, 'body', 'mobile_nukeviet'), 
(20, 'body-right', 'modern'), 
(20, 'left-body-right', 'default'), 
(21, 'body', 'mobile_nukeviet'), 
(21, 'body-right', 'modern'), 
(21, 'left-body-right', 'default'), 
(22, 'body', 'mobile_nukeviet'), 
(22, 'body-right', 'modern'), 
(22, 'left-body-right', 'default'), 
(23, 'body', 'mobile_nukeviet'), 
(23, 'body-right', 'modern'), 
(23, 'left-body-right', 'default'), 
(24, 'body', 'mobile_nukeviet'), 
(24, 'body-right', 'modern'), 
(24, 'left-body-right', 'default'), 
(25, 'body', 'mobile_nukeviet'), 
(25, 'body-right', 'modern'), 
(25, 'left-body-right', 'default'), 
(26, 'body', 'mobile_nukeviet'), 
(26, 'body-right', 'modern'), 
(26, 'left-body-right', 'default'), 
(27, 'body', 'mobile_nukeviet'), 
(27, 'body-right', 'modern'), 
(27, 'left-body-right', 'default'), 
(28, 'body', 'mobile_nukeviet'), 
(28, 'body', 'modern'), 
(28, 'left-body', 'default'), 
(29, 'body', 'mobile_nukeviet'), 
(29, 'body', 'modern'), 
(29, 'left-body', 'default'), 
(30, 'body', 'mobile_nukeviet'), 
(30, 'body', 'modern'), 
(30, 'left-body', 'default'), 
(31, 'body', 'mobile_nukeviet'), 
(31, 'body', 'modern'), 
(31, 'left-body', 'default'), 
(32, 'body', 'mobile_nukeviet'), 
(32, 'body', 'modern'), 
(32, 'left-body', 'default'), 
(33, 'body', 'mobile_nukeviet'), 
(33, 'body', 'modern'), 
(33, 'left-body', 'default'), 
(34, 'body', 'mobile_nukeviet'), 
(34, 'body', 'modern'), 
(34, 'left-body', 'default'), 
(35, 'body', 'mobile_nukeviet'), 
(35, 'body-right', 'modern'), 
(35, 'left-body-right', 'default'), 
(36, 'body', 'mobile_nukeviet'), 
(36, 'body-right', 'modern'), 
(36, 'left-body-right', 'default'), 
(39, 'body', 'mobile_nukeviet'), 
(39, 'body-right', 'modern'), 
(39, 'left-body-right', 'default'), 
(42, 'body', 'mobile_nukeviet'), 
(42, 'body-right', 'modern'), 
(42, 'left-body-right', 'default'), 
(43, 'body', 'mobile_nukeviet'), 
(43, 'body-right', 'modern'), 
(43, 'left-body-right', 'default'), 
(46, 'body', 'mobile_nukeviet'), 
(46, 'body-right', 'modern'), 
(46, 'left-body-right', 'default'), 
(47, 'body', 'mobile_nukeviet'), 
(47, 'body', 'modern'), 
(47, 'left-body-right', 'default'), 
(48, 'body', 'mobile_nukeviet'), 
(48, 'body-right', 'modern'), 
(48, 'left-body-right', 'default'), 
(50, 'body', 'mobile_nukeviet'), 
(50, 'body-right', 'modern'), 
(50, 'left-body-right', 'default'), 
(51, 'body', 'mobile_nukeviet'), 
(51, 'body-right', 'modern'), 
(51, 'left-body-right', 'default'), 
(52, 'body', 'mobile_nukeviet'), 
(52, 'body-right', 'modern'), 
(52, 'left-body-right', 'default'), 
(53, 'body', 'default'), 
(53, 'body', 'mobile_nukeviet'), 
(53, 'body', 'modern'), 
(54, 'body', 'mobile_nukeviet'), 
(54, 'body-right', 'modern'), 
(54, 'left-body-right', 'default'), 
(55, 'body', 'mobile_nukeviet'), 
(55, 'body-right', 'modern'), 
(55, 'left-body-right', 'default'), 
(56, 'body', 'mobile_nukeviet'), 
(56, 'body-right', 'modern'), 
(56, 'left-body-right', 'default'), 
(57, 'body', 'mobile_nukeviet'), 
(57, 'body-right', 'modern'), 
(57, 'left-body-right', 'default'), 
(60, 'body', 'mobile_nukeviet'), 
(60, 'body-right', 'modern'), 
(60, 'left-body-right', 'default'), 
(61, 'left-body-right', 'default'), 
(62, 'body', 'mobile_nukeviet'), 
(62, 'body-right', 'modern'), 
(62, 'left-body-right', 'default'), 
(63, 'body', 'mobile_nukeviet'), 
(63, 'body-right', 'modern'), 
(63, 'left-body-right', 'default'), 
(64, 'left-body-right', 'default'), 
(65, 'body', 'mobile_nukeviet'), 
(65, 'body-right', 'modern'), 
(65, 'left-body-right', 'default'), 
(66, 'body', 'mobile_nukeviet'), 
(66, 'body-right', 'modern'), 
(66, 'left-body-right', 'default'), 
(67, 'body', 'mobile_nukeviet'), 
(67, 'body-right', 'modern'), 
(67, 'left-body-right', 'default'), 
(68, 'left-body-right', 'default'), 
(69, 'body', 'mobile_nukeviet'), 
(69, 'body-right', 'modern'), 
(69, 'left-body-right', 'default'), 
(70, 'body', 'mobile_nukeviet'), 
(70, 'body-right', 'modern'), 
(70, 'left-body-right', 'default'), 
(71, 'body', 'mobile_nukeviet'), 
(71, 'body-right', 'modern'), 
(71, 'left-body-right', 'default'), 
(72, 'body', 'mobile_nukeviet'), 
(72, 'body-right', 'modern'), 
(72, 'left-body-right', 'default'), 
(73, 'left-body-right', 'default'), 
(74, 'left-body-right', 'default'), 
(75, 'left-body-right', 'default'), 
(76, 'left-body-right', 'default'), 
(77, 'left-body-right', 'default'), 
(78, 'body', 'mobile_nukeviet'), 
(78, 'body-right', 'modern'), 
(78, 'left-body-right', 'default'), 
(79, 'body', 'mobile_nukeviet'), 
(79, 'body-right', 'modern'), 
(79, 'left-body-right', 'default'), 
(80, 'left-body-right', 'default'), 
(81, 'left-body-right', 'default'), 
(82, 'left-body-right', 'default'), 
(83, 'body', 'mobile_nukeviet'), 
(83, 'body-right', 'modern'), 
(83, 'left-body-right', 'default'), 
(84, 'left-body-right', 'default'), 
(85, 'body', 'mobile_nukeviet'), 
(85, 'body-right', 'modern'), 
(85, 'left-body-right', 'default'), 
(86, 'body', 'mobile_nukeviet'), 
(86, 'body-right', 'modern'), 
(86, 'left-body-right', 'default'), 
(87, 'body', 'mobile_nukeviet'), 
(87, 'body-right', 'modern'), 
(87, 'left-body-right', 'default'), 
(88, 'left-body-right', 'default'), 
(89, 'body', 'mobile_nukeviet'), 
(89, 'body-right', 'modern'), 
(89, 'left-body-right', 'default'), 
(90, 'body', 'mobile_nukeviet'), 
(90, 'body-right', 'modern'), 
(90, 'left-body-right', 'default'), 
(91, 'body', 'mobile_nukeviet'), 
(91, 'body-right', 'modern'), 
(91, 'left-body-right', 'default'), 
(92, 'left-body-right', 'default'), 
(93, 'body', 'mobile_nukeviet'), 
(93, 'body-right', 'modern'), 
(93, 'left-body-right', 'default'), 
(94, 'left-body-right', 'default'), 
(95, 'body', 'mobile_nukeviet'), 
(95, 'body-right', 'modern'), 
(95, 'left-body-right', 'default'), 
(96, 'body', 'mobile_nukeviet'), 
(96, 'body-right', 'modern'), 
(96, 'left-body-right', 'default'), 
(97, 'body', 'mobile_nukeviet'), 
(97, 'body-right', 'modern'), 
(97, 'left-body-right', 'default'), 
(98, 'body', 'default'), 
(98, 'body', 'mobile_nukeviet'), 
(98, 'body-right', 'modern'), 
(99, 'left-body-right', 'default'), 
(100, 'body', 'default'), 
(100, 'body', 'mobile_nukeviet'), 
(100, 'body-right', 'modern'), 
(101, 'body', 'default'), 
(101, 'body', 'mobile_nukeviet'), 
(101, 'body-right', 'modern'), 
(102, 'body', 'default'), 
(102, 'body', 'mobile_nukeviet'), 
(102, 'body-right', 'modern');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_modules`
--

DROP TABLE IF EXISTS `nv4_vi_modules`;
CREATE TABLE `nv4_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) DEFAULT '',
  `mobile` varchar(100) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `keywords` text,
  `groups_view` varchar(255) NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_modules`
--

INSERT INTO `nv4_vi_modules` VALUES
('about', 'page', 'about', 'Giới thiệu', '', 1276333182, 1, 1, '', '', '', '', '6', 3, 1, '', 0, 0), 
('news', 'news', 'news', 'Tin Tức', '', 1270400000, 1, 1, '', '', '', '', '6', 4, 1, '', 1, 0), 
('users', 'users', 'users', 'Thành viên', 'Tài khoản', 1274080277, 1, 1, '', '', '', '', '6', 5, 1, '', 0, 0), 
('contact', 'contact', 'contact', 'Liên hệ', '', 1275351337, 1, 1, '', '', '', '', '6', 6, 1, '', 0, 0), 
('statistics', 'statistics', 'statistics', 'Thống kê', '', 1276520928, 1, 1, '', '', '', 'truy cập, online, statistics', '2', 7, 1, '', 0, 0), 
('voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1275315261, 1, 1, '', '', '', '', '6', 8, 1, '', 1, 0), 
('banners', 'banners', 'banners', 'Quảng cáo', '', 1270400000, 1, 1, '', '', '', '', '6', 9, 1, '', 0, 0), 
('seek', 'seek', 'seek', 'Tìm kiếm', '', 1273474173, 1, 0, '', '', '', '', '6', 10, 1, '', 0, 0), 
('menu', 'menu', 'menu', 'Menu Site', '', 1295287334, 0, 1, '', '', '', '', '6', 11, 1, '', 0, 0), 
('feeds', 'feeds', 'feeds', 'Rss Feeds', '', 1279366705, 1, 1, '', '', '', '', '6', 12, 1, '', 0, 0), 
('page', 'page', 'page', 'Page', '', 1279366705, 1, 1, '', '', '', '', '6', 13, 1, '', 0, 0), 
('comment', 'comment', 'comment', 'Bình luận', 'Quản lý bình luận', 1279366705, 1, 1, '', '', '', '', '6', 14, 1, '', 0, 0), 
('shops', 'shops', 'shops', 'shops', '', 1432350307, 1, 1, '', '', '', '', '6', 1, 1, '', 1, 0), 
('download', 'download', 'download', 'download', '', 1432353414, 1, 1, '', '', '', '', '6', 15, 1, '', 1, 0), 
('nvtools', 'nvtools', 'nvtools', 'nvtools', '', 1432784905, 1, 0, '', '', '', '', '6', 2, 1, '', 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_1`
--

DROP TABLE IF EXISTS `nv4_vi_news_1`;
CREATE TABLE `nv4_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_1`
--

INSERT INTO `nv4_vi_news_1` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 1, 0, 0, 0), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 1, 1, '6', 1, 1, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 4, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_10`
--

DROP TABLE IF EXISTS `nv4_vi_news_10`;
CREATE TABLE `nv4_vi_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_10`
--

INSERT INTO `nv4_vi_news_10` VALUES
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_11`
--

DROP TABLE IF EXISTS `nv4_vi_news_11`;
CREATE TABLE `nv4_vi_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_11`
--

INSERT INTO `nv4_vi_news_11` VALUES
(7, 11, '11', 0, 1, '', 2, 1307197282, 1307197381, 1, 1307197260, 0, 2, 'Tuyển dụng lập trình viên, chuyên viên đồ họa phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-chuyen-vien-do-hoa-phat-trien-NukeViet', 'Bạn đam mê nguồn mở? Bạn có năng khiếu lập trình PHP & MySQL? Bạn là chuyên gia đồ họa, HTML, CSS? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'nukeviet-job.jpg', '6', 1, 1, '2', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_12`
--

DROP TABLE IF EXISTS `nv4_vi_news_12`;
CREATE TABLE `nv4_vi_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_12`
--

INSERT INTO `nv4_vi_news_12` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 1, 0, 0, 0), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_2`
--

DROP TABLE IF EXISTS `nv4_vi_news_2`;
CREATE TABLE `nv4_vi_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_2`
--

INSERT INTO `nv4_vi_news_2` VALUES
(5, 2, '2', 1, 1, '', 5, 1274993307, 1275318039, 1, 1274993280, 0, 2, 'Giới thiệu về mã nguồn mở NukeViet', 'Gioi-thieu-ve-ma-nguon-mo-NukeViet', 'Chắc hẳn đây không phải lần đầu tiên bạn nghe nói đến mã nguồn mở. Và nếu bạn là người mê lướt web thì hẳn bạn từng nhìn thấy đâu đó cái tên NukeViet. NukeViet, phát âm là Nu-Ke-Việt, chính là phần mềm dùng để xây dựng các Website mà bạn ngày ngày online để truy cập đấy.', 'screenshot.jpg', '6', 1, 0, '2', 1, 1, 0, 0, 0), 
(9, 2, '2', 0, 1, 'Phạm Thế Quang Huy', 4, 1322685396, 1322686088, 1, 1322685396, 0, 2, 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 'NukeViet-Cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-Viet-Nam', '(Dân trí) - Là một trong những hệ quản trị nội dung nổi tiếng hàng đầu tại Việt Nam, NukeViet đã được áp dụng rộng rãi trong việc xây dựng nhiều trang báo điện tử và các cổng thông tin điện tử nổi tiếng tại Việt Nam. Mới đây nhất, NukeViet đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011', 'product_box.jpg', 'Sản phẩm dự thi Nhân tài Đất Việt 2011&#x3A; Mã nguồn mở NukeViet', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_8`
--

DROP TABLE IF EXISTS `nv4_vi_news_8`;
CREATE TABLE `nv4_vi_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_8`
--

INSERT INTO `nv4_vi_news_8` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 1, 0, 0, 0), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 1, 1, '6', 1, 1, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_9`
--

DROP TABLE IF EXISTS `nv4_vi_news_9`;
CREATE TABLE `nv4_vi_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_9`
--

INSERT INTO `nv4_vi_news_9` VALUES
(8, 9, '9', 0, 1, 'laser', 3, 1310067949, 1310068009, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 4, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_admins`
--

DROP TABLE IF EXISTS `nv4_vi_news_admins`;
CREATE TABLE `nv4_vi_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_block`
--

DROP TABLE IF EXISTS `nv4_vi_news_block`;
CREATE TABLE `nv4_vi_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_block`
--

INSERT INTO `nv4_vi_news_block` VALUES
(1, 5, 3), 
(1, 2, 2), 
(1, 1, 1), 
(2, 6, 4), 
(2, 5, 3), 
(2, 2, 2), 
(2, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_block_cat`
--

DROP TABLE IF EXISTS `nv4_vi_news_block_cat`;
CREATE TABLE `nv4_vi_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_block_cat`
--

INSERT INTO `nv4_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', 'Tin mới nhất', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv4_vi_news_bodyhtml_1`;
CREATE TABLE `nv4_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_bodyhtml_1`
--

INSERT INTO `nv4_vi_news_bodyhtml_1` VALUES
(1, '<p style=\"text-align: justify;\"> Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam.<br /> <br /> Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế.<br /> <br /> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet.<br /> <br /> NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn</p><blockquote> <p style=\"text-align: justify;\"> <em>Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (<a href=\"http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm\" target=\"_blank\">xem chi tiết</a>), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (<a href=\"http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov\" target=\"_blank\">xem chi tiết</a>); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.</em></p></blockquote>', 'http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm', 1, 0, 1, 1, 1, 0), 
(2, '<p style=\"font-weight: bold;\"> <span style=\"font-size: 14pt;\">Câu chuyện của NukeViet và VINADES.,JSC</span></p><p style=\"font-weight: bold;\"> Từ một trăn trở</p><p style=\"text-align: justify;\"> Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề &quot;Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet&quot;.</p><p> Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định...</p><p> <span style=\"font-weight: bold;\">Gặp mặt</span></p><p> Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này.</p><p> <span style=\"font-weight: bold;\">Một mô hình - một lối đi</span></p><p style=\"text-align: justify;\"> Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: &quot;Thành lập doanh nghiệp chuyên quản NukeViet&quot;. Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn.</p><p> <br /> <span style=\"font-weight: bold;\">Triển khai thực hiện</span></p><p style=\"text-align: justify;\"> Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin &quot;Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam&quot;. Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương:</p><div style=\"text-align: center;\"> <img alt=\"Anh Tú phát biểu khai trương VINADES.,JSC \" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhtu-phatbieu.jpg\" style=\"border: 0px solid;\" width=\"500\" /></div><div style=\"text-align: center;\"> Anh Tú phát biểu khai trương VINADES.,JSC <p> <br /> <img alt=\"\" border=\"0\" src=\"http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg\" style=\"width: 500px;\" width=\"500\" /></p> <p> Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động.</p> <p> <br /> <img alt=\"\" border=\"0\" height=\"332\" src=\"http://nukeviet.vn/uploads/spaw2/images/nangly.jpg\" style=\"width: 500px; height: 332px;\" width=\"500\" /></p> <p> Cùng nâng ly chúc mừng khai trương.</p></div><p style=\"font-weight: bold;\"> ... và lời cảm ơn gửi tới cộng đồng</p><p style=\"text-align: justify;\"> VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. &quot;Lửa thử vàng, gian nan thử sức&quot;, mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng.</p><p>  </p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Văn phòng làm việc của VINADES.,JSC ở Hà Nội.</p><div style=\"text-align: center;\"> <img alt=\"\" border=\"0\" height=\"375\" src=\"http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg\" style=\"width: 500px; height: 375px;\" width=\"500\" /></div><p>  </p><p style=\"text-align: center;\"> Một góc văn phòng nhìn từ trong ra ngoài.</p><p style=\"font-weight: bold;\"> NukeViet 3.0 - Cuộc cách mạng của NukeViet</p><p style=\"text-align: justify;\"> Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua.</p><div style=\"text-align: justify;\"> NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: <a href=\"http://nukeviet.vn/phpbb/viewforum.php?f=99\" target=\"_blank\">http://nukeviet.vn/phpbb/viewforum.php?f=99</a></div>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC-2/', 1, 0, 1, 1, 1, 0), 
(5, '<p> <strong><span style=\"font-size: 14px;\">THÔNGTIN VỀ MÃ NGUỒN MỞ NUKEVIET</span></strong></p><p style=\"font-weight: bold;\"> I. Giới thiệu chung:</p><p> NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System), người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền Web.</p><p> NukeViet có 2 dòng phiên bản chính:</p><p> Dòng phiên bản trước năm 2009 (NukeViet 2.0 trở về trước) được Nguyễn Anh Tú- một lưu học sinh người Việt tại Nga - cùng cộng đồng phát triển thành một ứng dụng thuần Việt từ nền tảng PHP-Nuke.</p><p> Dòng phiên bản NukeViet 3.0 trở về sau (kể từ năm 2010 trở đi) là dòng phiên bản hoàn toàn mới, được xây dựng từ đầu với nhiều tính năng ưu việt.</p><p> NukeViet được viết bằng ngôn ngữ PHP và chủ yếu sử dụng cơ sở dữ liệu MySQL, cho phép người sử dụng có thể dễ dàng xuất bản &amp;quản trị các nội dung của họ lên Internet hoặc Intranet.</p><p> NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng.</p><p style=\"text-align: justify;\"> NukeViet là giải pháp hoàn hảo cho các Website từ cá nhân cho tới các doanh nghiệp. NukeViet là bộ mã nguồn chất lượng cao, được phát hành theo giấy phép mã nguồn mở nên việc sử dụng NukeViet hoàn toàn miễn phí. Với người sử dụng cá nhân, tất cả đều có thể tự tạo cho mình một website chuyên nghiệp mà không mất bất cứ chi phí nào. Với những nhà phát triển Web, sử dụng NukeViet có thể nhanh chóng xây dựng các hệ thống lớn mà việc lập trình không đòi hỏi quá nhiều thời gian vì NukeViet đã xây dựng sẵn hệ thống quản lý ưu việt.</p> <p>Thông tin chi tiết về NukeViet có thể tìm thấy ở bách khoa toàn thư mở Wikipedia: <a href=\"http://vi.wikipedia.org/wiki/NukeViet\">http://vi.wikipedia.org/wiki/NukeViet</a></p><p style=\"font-weight: bold;\"> II. Thông tin về diễn đàn NukeViet:</p><p> Diễn đàn NukeViet hoạt động trên website: <a href=\"http://nukeviet.vn/\"><span style=\"font-weight: bold;\">http://nukeviet.vn</span></a> hiện có trên 22.000 thành viên thực gồm học sinh, sinh viên &amp; nhiều thành phần khác thuộc giới trí thức ở trong và ngoài nước.</p><p> Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng,văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an...</p><p> Nhiều học sinh, sinh viên tham gia diễn đàn NukeViet, đam mê mã nguồn mở và đã thành công với chính công việc mà họ yêu thích.</p>', 'http://nukeviet.vn/vi/news/Tin-tuc/Gioi-thieu-ve-ma-nguon-mo-NukeViet-5/', 1, 0, 1, 1, 1, 0), 
(6, '<div style=\"text-align: center;\"> <h2 style=\"color: rgb(255, 69, 0);\"> THƯ MỜI HỢP TÁC</h2> <h4> TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN</h4> <h2> MÃ NGUỒN MỞ NUKEVIET</h2> </div> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\">  </p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm; font-weight: bold;\"> Phương thức hợp tác nhưsau:</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 1.Quảng cáo, trao đổi banner, liên kết website:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên website &amp; hệ thống kênh truyền thông của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Quảng bá rộng rãi cho đối tượng của 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm chi phí quảng bá cho 2 bên.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 2.Hợp tác cung cấp hosting thử nghiệm NukeViet:</p> <p style=\"text-align: justify; line-height: 130%;\"> a. Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên ký hợp đồng nguyên tắc &amp; thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet.</p> <p style=\"text-align: justify; line-height: 130%;\"> b. Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Mở rộng thị trường theo cả hướng đối tượng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh.</p> <p style=\"text-align: justify; line-height: 130%;\"> c. Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 3,Hợp tác nhân lực hỗ trợ người sử dụng:</p> <p style=\"text-align: justify; line-height: 130%;\"> a, Mô tả hình thức:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác.</p> <p style=\"text-align: justify; line-height: 130%;\"> b, Lợi ích:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Tăng hiệu quả hỗ trợ khách hàng.</p> <p style=\"text-align: justify; line-height: 130%;\"> c, Trách nhiệm:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này.</p> <p style=\"text-align: justify; line-height: 130%; font-weight: bold;\"> 4. Các hình thức khác:</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam.</p> <p style=\"text-align: justify; line-height: 130%; text-indent: 1cm;\"> Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”.</p> <p style=\"text-align: justify; line-height: 130%; font-style: italic; text-indent: 1cm;\"> Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị.</p> <span style=\"font-weight: bold;\">Thông tin liên hệ:</span> <p style=\"text-align: justify;\"> CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC)</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Điện thoại: (84-4) 85 872007</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Fax: (84-4) 35 500 914</p> <p style=\"text-align: justify; text-indent: 1cm;\"> Website: <a href=\"http://www.vinades.vn/\">www.vinades.vn</a> – <a href=\"http://www.nukeviet.vn/\">www.nukeviet.vn</a></p> <p style=\"text-align: justify; text-indent: 1cm;\"> Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', 'http://vinades.vn/vi/news/thong-cao-bao-chi/Thu-moi-hop-tac-6/', 1, 0, 1, 1, 1, 0), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài là các lập trình viên PHP và MySQL, Chuyên Viên Đồ Hoạ để làm việc cho công ty, hiện thực hóa ước mơ một nguồn mở chuyên nghiệp cho Việt Nam vươn ra thế giới.<br /><br />Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân.<br /><p style=\"text-align: justify;\"> <strong>1. Vị trí dự tuyển</strong>: Chuyên viên đồ hoạ; Lập trình viên.</p><p style=\"text-align: justify;\"> <strong>2. Mô tả công việc:</strong></p>Với vị trí lập trình viên PHP &amp; MySQL: Viết module trên nền NukeViet, tham gia phát triển hệ thống NukeViet.<br /><p style=\"text-align: justify;\"> Nếu là chuyên viên đồ họa, kỹ thuật viên cắt giao diện... bạn có thể đảm nhiệm một trong các công việc sau:</p><p style=\"margin-left: 40px; text-align: justify;\"> + Vẽ và cắt giao diện.</p><p style=\"margin-left: 40px; text-align: justify;\"> + Valid CSS, xHTML.</p><p style=\"margin-left: 40px; text-align: justify;\"> + Ghép giao diện cho hệ thống.</p><strong>3. Yêu cầu: </strong><br /><br />Lập trình viên PHP &amp; MySQL: Thành thạo PHP, MySQL. Biết CSS, XHTML, JavaScript là một ưu thế.<br /><br />Chuyên viên đồ họa: Sử dụng thành thạo một trong các phần mềm Photoshop, illustrator, 3Dmax, coreldraw. Biết CSS, xHTML.<p style=\"text-align: justify; margin-left: 40px;\"> + Trình độ tối thiểu cho người làm đồ họa web: Biết vẽ giao diện hoặc cắt PSD ra xHTML &amp; CSS.</p><p style=\"text-align: justify; margin-left: 40px;\"> + Ưu tiên người cắt giao diện đạt chuẩn W3C (Test trên Internet Explorer 7+, FireFox 3+, Chrome 8+, Opera 10+)</p>Chúng tôi ưu tiên các ứng viên có kỹ năng làm việc độc lập, làm việc theo nhóm, có tinh thần trách nhiệm cao, chủ động trong công việc.<br /><p style=\"text-align: justify;\"> <strong>4: Quyền lợi:</strong></p><p style=\"text-align: justify;\"> <strong>-</strong> Lương: thoả thuận, trả qua ATM.</p><p style=\"text-align: justify;\"> - Thưởng theo dự án, các ngày lễ tết.</p><p style=\"text-align: justify;\"> - Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội...</p><p style=\"text-align: justify;\"> <strong>5. Thời gian làm việc:</strong> Toàn thời gian cố định hoặc làm <strong>online</strong>.</p><p style=\"text-align: justify;\"> <strong>6. Hạn nộp hồ sơ</strong>: Không hạn chế, vui lòng kiểm tra tại <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a></p><p style=\"text-align: justify;\"> <strong>7. Hồ sơ bao gồm:</strong></p><p style=\"text-align: justify;\"> &nbsp;&nbsp;<strong>&nbsp; *&nbsp; Cách thức đăng ký dự tuyển</strong>: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư tuyendung@vinades.vn<br /> &nbsp;&nbsp;&nbsp; *&nbsp; <strong>Nội dung hồ sơ xin việc file mềm gồm</strong>:<br /> <br /> <strong>+ Đơn xin việc:</strong> Tự biên soạn.</p><p style=\"text-align: justify;\"> <strong>+ Thông tin ứng viên:</strong> Theo mẫu của VINADES.,JSC (dowload tại đây: <strong><u><a href=\"http://vinades.vn/vi/download/Thong-tin-ung-vien/Mau-ly-lich-ung-vien/\" target=\"_blank\" title=\"Mẫu lý lịch ứng viên\">Mẫu lý lịch ứng viên</a></u></strong>)<br /> <br /> Chi tiết vui lòng tham khảo tại: <a href=\"http://vinades.vn/vi/news/Tuyen-dung/\" target=\"_blank\">http://vinades.vn/vi/news/Tuyen-dung/</a><br /> <br /> Mọi thắc mắc vui lòng liên hệ:<br /> <br /> <strong>Công ty cổ phần phát triển nguồn mở Việt Nam.</strong><br /> Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.</p><div> - Tel: +84-4-85872007 - Fax: +84-4-35500914<br /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a> - Website: <a href=\"http://www.vinades.vn/\">http://www.vinades.vn</a></div>', 'http://vinades.vn/vi/news/Tuyen-dung/', 2, 0, 1, 1, 1, 0), 
(8, '<p style=\"text-align: justify;\"> <span style=\"font-size:16px;\"><strong>Giảm giá tới 90% giá module, ngày nào cũng là ngày &quot;mua chung&quot; trên webnhanh.vn!</strong></span></p><p style=\"text-align: justify;\"> Như thông báo trên webnhanh.vn, chương trình &quot;<a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Mua-chung-tren-Webnhanhvn-se-giam-gia-90-gia-module-da-cong-bo-245/\" target=\"_blank\"><strong>mua chung module</strong></a>&quot; nằm trong chính sách chung của webnhanh.vn trong việc hỗ trợ phát triển mã nguồn mở, giúp cho mọi người được hưởng những dịch vụ thiết kế website tốt nhất với chi phí thấp nhất. Tham gia chương trình này, bạn chỉ phải trả số tiền bằng 1/10 giá trị module mà vẫn được sở hữu module với tính năng hấp dẫn mà bạn&nbsp; mong muốn.<br /> <br /> Cụ thể, các module trong <a href=\"http://webnhanh.vn/vi/nvresources/cat/Modules-1/\" target=\"_blank\"><strong>kho module của webnhanh.vn</strong></a> đang chờ hoàn thiện sẽ được giảm giá tới 90% nếu khách hàng đăng ký mua chung module. Tuy nhiên sau 2 tháng thực hiện, Ban Quản Trị webnhanh.vn thấy rằng khả năng xuất hiện nhu cầu cùng mua chung 1 sản phẩm và dịch vụ có tính đặc thù như code dành cho web là rất thấp. Chính vì thế webnhanh.vn đã giảm giá đồng loạt các module trên webnhanh.vn để khách hàng có nhu cầu sẽ có nhiều cơ hội được sử dụng các module mà mình mong muốn cung cấp lên website.<br /> <br /> Đại đa số các module sẽ được giảm giá xuống mức giá siêu rẻ để đảm bảo mọi người đều có khả năng sử dụng. Đặc biệt với các module có mức giá từ 10-20 triệu đồng sẽ giảm giá xuống còn ở mức 1-5 triệu đồng.<br /> <br /> <span style=\"font-size:16px;\"><strong>Giá rẻ hơn, nhiều giao diện hơn cho web</strong></span></p><p style=\"text-align: justify;\"> Ngoài việc giảm giá <a href=\"http://webnhanh.vn/vi/nvresources/cat/Giao-dien-3/\" target=\"_blank\"><strong>các giao diện website</strong></a> do VINADES.,JSC thiết kế (từ mức giá 2 triệu đồng xuống còn 300 đến 700 ngàn đồng). Webnhanh.vn cũng sẽ cải thiện kho giao diện của mình bằng cách đưa vào sử dụng các mẫu giao diện của các nhà thiết kế giao diện khác với giá trung bình khoảng 300 ngàn đồng (chi phí chuyển template thành giao diện có thể cài đặt cho website). Khách hàng cũng có thể gửi mẫu giao diện (đã cắt HTML) để chúng tôi thực hiện việc ghép giao diện với mức giá 300-500 ngàn đồng (áp dụng mô hình giá chia sẻ của VINADES.,JSC&nbsp; trong <strong><a href=\"http://vinades.vn/vi/news/San-pham/Thiet-ke-giao-dien-14/\" target=\"_blank\">thiết kế giao diện web</a></strong> <sup>(*)</sup>).<br /> <br /> <span style=\"font-size:16px;\"><strong>Giảm giá các gói web dựng sẵn, nâng cao chất lượng và cấu hình dịch vụ</strong></span></p><p style=\"text-align: justify;\"> Cơ cấu chất lượng sản phẩm và dịch vụ cũng thay đổi theo hướng nâng cao rõ rệt. Ngoài việc giảm giá các <strong><a href=\"http://webnhanh.vn/vi/nvresources/package/\" target=\"_blank\">gói web dựng sẵn</a></strong>, webnhanh.vn đồng thời nâng cao chất lượng các dịch vụ đi kèm của các gói web này. Theo đó ngoài việc kéo dài thời gian bảo hành miễn phí lên 12 tháng, đồng thời webnhanh.vn cũng kéo dài thời gian sử dụng hosting miễn phí lên 12 tháng. Với mức hỗ trợ này, website thiết kế trên webnhanh.vn đảm bảo chất lượng cao và mức giá còn rẻ hơn cả các nhà cung cấp dịch vụ web giá rẻ. Đây là cơ hội rất lớn cho <strong><a href=\"http://webnhanh.vn/vi/dealers/\" target=\"_blank\">các đại lý của webnhanh.vn</a></strong> để tạo nên lợi thế cạnh tranh về chất lượng và giá cả dịch vụ.<br /> <br /> <strong><sup>(*)</sup> &quot;Giá chia sẻ&quot;</strong> là mức giá tiết kiệm cho khách hàng, nếu mua với mức giá này khách hàng sẽ tiết kiệm chi phí thiết kế giao diện một cách tối đa mà vẫn được toàn quyền sử dụng mẫu giao diện đã đặt hàng. Webnhanh.vn sẽ giữ lại mẫu giao diện này và đưa vào thư viện giao diện để cung cấp cho các khách hàng khác. Mô hình &quot;Giá chia sẻ&quot; sử dụng cho các khách hàng không quá khắt khe về việc đảm bảo tính duy nhất của mẫu giao diện đồng thời giúp webnhanh.vn làm phong phú thêm kho giao diện của mình.</p><strong>Chú ý:</strong> Ngoài việc cung cấp các gói web dựng sẵn với chi phí thấp phục vụ người dùng phổ thông, <strong><a href=\"http://vinades.vn\">VINADES.,JSC</a></strong> vẫn duy trì dịch vụ thiết kế giao diện riêng và thiết kế website theo yêu cầu để phục vụ những khách hàng có nhu cầu riêng biệt và cao cấp hơn, khách hàng có nhu cầu vui lòng truy cập <a href=\"http://vinades.vn\" target=\"_blank\">http://vinades.vn</a> hoặc liên hệ nhân viên kinh doanh của VINADES.,JSC để được tư vấn và báo giá dịch vụ.<br /><br /><div style=\"text-align: justify;\"> Như vậy, cùng với việc tham gia cung cấp hosting chuyên nghiệp dành cho NukeViet của các nhà cung cấp hosting trong và ngoài nước như <strong><a href=\"http://vinades.vn/vi/news/Doi-tac/VINADES-JSC-va-DIGISTAR-hop-tac-trong-viec-phat-trien-ma-nguon-mo-NukeViet-17/\">DIGISTAR</a></strong>, <strong><a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/TMDHosting-cung-cap-dich-vu-hosting-chuyen-NukeViet-64/\" title=\"TMDHosting cung cấp dịch vụ hosting chuyên NukeViet\">TMDHosting</a></strong> hay <strong><a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/SiteGround-cung-cap-dich-vu-hosting-chuyen-NukeViet-59/\" title=\"SiteGround cung cấp dịch vụ hosting chuyên NukeViet\">SiteGround</a></strong>, <a href=\"http://nukeviet.vn/vi/news/the-gioi-cong-nghe/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/\" title=\"Webnhanh.vn - website đầu tiên thiết kế website và bán code chuyên nghiệp dành cho NukeViet\"><strong>Webnhanh.vn</strong> là website đầu tiên có dịch vụ thiết kế website và bán code chuyên nghiệp</a> dành riêng cho NukeViet. Sự chuyên nghiệp hóa trong các khâu từ phát triển đến cung cấp dịch vụ cho mã nguồn mở NukeViet sẽ mở ra một cơ hội phát triển mới cho người sử dụng web ở Việt Nam.</div>', 'http://nukeviet.vn/vi/news/website/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/', 2, 0, 1, 1, 1, 0), 
(9, '<div> Nhắc đến các hệ thống quản trị nội dung (Content Management System – CMS) để quản lý các cổng thông tin điện tử trên Internet, không ít người sẽ nhắc đến các bộ công cụ như Joomla hay Wordpress. Tuy nhiên, có một sản phẩm hoàn toàn thuần Việt, do người Việt xây dựng không hề thua kém những sản phẩm trên cả về tính năng lẫn khả năng ứng dụng, đó là NukeViet của nhóm tác giả thuộc Công ty Cổ phần phát triển nguồn mở Việt Nam (VINADES).</div><div> &nbsp;</div><div> Với NukeViet, người dùng tại Việt Nam sẽ vượt qua các trở ngại về rào cản ngôn ngữ, có thể xây dựng và vận hành các trang web một cách dễ dàng nhất, đồng thời nhận được sự hỗ trợ của cộng đồng người dùng và các nhà phát triển cũng chính là người Việt Nam.</div><div> &nbsp;</div><div> Mới đây nhất, Ban giám khảo <span style=\"FONT-STYLE: italic\">Giải thưởng Nhân Tài Đất Việt 2011</span> đã quyết định đưa NukeViet vào danh sách các sản phẩm đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của <span style=\"FONT-STYLE: italic\">Giải Thưởng Nhân Tài Đất Việt 2011</span> diễn ra vào ngày 17-18/11 tới đây.</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Những ý tưởng giúp hình thành nên sản phẩm “thuần Việt”</span></div><div> &nbsp;</div><div> Theo chia sẻ của đại diện nhóm tác giả, năm 2004, anh Nguyễn Anh Tú, một lưu học sinh người Việt tại Nga với ý tưởng xây dựng một website để kết nối cộng đồng sinh viên du học đã sử dụng bộ CMS mã nguồn mở PHP-Nuke để thực hiện.</div><div> &nbsp;</div><div> Sau đó, anh Nguyễn Anh Tú đã phát triển và cải tiến bộ mã nguồn mở PHP-Nuke để chia sẻ cho các thành viên có nhu cầu xây dựng website một cách đơn giản và thuận tiện hơn. Được sự đón nhận của đông đảo người sử dụng, bộ mã nguồn đã liên tục được phát triển và trở thành một ứng dụng thuần Việt với tên gọi NukeViet. NukeViet đã nhanh chóng trở nên phổ biến trong giới các nhà xây dựng và phát triển website tại Việt Nam.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-1_4b905.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Giao diện một website tin tức được xây dựng bằng NukeViet</span></span></div><div> &nbsp;</div><div> Trong quá trình phát triển NukeViet, có một điều đội ngũ kỹ thuật luôn trăn trở là làm sao để có thể nâng cao tỉ lệ đóng góp của người Việt vào trong mã nguồn sản phẩm. Chính vì ý thức được điều này nên mức độ thuần Việt của sản phẩm ngày càng được nâng cao trong từng phiên bản phát hành. Cho đến phiên bản 3.0 (phát hành tháng 10 năm 2010) thì NukeViet đã thực sự trở thành một sản phẩm mã nguồn mở riêng của Việt Nam với 100% dòng code được viết mới.</div><div> &nbsp;</div><div> Kể từ đây, cộng đồng mã nguồn mở Việt Nam đã có riêng một bộ mã nguồn thuần Việt, tự hào sánh bước ngang vai cùng các cộng đồng mã nguồn mở khác trên thế giới. NukeViet ra đời đã giúp cộng đồng mạng Việt Nam giải quyết nhu cầu và mong muốn có một bộ mã nguồn mở của riêng Việt Nam, giúp phát triển hệ thống website của người Việt một cách an toàn nhất, đảm bảo nhất.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-2_600d0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Một website bán hành trực tuyến xây dựng bằng NukeViet</span></span></div><div> &nbsp;</div><div> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Khả năng ứng dụng và những ưu điểm của NukeViet</span></div><div> &nbsp;</div><div> Kể từ khi ra đời và trải qua một quá trình dài phát triển, NukeViet hiện được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block...&nbsp;</div><div> &nbsp;</div><div> NukeViet chủ yếu được sử dụng làm trang tin tức &nbsp;nhờ module News tích hợp sẵn trong NukeViet được viết rất công phu, nó lại đặc biệt phù hợp với yêu cầu và đặc điểm sử dụng cho hệ thống tin tức. NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng do đó thường được những đối tượng người dùng không chuyên ưa thích.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-4_416a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-SIZE: 10pt\"><span style=\"FONT-FAMILY: Tahoma\">Website phòng Giáo dục và Đào tạo Lạng Giang được xây dựng trên mã nguồn NukeViet</span></span></div><div> &nbsp;</div><div> NukeViet có mã nguồn mở do đó việc sử dụng NukeViet là hoàn toàn miễn phí cho tất cả mọi người trên thế giới. Từ phiên bản 2.0 trở về trước, đối tượng người dùng chủ yếu của NukeViet là người Việt vì những đặc điểm của bản thân mã nguồn (có nguồn gốc từ PHP-Nuke) và vì chính sách của nhóm phát triển là: &quot;hệ thống Portal dành cho người Việt&quot;. Tuy nhiên, kể từ phiên bản 3.0, đội ngũ phát triển NukeViet định hướng đưa NukeViet ra cộng đồng quốc tế với hỗ trợ thêm nhiều ngôn ngữ.&nbsp;</div><div> &nbsp;</div><div> Trên thực tế, với những ưu điểm vượt trội của mình, NukeViet 3 đã được ứng dụng ở hàng ngàn website khác nhau. Đặc biệt, không ít các cơ quan, tổ chức của Nhà nước đã tin tưởng sử dụng mã nguồn NukeViet để xây dựng cổng thông tin điện tử của mình, như &nbsp;Cổng thông tin tích hợp 1 cửa cho Phòng giáo dục Lạng Giang, cổng thông tin 2 chiều - Công ty cổ phần đầu tư tài chính công đoàn dầu khí Việt Nam, Hệ thống tra cứu điểm, tra cứu văn bằng - Cổng thông tin Sở GD&amp;ĐT Quảng Ninh, Website viện y học cổ truyền Quân Đội…</div><div> &nbsp;</div><div> Tất cả các dự án trên đều được khách hàng đánh giá rất cao về tính ứng dụng, hiệu quả do tiết kiệm chi phí và đáp ứng rất tốt nhu cầu sử dụng của các đơn vị.&nbsp;</div><div> &nbsp;</div><div> <span style=\"FONT-WEIGHT: bold\">Hướng phát triển trong tương lai và những kỳ vọng trước mắt</span></div><div> &nbsp;</div><div> Với ý nghĩa là phần mềm quản lý website (chiếm tới 90% các giao tiếp và tương tác trực tiếp với người sử dụng trên môi trường internet), khi phát triển, NukeViet sẽ trở thành một công cụ truyền thông rất mạnh, có thể đem lại những hiệu quả to lớn khác. Nhóm phát triển sẽ phát huy lợi thế này để phát triển sản phẩm.</div><div> &nbsp;</div><div> Nhóm phát triển cũng muốn tăng cường các khả năng liên kết, chia sẻ và tích hợp dữ liệu giữa các hệ thống khác nhau nhằm tạo nên một mạng lưới lớn, rộng khắp và hoàn chỉnh, có thể huy động sức mạnh tổng lực, thực hiện các nhiệm vụ xã hội khác trên mã nguồn NukeViet của mình.</div><div> &nbsp;</div><div> NukeViet khi được kết hợp với xu thế phát triển của điện toán đám mây sẽ trở thành một nền tảng giúp phát triển nhiều hệ thống dịch vụ trực tuyến có thể thu hút nhiều người dùng với giá trị thương mại cao.</div><div> &nbsp;</div><div style=\"TEXT-ALIGN: center\"> <div> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\"><img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-3_46e98.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></span></div></div><div style=\"TEXT-ALIGN: center\"> <span style=\"FONT-FAMILY: Tahoma; FONT-SIZE: 10pt\">Giao diện soạn thảo nội dung trên NukeViet</span></div><div> &nbsp;</div><div> Với việc gửi sản phẩm dự thi tại <span style=\"FONT-STYLE: italic\">Giải thưởng Nhân Tài Đất Việt 2011</span>, nhóm tác giả của NukeViet hy vọng mã nguồn mở của mình sẽ đạt vị trí cao tại Giải thưởng, như một cách thức để quảng bá rộng rãi sản phẩm, được thừa nhận và hỗ trợ sử dụng trong các lĩnh vực mà nó có thể phục vụ tốt và đem lại hiệu quả kinh tế, xã hội cao như: lĩnh vực giáo dục, lĩnh vực hành chính… để các bộ-ban-ngành, các cơ quan hành chính, chính quyền địa phương nhìn thấy giá trị và hiệu quả to lớn của mã nguồn mở NukeViet để triển khai NukeViet phục vụ các cơ quan này. NukeViet sẽ giúp hiện thực hóa cải cách hành chính và góp phần đẩy nhanh thủ tục một cửa một cách tiết kiệm mà vẫn đạt hiệu quả cao nhất.</div><div> &nbsp;</div><div> Ngoài ra, uy tính của Giải thưởng, nhóm tác giả NukeViet hy vọng sẽ đem NukeViet đến nhiều người hơn, để cả xã hội được sử dụng thành quả lớn lao của bộ mã nguồn mở được coi là biểu tượng và đại diện tiểu biểu cho sự phát triển và thành công của mã nguồn mở Việt Nam. Không chỉ thế, mở ra cơ hội tiếp cận và học hỏi công nghệ cho hàng ngàn học sinh, sinh viên, qua đó có được các kiến thức đầy đủ về công nghệ web, về internet và vô số các kỹ năng làm việc trên máy tính khác mà có thể do vô tình hay cố ý, trong quá trình tìm hiểu, học tập và vận hành NukeViet mà họ đã có được.</div><div> &nbsp;</div><div> Với những ứng dụng rộng rãi mà NukeViet đã có được kể từ khi ra mắt và và trải qua thời gian dài phát triển, Hội đồng <span style=\"FONT-STYLE: italic\">Giám khảo Giải Thưởng Nhân &nbsp;Tài Đất Việt</span> đã đánh giá rất cao những ưu điểm và thế mạnh của NukeViet để đưa sản phẩm vào danh sách 17 sản phẩm sẽ tranh tài tại vòng Chung khảo của <span style=\"FONT-STYLE: italic\">Giải Thưởng Nhân Tài Đất Việt 2011</span> diễn ra vào ngày 17-18/11 tới đây.</div><div> &nbsp;</div><div> Bạn đọc có thể tìm hiểu thêm về NukeViet tại <span style=\"FONT-WEIGHT: bold\"><a href=\"http://nukeviet.vn/vi/news/Bao-chi-viet/\">http://nukeviet.vn/</a>.</span></div>', 'http://dantri.com.vn/c119/s119-537812/nukeviet-cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-vn.htm', 1, 0, 1, 1, 1, 0), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước.<div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Sân khấu trước lễ trao giải.</span></div><div> &nbsp;</div><div align=\"center\"> &nbsp;</div><div align=\"left\"> Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ.</div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg\" width=\"350\" /></div> <div align=\"center\"> Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm.</div></div><p> Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải.</p><div> Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới&nbsp;dự Lễ trao giải.</span></div><div> &nbsp;</div><div> 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan.</span></div><div> &nbsp;</div><div> Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số…</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Giáo sư - Viện sỹ Nguyễn Văn Hiệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu.</span></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam.</span></div><p> Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải.</p><div> Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Tiết mục mở màn Lễ trao giải.</span></div><p> Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự.</p><blockquote> <p> <em><span style=\"FONT-STYLE: italic\">Hà Nội, ngày 16 tháng 11 năm 2011</span></em></p> <div> <em>Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược.</em></div></blockquote><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg\" style=\"MARGIN: 5px\" width=\"400\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt.</span></div><blockquote> <p> <em>Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay.</em></p> <p> <em>Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</em></p> <p> <em>Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế.</em></p> <p> <em>Chào thân ái,</em></p> <p> <strong><em>Chủ tịch danh dự Hội Khuyến học Việt Nam</em></strong></p> <p> <strong><em>Đại tướng Võ Nguyên Giáp</em></strong></p></blockquote><p> Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt.</p><div> Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp&nbsp;các vị lãnh đạo&nbsp; Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ.</span></div><p> Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh&nbsp; vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia.</p><div> “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất&nbsp; sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang.</span></div><p> Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng&nbsp; mới ra đời cách đây 7 năm.</p><p> Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực.</p><p> Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải.</p><div> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Khoa học Tự nhiên Việt Nam </span>thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân.</p><p> GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam.</p><div> Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ.</span></div><p> GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.”</p><p> GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam.</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược:</span> 2 giải</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình <span style=\"FONT-STYLE: italic\">“Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”</span>.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><div> &nbsp;</div><div> Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp,&nbsp;2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức.</span></div><p> Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác.</p><p> <span style=\"FONT-WEIGHT: bold\">2.</span> Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu <span style=\"FONT-STYLE: italic\">“Triển khai ghép tim trên người lấy từ người cho chết não”</span>.</p><div> Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế).</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt.</span></div><p> Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện.</p><p> ---------------------</p><p> <span style=\"FONT-WEIGHT: bold\">* Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin.</span></p><p> <span style=\"FONT-STYLE: italic\">Hệ thống sản phẩm đã ứng dụng thực tế:</span></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất:</span> Không có.</p><p> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> Không có</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 3 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1.</span> <span style=\"FONT-STYLE: italic\">“Bộ cạc xử lý tín hiệu HDTV”</span> của nhóm HD Việt Nam.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm HDTV Việt Nam lên nhận giải.</span></div><p> Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào.</p><div> <span style=\"FONT-WEIGHT: bold; FONT-STYLE: italic\">2.</span> <span style=\"FONT-STYLE: italic\">“Mã nguồn mở NukeViet”</span> của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC).</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" alt=\"NukeViet nhận giải ba Nhân tài đất Việt 2011\" src=\"/uploads/news/nukeviet-nhantaidatviet2011.jpg\" style=\"margin: 5px; width: 450px; height: 301px;\" /></div></div><p> NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp.</p><div> <span style=\"FONT-WEIGHT: bold\">3.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống ngôi nhà thông minh homeON”</span> của nhóm Smart home group.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ.&nbsp;</p><p> <strong><span style=\"FONT-STYLE: italic\">* Hệ thống sản phẩm có tiềm năng ứng dụng:</span></strong></p><p> <span style=\"FONT-STYLE: italic\">Giải Nhất: </span>Không có.</p><div> <span style=\"FONT-STYLE: italic\">Giải Nhì:</span> trị giá 50 triệu đồng: <span style=\"FONT-STYLE: italic\">“Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion”</span> của nhóm tác giả SIG.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng.</span></div><p> ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động.</p><p> Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.”</p><p> <span style=\"FONT-STYLE: italic\">Giải Ba:</span> 2 giải, mỗi giải trị giá 30 triệu đồng.</p><div> <span style=\"FONT-WEIGHT: bold\">1. </span><span style=\"FONT-STYLE: italic\">“Bộ điều khiển IPNET”</span> của nhóm IPNET</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> <span style=\"FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET.</span></div><p> Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc.</p><div> <span style=\"FONT-WEIGHT: bold\">2.</span> <span style=\"FONT-STYLE: italic\">“Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX”</span> của nhóm LYNX.</div><div> &nbsp;</div><div align=\"center\"> <div> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div></div><p> Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome…</p><div> Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực&nbsp;tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011.</div><div> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <img _fl=\"\" align=\"middle\" src=\"http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg\" style=\"MARGIN: 5px\" width=\"450\" /></div><div align=\"center\"> &nbsp;</div><div align=\"center\"> <div align=\"center\"> <table border=\"1\" cellpadding=\"0\" cellspacing=\"0\" width=\"90%\"> <tbody> <tr> <td> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng.</span></span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\"><span style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; FONT-FAMILY: Tahoma\">Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này.</span>&nbsp;</span></div> <div> <span style=\"FONT-WEIGHT: bold\">&nbsp;</span></div> </td> </tr> </tbody> </table> </div></div>', 'http://dantri.com.vn/c119/s119-539911/nhan-tai-dat-viet-chap-canh-khat-khao-sang-tao.htm', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_bodytext`
--

DROP TABLE IF EXISTS `nv4_vi_news_bodytext`;
CREATE TABLE `nv4_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_bodytext`
--

INSERT INTO `nv4_vi_news_bodytext` VALUES
(1, 'Để chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet, Ban quản trị NukeViet quyết định thành lập doanh nghiệp chuyên quản NukeViet mang tên Công ty cổ phần Phát triển nguồn mở Việt Nam (Viết tắt là VINADES.,JSC), chính thức ra mắt vào ngày 25-2-2010 (trụ sở tại Hà Nội) nhằm phát triển, phổ biến hệ thống NukeViet tại Việt Nam. Theo ông Nguyễn Anh Tú, Chủ tịch HĐQT VINADES, công ty sẽ phát triển bộ mã nguồn NukeViet nhất quán theo con đường mã nguồn mở đã chọn, chuyên nghiệp và quy mô hơn bao giờ hết. Đặc biệt là hoàn toàn miễn phí đúng tinh thần mã nguồn mở quốc tế. NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System) thuần Việt từ nền tảng PHP-Nuke và cơ sở dữ liệu MySQL. Người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền web, cho phép người sử dụng có thể dễ dàng xuất bản và quản trị các nội dung của họ lên internet hoặc intranet. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng thêm các module, block... tạo sự dễ dàng cài đặt, quản lý, ngay cả với những người mới tiếp cận với website. Người dùng có thể tìm hiểu thêm thông tin và tải về sản phẩm tại địa chỉ http://nukeviet.vn Thông tin ra mắt công ty VINADES có thể tìm thấy trên trang 7 báo Hà Nội Mới ra ngày 25/02/2010 (http://hanoimoi.com.vn/newsdetail/Cong_nghe/309750/ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-viet-nam.htm xem chi tiết), Bản tin tiếng Anh của đài tiếng nói Việt Nam ngày 26/02/2010 (http://english.vovnews.vn/Home/First-opensource-company-starts-operation/20102/112960.vov xem chi tiết); trang 7 báo An ninh Thủ Đô số 2858 ra vào thứ 2 ngày 01/03/2010 và các trang tin tức, báo điện tử khác.'), 
(2, 'Câu chuyện của NukeViet và VINADES.,JSC Từ một trăn trở Giữa năm 2009, trước yêu cầu cấp thiết phải đổi mới và làm một cuộc cách mạng cho mã nguồn mở NukeViet, một cuộc thảo luận sôi nổi đã diễn ra với tiêu đề \"Lối đi nào để chuyên nghiệp hóa mã nguồn mở NukeViet\". Kết quả của cuộc thảo luận này là 55 bài viết với hàng chục ý kiến đóng góp đã được đưa ra. Các giải pháp về tài chính, nhân lực, phương hướng hoạt động được đem ra thảo luận. rockbuilc, Nkd833 đề xuất phương án thành lập doanh nghiệp chuyên quản NukeViet như một giải pháp toàn diện để giải quyết vấn đề chuyên nghiệp hóa NukeViet. Các vấn đề được các thành viên tham gia thảo luận và mổ xẻ thẳng thắn, nhiều ý kiến phản biện trái chiều cũng được đưa ra trên tinh thần xây dựng. Sau 2 tháng thảo luận, Ban Quản Trị đã có dự định... Gặp mặt Tháng 11, Sau khi tham khảo các ý kiến của mọi người trên diễn đàn, Anh Tú đã trực tiếp về Việt Nam. Một cuộc offline được tổ chức chớp nhoáng với sự tham gia của các thành viên chủ chốt tại Hà Nội. Các cuộc tìm hiểu và tiếp xúc được triển khai gấp rút trong giai đoạn này. Một mô hình - một lối đi Hướng đi chuyên nghiệp hóa việc phát triển NukeViet đã được anh Tú chọn lựa: \"Thành lập doanh nghiệp chuyên quản NukeViet\". Doanh nghiệp chuyên quản NukeViet được thành lập từ chính nhu cầu của cộng đồng nhằm chuyên nghiệp hóa NukeViet, vì vậy mô hình công ty cổ phần được chọn lựa để đáp ứng yêu cầu đó. Chịu trách nhiệm triển khai, laser đã lên phương án đầu tư, mục tiêu, kế hoạch phát triển ngắn và dài hạn. Triển khai thực hiện Tháng 1 năm 2010, việc thành lập đã được xúc tiến. Ngày 25/02/2010, trên các bản tin tiếng Anh và tiếng Việt xuất hiện bản tin \"Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam\". Đó là Công ty cổ phần Phát triển nguồn mở Việt Nam (VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY - VINADES.,JSC). Đây là một vài hình ảnh trong ngày khai trương: Anh Tú phát biểu khai trương VINADES.,JSC Anh Tú phát biểu khai trương VINADES.,JSC http://nukeviet.vn/uploads/spaw2/images/hung-phatbieu.jpg Anh Tú phát biểu khai trương VINADES.,JSC Nguyễn Hùng giới thiệu đôi nét về công ty, mục tiêu và phương hướng hoạt động. http://nukeviet.vn/uploads/spaw2/images/nangly.jpg Cùng nâng ly chúc mừng khai trương. Cùng nâng ly chúc mừng khai trương. ... và lời cảm ơn gửi tới cộng đồng VINADES.,JSC từ khi được thai nghén tới lúc chập chững những bước đi ban đầu đều có sự động viên, ủng hộ và đóng góp lớn nhỏ của cộng đồng NukeViet - Một cộng đồng gắn liền với những ký ức, những kỷ niệm buồn vui và mang trong mỗi thành viên một đam mê, một hoài bão lớn lao. \"Lửa thử vàng, gian nan thử sức\", mỗi khó khăn trả qua khiến cộng đồng NukeViet lớn dần lên, gắn kết với nhau bằng một sợi dây vô hình không thể chia cắt: đó là niềm đam mê với mã nguồn mở, với công nghệ web. VINADES.,JSC được tạo ra từ cộng đồng và sẽ cố gắng hết sức để hoạt động vì lợi ích của cộng đồng. http://nukeviet.vn/uploads/spaw2/images/anhvp2.jpg Văn phòng làm việc của VINADES.,JSC ở Hà Nội. http://nukeviet.vn/uploads/spaw2/images/anhvp3.jpg Một góc văn phòng nhìn từ trong ra ngoài. NukeViet 3.0 - Cuộc cách mạng của NukeViet Sau nhiều tháng triển khai, NukeViet 3.0 đã được định hình và dự định công bố bản beta trong thời gian gần. NukeViet 3.0 là phiên bản mang tính cách mạng của hệ thống NukeViet vì 100% các dòng code của NukeViet 3.0 đã được viết mới hoàn toàn chứ không sử dụng nền tảng cũ. Việc này đã ngốn rất nhiều thời gian và công sức của đội ngũ lập trình. Đó cũng là lý do vì sao bản 2.0 không được cải tiến nhiều trong thời gian qua. NukeViet 3.0 được xây dựng với mong muốn có một nền tảng ổn định để sau đó có thể đầu tư lâu dài, xây dựng một thư viện ứng dụng phong phú. VINADES.,JSC sẽ song hành cùng cộng đồng NukeViet trong việc hỗ trợ và phát triển NukeViet thành một mã nguồn mở hoạt động ở quy mô chuyên nghiệp. Đây là bước đi đầu tiên trong trong tiến trình chuyên nghiệp hóa này. Các ứng dụng bổ sung sẽ được xây dựng bài bản, chất lượng. Cộng đồng NukeViet sẽ không chỉ là cộng đồng người sử dụng mà sẽ được đầu tư về đào tạo để trở thành một cộng đồng lập trình mạnh. Thông tin chi tiết về dự án phát triển NukeViet 3.0 được cập nhật tại đây: http://nukeviet.vn/phpbb/viewforum.php?f=99 http://nukeviet.vn/phpbb/viewforum.php?f=99'), 
(5, 'THÔNGTIN VỀ MÃ NGUỒN MỞ NUKEVIET Giới thiệu chung NukeViet là một hệ quản trị nội dung mã nguồn mở (Opensource Content Management System), người sử dụng thường gọi NukeViet là portal vì nó có khả năng tích hợp nhiều ứng dụng trên nền Web. NukeViet có 2 dòng phiên bản chính: Dòng phiên bản trước năm 2009 (NukeViet 2.0 trở về trước) được Nguyễn Anh Tú- một lưu học sinh người Việt tại Nga - cùng cộng đồng phát triển thành một ứng dụng thuần Việt từ nền tảng PHP-Nuke. Dòng phiên bản NukeViet 3.0 trở về sau (kể từ năm 2010 trở đi) là dòng phiên bản hoàn toàn mới, được xây dựng từ đầu với nhiều tính năng ưu việt. NukeViet được viết bằng ngôn ngữ PHP và chủ yếu sử dụng cơ sở dữ liệu MySQL, cho phép người sử dụng có thể dễ dàng xuất bản &quản trị các nội dung của họ lên Internet hoặc Intranet. NukeViet được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp, nó cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng. NukeViet là giải pháp hoàn hảo cho các Website từ cá nhân cho tới các doanh nghiệp. NukeViet là bộ mã nguồn chất lượng cao, được phát hành theo giấy phép mã nguồn mở nên việc sử dụng NukeViet hoàn toàn miễn phí. Với người sử dụng cá nhân, tất cả đều có thể tự tạo cho mình một website chuyên nghiệp mà không mất bất cứ chi phí nào. Với những nhà phát triển Web, sử dụng NukeViet có thể nhanh chóng xây dựng các hệ thống lớn mà việc lập trình không đòi hỏi quá nhiều thời gian vì NukeViet đã xây dựng sẵn hệ thống quản lý ưu việt. Thông tin chi tiết về NukeViet có thể tìm thấy ở bách khoa toàn thư mở Wikipedia: http://vi.wikipedia.org/wiki/NukeViet http://vi.wikipedia.org/wiki/NukeViet II. Thông tin về diễn đàn NukeViet: Diễn đàn NukeViet hoạt động trên website: http://nukeviet.vn/ http://nukeviet.vn hiện có trên 13.000 thành viên thực gồm học sinh, sinh viên & nhiều thành phần khác thuộc giới trí thức ở trong và ngoài nước. Là một diễn đàn của các nhà quản lý website, rất nhiều thành viên trong diễn đàn NukeViet là cán bộ, lãnh đạo từ đủ mọi lĩnh vực: công nghệ thông tin, xây dựng,văn hóa - xã hội, thể thao, dịch vụ - du lịch... từ cử nhân, bác sĩ, kỹ sư cho đến bộ đội, công an... Nhiều học sinh, sinh viên tham gia diễn đàn NukeViet, đam mê mã nguồn mở và đã thành công với chính công việc mà họ yêu thích.'), 
(6, 'THƯ MỜI HỢP TÁC TRONG VIỆC LIÊN KẾT QUẢNG CÁO, CUNG CẤP HOSTING THỬ NGHIỆM PHÁT TRIỂN MÃ NGUỒN MỞ NUKEVIET Kính gửi: QUÍ KHÁCH VÀ ĐỐI TÁC Lời đầu tiên, Ban giám đốc công ty cổ phần Phát Triển Nguồn Mở Việt Nam (VINADES.,JSC) xin gửi đến Quý đối tác lời chào trân trọng, lời chúc may mắn và thành công. Tiếp đến chúng tôi xin được giới thiệu và ngỏ lời mời hợp tác kinh doanh. VINADES.,JSC ra đời nhằm chuyên nghiệp hóa việc phát hành mã nguồn mở NukeViet. Đồng thời khai thác các dự án từ NukeViet tạo kinh phí phát triển bền vững cho mã nguồn này. NukeViet là hệ quản trị nội dung, là website đa năng đầu tiên của Việt Nam do cộng đồng người Việt phát triển. Có nhiều lợi thế như cộng đồng người sử dụng đông đảo nhất tại Việt Nam hiện nay, sản phẩm thuần Việt, dễ sử dụng, dễ phát triển. Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên. Phương thức hợp tác nhưsau: 1.Quảng cáo, trao đổi banner, liên kết website: a. Mô tả hình thức: - Quảng cáo trên website & hệ thống kênh truyền thông của 2 bên. - Quảng cáo trên các phiên bản phát hành của mã nguồn mở NukeViet. b, Lợi ích: - Quảng bá rộng rãi cho đối tượng của 2 bên. - Giảm chi phí quảng bá cho 2 bên. c, Trách nhiệm: - Hai bên sẽ thỏa thuận và đưa quảng cáo của mình vào website của đối tác. Thỏa thuận vị trí, kích thước và trang đặt banner quảng cáo nhằm mang lại hiệu quả cao cho cả hai bên. - Mở forum hỗ trợ người dùng hosting ngay tại diễn đàn NukeViet.VN để quý công ty dễ dàng hỗ trợ người sử dụng cũng như thực hiện các kế hoạch truyền thông của mình tới cộng đồng NukeViet. 2.Hợp tác cung cấp hosting thử nghiệm NukeViet: a. Mô tả hình thức: - Hai bên ký hợp đồng nguyên tắc & thỏa thuận hợp tác trong việc hợp tác phát triển mã nguồn mở NukeViet. Theo đó: + Phía đối tác cung cấp mỗi loại 1 gói hosting đại lý cho VINADES.,JSC để chúng tôi test trong quá trình phát triển mã nguồn mở NukeViet, để đảm bảo NukeViet sẵn sàng tương thích với hosting của quý khách ngay khi ra mắt. + VINADES.,JSC sẽ công báo thông tin chứng nhận host của phía đối tác là phù hợp, tương thích tốt nhất với NukeViet tới cộng đồng những người phát triển và sử dụng NukeViet. b. Lợi ích: - Mở rộng thị trường theo cả hướng đối tượng. - Tiết kiệm chi phí –nâng cao hiệu quả kinh doanh. c. Trách nhiệm: - Bên đối tác cung cấp miễn phí host để VINADES.,JSC thực hiện việc test tương thích mã nguồn NukeViet trên các gói hosting của đối tác. - VINADES.,JSC công bố tới cộng đồng về kết quả chứng nhận chất lượng host của phía đối tác. 3,Hợp tác nhân lực hỗ trợ người sử dụng: a, Mô tả hình thức: - Hai bên sẽ hỗ trợ lẫn nhau trong quá trình giải quyết các yêu cầu của khách hàng. + Bên đối tác gửi các yêu cầu của khách hàng về mã nguồn NukeViet tới VINADES.,JSC + VINADES gửi các yêu cầu của khách hàng có liên quan đến dịch vụ hosting tới phía đối tác. b, Lợi ích: - Giảm thiểu chi phí, nhân lực hỗ trợ khách hàng của cả 2 bên. - Tăng hiệu quả hỗ trợ khách hàng. c, Trách nhiệm: - Khi nhận được yêu cầu hỗ trợ VINADES hoặc bên đối tác cần ưu tiên xử lý nhanh gọn nhằm nâng cao hiệu quả của sự hợp tác song phưong này. 4. Các hình thức khác: Ngoài các hình thức đã đề xuất ở trên, là đơn vị phát hành mã nguồn mở NukeViet chúng tôi có thể phát hành quảng cáo trên giao diện phần mềm, trên các bài viết giới thiệu xuất hiện ngay sau khi cài đặt phần mềm… chúng tôi tin tưởng rằng với lượng phát hành lên đến hàng chục ngàn lượt tải về cho mỗi phiên bản là một cơ hội quảng cáo rất hiệu quả đến cộng đồng Webmaster Việt Nam. Với mong muốn tạo nên cộng đồng phát triển và sử dụng NukeViet rộng lớn đúng như mục tiêu đề ra,chúng tôi luôn linh động trong các hình thức hợp tác nhằm mang lại sự thuận tiện cho đối tác cũng như mục tiêu hợp tác đa phương. Chúng tôi sẽ tiếp nhận các hình thức hợp tác khác mà bên đối tác trình bày hợp lý và hiệu quả, mong nhận được thêm nhiều hình thức hợp tác khác từ đối tác. Phương châm của chúng tôi “Cùng hợp tác để phát triển”. Trân trọng cảm ơn, rất mong được hợp tác cùng quý vị. Thông tin liên hệ: CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM (VINADES.,JSC) Trụ sở chính: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội. Điện thoại: +84-4-85872007 Fax: +84-4-35500914 Website: http://www.vinades.vn/ www.vinades.vn – http://www.nukeviet.vn/ www.nukeviet.vn Email: mailto:contact@vinades.vn contact@vinades.vn'), 
(7, 'Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC) đang thu hút tuyển dụng nhân tài là các lập trình viên PHP và MySQL, Chuyên Viên Đồ Hoạ để làm việc cho công ty, hiện thực hóa ước mơ một nguồn mở chuyên nghiệp cho Việt Nam vươn ra thế giới.Tại VINADES.,JSC bạn sẽ được tham gia các dự án của công ty, tham gia xây dựng và phát triển bộ nhân hệ thống NukeViet, được học hỏi và trau dồi nâng cao kiến thức và kỹ năng cá nhân. 1. Vị trí dự tuyển: Chuyên viên đồ hoạ; Lập trình viên. 2. Mô tả công việc:Với vị trí lập trình viên PHP & MySQL: Viết module trên nền NukeViet, tham gia phát triển hệ thống NukeViet. Nếu là chuyên viên đồ họa, kỹ thuật viên cắt giao diện... bạn có thể đảm nhiệm một trong các công việc sau: + Vẽ và cắt giao diện. + Valid CSS, xHTML. + Ghép giao diện cho hệ thống.3. Yêu cầu: Lập trình viên PHP & MySQL: Thành thạo PHP, MySQL. Biết CSS, XHTML, JavaScript là một ưu thế.Chuyên viên đồ họa: Sử dụng thành thạo một trong các phần mềm Photoshop, illustrator, 3Dmax, coreldraw. Biết CSS, xHTML. + Trình độ tối thiểu cho người làm đồ họa web: Biết vẽ giao diện hoặc cắt PSD ra xHTML & CSS. + Ưu tiên người cắt giao diện đạt chuẩn W3C (Test trên Internet Explorer 7+, FireFox 3+, Chrome 8+, Opera 10+)Chúng tôi ưu tiên các ứng viên có kỹ năng làm việc độc lập, làm việc theo nhóm, có tinh thần trách nhiệm cao, chủ động trong công việc. 4: Quyền lợi: - Lương: thoả thuận, trả qua ATM. - Thưởng theo dự án, các ngày lễ tết. - Hưởng các chế độ khác theo quy định của công ty và pháp luật: Bảo hiểm y tế, bảo hiểm xã hội... 5. Thời gian làm việc: Toàn thời gian cố định hoặc làm online. 6. Hạn nộp hồ sơ: Không hạn chế, vui lòng kiểm tra tại http://vinades.vn/vi/news/Tuyen-dung/ http://vinades.vn/vi/news/Tuyen-dung/ 7. Hồ sơ bao gồm: * Cách thức đăng ký dự tuyển: Làm Hồ sơ xin việc (file mềm) và gửi về hòm thư tuyendung@vinades.vn * Nội dung hồ sơ xin việc file mềm gồm: + Đơn xin việc: Tự biên soạn. + Thông tin ứng viên: Theo mẫu của VINADES.,JSC (dowload tại đây: http://vinades.vn/vi/download/Thong-tin-ung-vien/Mau-ly-lich-ung-vien/ Mẫu lý lịch ứng viên) Chi tiết vui lòng tham khảo tại: http://vinades.vn/vi/news/Tuyen-dung/ http://vinades.vn/vi/news/Tuyen-dung/ Mọi thắc mắc vui lòng liên hệ: Công ty cổ phần phát triển nguồn mở Việt Nam. Địa chỉ: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội. - Tel: +84-4-85872007 - Fax: +84-4-35500914 - Email: mailto:contact@vinades.vn contact@vinades.vn - Website: http://www.vinades.vn/ http://www.vinades.vn'), 
(8, 'Giảm giá tới 90% giá module, ngày nào cũng là ngày \"mua chung\" trên webnhanh.vn! Như thông báo trên webnhanh.vn, chương trình \"http://webnhanh.vn/vi/thiet-ke-web/detail/Mua-chung-tren-Webnhanhvn-se-giam-gia-90-gia-module-da-cong-bo-245/ mua chung module\" nằm trong chính sách chung của webnhanh.vn trong việc hỗ trợ phát triển mã nguồn mở, giúp cho mọi người được hưởng những dịch vụ thiết kế website tốt nhất với chi phí thấp nhất. Tham gia chương trình này, bạn chỉ phải trả số tiền bằng 1/10 giá trị module mà vẫn được sở hữu module với tính năng hấp dẫn mà bạn mong muốn. Cụ thể, các module trong http://webnhanh.vn/vi/nvresources/cat/Modules-1/ kho module của webnhanh.vn đang chờ hoàn thiện sẽ được giảm giá tới 90% nếu khách hàng đăng ký mua chung module. Tuy nhiên sau 2 tháng thực hiện, Ban Quản Trị webnhanh.vn thấy rằng khả năng xuất hiện nhu cầu cùng mua chung 1 sản phẩm và dịch vụ có tính đặc thù như code dành cho web là rất thấp. Chính vì thế webnhanh.vn đã giảm giá đồng loạt các module trên webnhanh.vn để khách hàng có nhu cầu sẽ có nhiều cơ hội được sử dụng các module mà mình mong muốn cung cấp lên website. Đại đa số các module sẽ được giảm giá xuống mức giá siêu rẻ để đảm bảo mọi người đều có khả năng sử dụng. Đặc biệt với các module có mức giá từ 10-20 triệu đồng sẽ giảm giá xuống còn ở mức 1-5 triệu đồng. Giá rẻ hơn, nhiều giao diện hơn cho web Ngoài việc giảm giá http://webnhanh.vn/vi/nvresources/cat/Giao-dien-3/ các giao diện website do VINADES.,JSC thiết kế (từ mức giá 2 triệu đồng xuống còn 300 đến 700 ngàn đồng). Webnhanh.vn cũng sẽ cải thiện kho giao diện của mình bằng cách đưa vào sử dụng các mẫu giao diện của các nhà thiết kế giao diện khác với giá trung bình khoảng 300 ngàn đồng (chi phí chuyển template thành giao diện có thể cài đặt cho website). Khách hàng cũng có thể gửi mẫu giao diện (đã cắt HTML) để chúng tôi thực hiện việc ghép giao diện với mức giá 300-500 ngàn đồng (áp dụng mô hình giá chia sẻ của VINADES.,JSC trong http://vinades.vn/vi/news/San-pham/Thiet-ke-giao-dien-14/ thiết kế giao diện web (*)). Giảm giá các gói web dựng sẵn, nâng cao chất lượng và cấu hình dịch vụ Cơ cấu chất lượng sản phẩm và dịch vụ cũng thay đổi theo hướng nâng cao rõ rệt. Ngoài việc giảm giá các http://webnhanh.vn/vi/nvresources/package/ gói web dựng sẵn, webnhanh.vn đồng thời nâng cao chất lượng các dịch vụ đi kèm của các gói web này. Theo đó ngoài việc kéo dài thời gian bảo hành miễn phí lên 12 tháng, đồng thời webnhanh.vn cũng kéo dài thời gian sử dụng hosting miễn phí lên 12 tháng. Với mức hỗ trợ này, website thiết kế trên webnhanh.vn đảm bảo chất lượng cao và mức giá còn rẻ hơn cả các nhà cung cấp dịch vụ web giá rẻ. Đây là cơ hội rất lớn cho http://webnhanh.vn/vi/dealers/ các đại lý của webnhanh.vn để tạo nên lợi thế cạnh tranh về chất lượng và giá cả dịch vụ. (*) \"Giá chia sẻ\" là mức giá tiết kiệm cho khách hàng, nếu mua với mức giá này khách hàng sẽ tiết kiệm chi phí thiết kế giao diện một cách tối đa mà vẫn được toàn quyền sử dụng mẫu giao diện đã đặt hàng. Webnhanh.vn sẽ giữ lại mẫu giao diện này và đưa vào thư viện giao diện để cung cấp cho các khách hàng khác. Mô hình \"Giá chia sẻ\" sử dụng cho các khách hàng không quá khắt khe về việc đảm bảo tính duy nhất của mẫu giao diện đồng thời giúp webnhanh.vn làm phong phú thêm kho giao diện của mình.Chú ý: Ngoài việc cung cấp các gói web dựng sẵn với chi phí thấp phục vụ người dùng phổ thông, http://vinades.vn VINADES.,JSC vẫn duy trì dịch vụ thiết kế giao diện riêng và thiết kế website theo yêu cầu để phục vụ những khách hàng có nhu cầu riêng biệt và cao cấp hơn, khách hàng có nhu cầu vui lòng truy cập http://vinades.vn http://vinades.vn hoặc liên hệ nhân viên kinh doanh của VINADES.,JSC để được tư vấn và báo giá dịch vụ. Như vậy, cùng với việc tham gia cung cấp hosting chuyên nghiệp dành cho NukeViet của các nhà cung cấp hosting trong và ngoài nước như http://vinades.vn/vi/news/Doi-tac/VINADES-JSC-va-DIGISTAR-hop-tac-trong-viec-phat-trien-ma-nguon-mo-NukeViet-17/ DIGISTAR, http://nukeviet.vn/vi/news/the-gioi-cong-nghe/TMDHosting-cung-cap-dich-vu-hosting-chuyen-NukeViet-64/ TMDHosting hay http://nukeviet.vn/vi/news/the-gioi-cong-nghe/SiteGround-cung-cap-dich-vu-hosting-chuyen-NukeViet-59/ SiteGround, http://nukeviet.vn/vi/news/the-gioi-cong-nghe/website-dau-tien-thiet-ke-website-va-ban-code-chuyen-nghiep-danh-cho-NukeViet-67/ Webnhanh.vn là website đầu tiên có dịch vụ thiết kế website và bán code chuyên nghiệp dành riêng cho NukeViet. Sự chuyên nghiệp hóa trong các khâu từ phát triển đến cung cấp dịch vụ cho mã nguồn mở NukeViet sẽ mở ra một cơ hội phát triển mới cho người sử dụng web ở Việt Nam.'), 
(9, 'Nhắc đến các hệ thống quản trị nội dung (Content Management System – CMS) để quản lý các cổng thông tin điện tử trên Internet, không ít người sẽ nhắc đến các bộ công cụ như Joomla hay Wordpress. Tuy nhiên, có một sản phẩm hoàn toàn thuần Việt, do người Việt xây dựng không hề thua kém những sản phẩm trên cả về tính năng lẫn khả năng ứng dụng, đó là NukeViet của nhóm tác giả thuộc Công ty Cổ phần phát triển nguồn mở Việt Nam (VINADES). Với NukeViet, người dùng tại Việt Nam sẽ vượt qua các trở ngại về rào cản ngôn ngữ, có thể xây dựng và vận hành các trang web một cách dễ dàng nhất, đồng thời nhận được sự hỗ trợ của cộng đồng người dùng và các nhà phát triển cũng chính là người Việt Nam. Mới đây nhất, Ban giám khảo Giải thưởng Nhân Tài Đất Việt 2011 đã quyết định đưa NukeViet vào danh sách các sản phẩm đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011 diễn ra vào ngày 17-18/11 tới đây. Những ý tưởng giúp hình thành nên sản phẩm “thuần Việt” Theo chia sẻ của đại diện nhóm tác giả, năm 2004, anh Nguyễn Anh Tú, một lưu học sinh người Việt tại Nga với ý tưởng xây dựng một website để kết nối cộng đồng sinh viên du học đã sử dụng bộ CMS mã nguồn mở PHP-Nuke để thực hiện. Sau đó, anh Nguyễn Anh Tú đã phát triển và cải tiến bộ mã nguồn mở PHP-Nuke để chia sẻ cho các thành viên có nhu cầu xây dựng website một cách đơn giản và thuận tiện hơn. Được sự đón nhận của đông đảo người sử dụng, bộ mã nguồn đã liên tục được phát triển và trở thành một ứng dụng thuần Việt với tên gọi NukeViet. NukeViet đã nhanh chóng trở nên phổ biến trong giới các nhà xây dựng và phát triển website tại Việt Nam. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-1_4b905.jpg Giao diện một website tin tức được xây dựng bằng NukeViet Trong quá trình phát triển NukeViet, có một điều đội ngũ kỹ thuật luôn trăn trở là làm sao để có thể nâng cao tỉ lệ đóng góp của người Việt vào trong mã nguồn sản phẩm. Chính vì ý thức được điều này nên mức độ thuần Việt của sản phẩm ngày càng được nâng cao trong từng phiên bản phát hành. Cho đến phiên bản 3.0 (phát hành tháng 10 năm 2010) thì NukeViet đã thực sự trở thành một sản phẩm mã nguồn mở riêng của Việt Nam với 100% dòng code được viết mới. Kể từ đây, cộng đồng mã nguồn mở Việt Nam đã có riêng một bộ mã nguồn thuần Việt, tự hào sánh bước ngang vai cùng các cộng đồng mã nguồn mở khác trên thế giới. NukeViet ra đời đã giúp cộng đồng mạng Việt Nam giải quyết nhu cầu và mong muốn có một bộ mã nguồn mở của riêng Việt Nam, giúp phát triển hệ thống website của người Việt một cách an toàn nhất, đảm bảo nhất. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-2_600d0.jpg Một website bán hành trực tuyến xây dựng bằng NukeViet NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp. Khả năng ứng dụng và những ưu điểm của NukeViet Kể từ khi ra đời và trải qua một quá trình dài phát triển, NukeViet hiện được sử dụng ở nhiều website, từ những website cá nhân cho tới những hệ thống website doanh nghiệp. NukeViet cung cấp nhiều dịch vụ và ứng dụng nhờ khả năng tăng cường tính năng bằng cách cài thêm các module, block... NukeViet chủ yếu được sử dụng làm trang tin tức nhờ module News tích hợp sẵn trong NukeViet được viết rất công phu, nó lại đặc biệt phù hợp với yêu cầu và đặc điểm sử dụng cho hệ thống tin tức. NukeViet có thể dễ dàng cài đặt, dễ dàng quản lý kể cả với những người mới sử dụng do đó thường được những đối tượng người dùng không chuyên ưa thích. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-4_416a1.jpg Website phòng Giáo dục và Đào tạo Lạng Giang được xây dựng trên mã nguồn NukeViet NukeViet có mã nguồn mở do đó việc sử dụng NukeViet là hoàn toàn miễn phí cho tất cả mọi người trên thế giới. Từ phiên bản 2.0 trở về trước, đối tượng người dùng chủ yếu của NukeViet là người Việt vì những đặc điểm của bản thân mã nguồn (có nguồn gốc từ PHP-Nuke) và vì chính sách của nhóm phát triển là: \"hệ thống Portal dành cho người Việt\". Tuy nhiên, kể từ phiên bản 3.0, đội ngũ phát triển NukeViet định hướng đưa NukeViet ra cộng đồng quốc tế với hỗ trợ thêm nhiều ngôn ngữ. Trên thực tế, với những ưu điểm vượt trội của mình, NukeViet 3 đã được ứng dụng ở hàng ngàn website khác nhau. Đặc biệt, không ít các cơ quan, tổ chức của Nhà nước đã tin tưởng sử dụng mã nguồn NukeViet để xây dựng cổng thông tin điện tử của mình, như Cổng thông tin tích hợp 1 cửa cho Phòng giáo dục Lạng Giang, cổng thông tin 2 chiều - Công ty cổ phần đầu tư tài chính công đoàn dầu khí Việt Nam, Hệ thống tra cứu điểm, tra cứu văn bằng - Cổng thông tin Sở GD&ĐT Quảng Ninh, Website viện y học cổ truyền Quân Đội… Tất cả các dự án trên đều được khách hàng đánh giá rất cao về tính ứng dụng, hiệu quả do tiết kiệm chi phí và đáp ứng rất tốt nhu cầu sử dụng của các đơn vị. Hướng phát triển trong tương lai và những kỳ vọng trước mắt Với ý nghĩa là phần mềm quản lý website (chiếm tới 90% các giao tiếp và tương tác trực tiếp với người sử dụng trên môi trường internet), khi phát triển, NukeViet sẽ trở thành một công cụ truyền thông rất mạnh, có thể đem lại những hiệu quả to lớn khác. Nhóm phát triển sẽ phát huy lợi thế này để phát triển sản phẩm. Nhóm phát triển cũng muốn tăng cường các khả năng liên kết, chia sẻ và tích hợp dữ liệu giữa các hệ thống khác nhau nhằm tạo nên một mạng lưới lớn, rộng khắp và hoàn chỉnh, có thể huy động sức mạnh tổng lực, thực hiện các nhiệm vụ xã hội khác trên mã nguồn NukeViet của mình. NukeViet khi được kết hợp với xu thế phát triển của điện toán đám mây sẽ trở thành một nền tảng giúp phát triển nhiều hệ thống dịch vụ trực tuyến có thể thu hút nhiều người dùng với giá trị thương mại cao. http://dantri4.vcmedia.vn/tI0YUx18mEaF5kMsGHJ/Image/2011/11/NukeViet-3_46e98.jpg Giao diện soạn thảo nội dung trên NukeViet Với việc gửi sản phẩm dự thi tại Giải thưởng Nhân Tài Đất Việt 2011, nhóm tác giả của NukeViet hy vọng mã nguồn mở của mình sẽ đạt vị trí cao tại Giải thưởng, như một cách thức để quảng bá rộng rãi sản phẩm, được thừa nhận và hỗ trợ sử dụng trong các lĩnh vực mà nó có thể phục vụ tốt và đem lại hiệu quả kinh tế, xã hội cao như: lĩnh vực giáo dục, lĩnh vực hành chính… để các bộ-ban-ngành, các cơ quan hành chính, chính quyền địa phương nhìn thấy giá trị và hiệu quả to lớn của mã nguồn mở NukeViet để triển khai NukeViet phục vụ các cơ quan này. NukeViet sẽ giúp hiện thực hóa cải cách hành chính và góp phần đẩy nhanh thủ tục một cửa một cách tiết kiệm mà vẫn đạt hiệu quả cao nhất. Ngoài ra, uy tính của Giải thưởng, nhóm tác giả NukeViet hy vọng sẽ đem NukeViet đến nhiều người hơn, để cả xã hội được sử dụng thành quả lớn lao của bộ mã nguồn mở được coi là biểu tượng và đại diện tiểu biểu cho sự phát triển và thành công của mã nguồn mở Việt Nam. Không chỉ thế, mở ra cơ hội tiếp cận và học hỏi công nghệ cho hàng ngàn học sinh, sinh viên, qua đó có được các kiến thức đầy đủ về công nghệ web, về internet và vô số các kỹ năng làm việc trên máy tính khác mà có thể do vô tình hay cố ý, trong quá trình tìm hiểu, học tập và vận hành NukeViet mà họ đã có được. Với những ứng dụng rộng rãi mà NukeViet đã có được kể từ khi ra mắt và và trải qua thời gian dài phát triển, Hội đồng Giám khảo Giải Thưởng Nhân Tài Đất Việt đã đánh giá rất cao những ưu điểm và thế mạnh của NukeViet để đưa sản phẩm vào danh sách 17 sản phẩm sẽ tranh tài tại vòng Chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011 diễn ra vào ngày 17-18/11 tới đây. Bạn đọc có thể tìm hiểu thêm về NukeViet tại http://nukeviet.vn/vi/news/Bao-chi-viet/ http://nukeviet.vn/'), 
(10, 'Cả hội trường như vỡ òa, rộn tiếng vỗ tay, tiếng cười nói chúc mừng các nhà khoa học, các nhóm tác giả đoạt Giải thưởng Nhân tài Đất Việt năm 2011. Năm thứ 7 liên tiếp, Giải thưởng đã phát hiện và tôn vinh nhiều tài năng của đất nước. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/01_b7d3f.jpg Sân khấu trước lễ trao giải. Cơ cấu Giải thưởng của Nhân tài Đất Việt 2011 trong lĩnh vực CNTT bao gồm 2 hệ thống giải dành cho “Sản phẩm có tiềm năng ứng dụng” và “Sản phẩm đã ứng dụng rộng rãi trong thực tế”. Mỗi hệ thống giải sẽ có 1 giải Nhất, 1 giải Nhì và 1 giải Ba với trị giá giải thưởng tương đương là 100 triệu đồng, 50 triệu đồng và 30 triệu đồng cùng phần thưởng của các đơn vị tài trợ. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/03_f19bd.jpg Nhiều tác giả, nhóm tác giả đến lễ trao giải từ rất sớm. Giải thưởng Nhân tài Đất Việt 2011 trong lĩnh vực Khoa học Tự nhiên được gọi chính thức là Giải thưởng Khoa học Tự nhiên Việt Nam sẽ có tối đa 6 giải, trị giá 100 triệu đồng/giải dành cho các lĩnh vực: Toán học, Cơ học, Vật lý, Hoá học, Các khoa học về sự sống, Các khoa học về trái đất (gồm cả biển) và môi trường, và các lĩnh vực khoa học liên ngành hoặc đa ngành của hai hoặc nhiều ngành nói trên. Viện Khoa học và Công nghệ Việt Nam thành lập Hội đồng giám khảo gồm các nhà khoa học tự nhiên hàng đầu trong nước để thực hiện việc đánh giá và trao giải. Sau thành công của việc trao Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y dược năm 2010, Ban Tổ chức tiếp tục tìm kiếm những chủ nhân xứng đáng cho Giải thưởng này trong năm 2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/07_78b85.jpg Nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam Lê Khả Phiêu tới dự Lễ trao giải. 45 phút trước lễ trao giải, không khí tại Cung Văn hóa Hữu nghị Việt - Xô đã trở nên nhộn nhịp. Sảnh phía trước Cung gần như chật kín. Rất đông bạn trẻ yêu thích công nghệ thông tin, sinh viên các trường đại học đã đổ về đây, cùng với đó là những bó hoa tươi tắn sẽ được dành cho các tác giả, nhóm tác giả đoạt giải. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/09_aef87.jpg Phó Chủ tịch nước CHXHCN Việt Nam Nguyễn Thị Doan. Các vị khách quý cũng đến từ rất sớm. Tới tham dự lễ trao giải năm nay có ông Lê Khả Phiêu, nguyên Tổng Bí thư BCH TW Đảng Cộng sản Việt Nam; bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCN Việt Nam; ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam; ông Nguyễn Bắc Son, Bộ trưởng Bộ Thông tin và Truyền thông; ông Đặng Ngọc Tùng, Chủ tịch Tổng Liên đoàn lao động Việt Nam; ông Phạm Văn Linh, Phó trưởng ban Tuyên giáo Trung ương; ông Đỗ Trung Tá, Phái viên của Thủ tướng Chính phủ về CNTT, Chủ tịch Hội đồng Khoa học công nghệ quốc gia; ông Nguyễn Quốc Triệu, nguyên Bộ trưởng Bộ Y tế, Trưởng Ban Bảo vệ Sức khỏe TƯ; bà Cù Thị Hậu, Chủ tịch Hội người cao tuổi Việt Nam; ông Lê Doãn Hợp, nguyên Bộ trưởng Bộ Thông tin Truyền thông, Chủ tịch Hội thông tin truyền thông số… http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/08_ba46c.jpg Bộ trưởng Bộ Thông tin và Truyền thông Nguyễn Bắc Son. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/06_29592.jpg Giáo sư - Viện sỹ Nguyễn Văn Hiệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/04_051f2.jpg Nguyên Bộ trưởng Bộ Y tế Nguyễn Quốc Triệu. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/05_c7ea4.jpg Ông Vũ Oanh, nguyên Ủy viên Bộ Chính trị, nguyên Chủ tịch Hội Khuyến học Việt Nam. Do tuổi cao, sức yếu hoặc bận công tác không đến tham dự lễ trao giải nhưng Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang cũng gửi lẵng hoa đến chúc mừng lễ trao giải. Đúng 20h, Lễ trao giải bắt đầu với bài hát “Nhân tài Đất Việt” do ca sỹ Thái Thùy Linh cùng ca sĩ nhí và nhóm múa biểu diễn. Các nhóm tác giả tham dự Giải thưởng năm 2011 và những tác giả của các năm trước từ từ bước ra sân khấu trong tiếng vỗ tay tán dương của khán giả. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/12_74abf.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN15999_3e629.jpg Tiết mục mở màn Lễ trao giải. Trước Lễ trao giải Giải thưởng Nhân tài Đất Việt năm 2011, Đại tướng Võ Nguyên Giáp, Chủ tịch danh dự Hội Khuyến học Việt Nam, đã gửi thư chúc mừng, khích lệ Ban tổ chức Giải thưởng cũng như các nhà khoa học, các tác giả tham dự. Hà Nội, ngày 16 tháng 11 năm 2011 Giải thưởng “Nhân tài đất Việt” do Hội Khuyến học Việt Nam khởi xướng đã bước vào năm thứ bảy (2005 - 2011) với ba lĩnh vực: Công nghệ thông tin, Khoa học tự nhiên và Y dược. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/thuDaituong1_767f4.jpg Thư của Đại tướng Võ Nguyên Giáp gửi BTC Giải thưởng Nhân tài đất Việt. Tôi gửi lời chúc mừng các nhà khoa học và các thí sinh được nhận giải thưởng “Nhân tài đất Việt” năm nay. Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Nhân ngày “Nhà giáo Việt Nam”, chúc Hội Khuyến học Việt nam, chúc các thầy giáo và cô giáo, với tâm huyết và trí tuệ của mình, sẽ đóng góp xứng đáng vào công cuộc đổi mới căn bản và toàn diện nền giáo dục nước nhà, để cho nền giáo dục Việt Nam thực sự là cội nguồn của nguyên khí quốc gia, đảm bảo cho mọi nhân cách và tài năng đất Việt được vun đắp và phát huy vì sự trường tồn, sự phát triển tiến bộ và bền vững của đất nước trong thời đại toàn cầu hóa và hội nhập quốc tế. Chào thân ái, Chủ tịch danh dự Hội Khuyến học Việt Nam Đại tướng Võ Nguyên Giáp Phát biểu khai mạc Lễ trao giải, Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng Ban tổ chức, bày tỏ lời cám ơn chân thành về những tình cảm cao đẹp và sự quan tâm chăm sóc của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang đã và đang dành cho Nhân tài Đất Việt. Nhà báo Phạm Huy Hoàn nhấn mạnh, Giải thưởng Nhân tài Đất Việt suốt 7 năm qua đều nhận được sự quan tâm của các vị lãnh đạo Đảng, Nhà nước và của toàn xã hội. Tại Lễ trao giải, Ban tổ chức luôn có vinh dự được đón tiếp các vị lãnh đạo Đảng và Nhà nước đến dự và trực tiếp trao Giải thưởng. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/15_4670c.jpg Trưởng Ban tổ chức Phạm Huy Hoàn phát biểu khai mạc buổi lễ. Năm 2011, Giải thưởng có 3 lĩnh vực được xét trao giải là CNTT, Khoa học tự nhiên và Y dược. Lĩnh vực CNTT đã đón nhận 204 sản phẩm tham dự từ mọi miền đất nước và cả nước ngoài như thí sinh Nguyễn Thái Bình từ bang California - Hoa Kỳ và một thí sinh ở Pháp cũng đăng ký tham gia. “Cùng với lĩnh vực CNTT, năm nay, Hội đồng khoa học của Viện khoa học và công nghệ Việt Nam và Hội đồng khoa học - Bộ Y tế tiếp tục giới thiệu những nhà khoa học xuất sắc, có công trình nghiên cứu đem lại nhiều lợi ích cho xã hội trong lĩnh vực khoa học tự nhiên và lĩnh vực y dược. Đó là những bác sĩ tài năng, những nhà khoa học mẫn tuệ, những người đang ngày đêm thầm lặng cống hiến trí tuệ sáng tạo của mình cho xã hội trong công cuộc xây dựng đất nước.” - nhà báo Phạm Huy Hoàn nói. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/14_6e18f.jpg Nhà báo Phạm Huy Hoàn, TBT báo điện tử Dân trí, Trưởng BTC Giải thưởng và ông Phan Hoàng Đức, Phó TGĐ Tập đoàn VNPT nhận lẵng hoa chúc mừng của Đại tướng Võ Nguyên Giáp và Chủ tịch nước Trương Tấn Sang. Cũng theo Trưởng Ban tổ chức Phạm Huy Hoàn, đến nay, vị Chủ tịch danh dự đầu tiên của Hội Khuyến học Việt Nam, Đại tướng Võ Nguyên Giáp, đã bước qua tuổi 100 nhưng vẫn luôn dõi theo và động viên từng bước phát triển của Giải thưởng Nhân tài Đất Việt. Đại tướng luôn quan tâm chăm sóc Giải thưởng ngay từ khi Giải thưởng mới ra đời cách đây 7 năm. Trước lễ trao giải, Đại tướng Võ Nguyên Giáp đã gửi thư chúc mừng, động viên Ban tổ chức. Trong thư, Đại tướng viết: “Mong rằng, các sản phẩm và các công trình nghiên cứu được trao giải sẽ được tiếp tục hoàn thiện và được ứng dụng rộng rãi trong đời sống, đem lại hiệu quả kinh tế và xã hội thiết thực. Sau phần khai mạc, cả hội trường hồi hội chờ đợi phút vinh danh các nhà khoa học và các tác giả, nhóm tác giả đoạt giải. * Giải thưởng Khoa học Tự nhiên Việt Nam thuộc về 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ - Viện Vật lý, Viện Khoa học công nghệ Việt Nam với công trình “Nghiên cứu cấu trúc hạt nhân và các phản ứng hạt nhân”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn_d4aae.jpg Hai nhà khoa học đã tiến hành thành công các nghiên cứu về phản ứng hạt nhân với nơtron, phản ứng quang hạt nhân, quang phân hạch và các phản ứng hạt nhân khác có cơ chế phức tạp trên các máy gia tốc như máy phát nơtron, Microtron và các máy gia tốc thẳng của Việt Nam và Quốc tế. Các nghiên cứu này đã góp phần làm sáng tỏ cấu trúc hạt nhân và cơ chế phản ứng hạt nhân, đồng thời cung cấp nhiều số liệu hạt nhân mới có giá trị cho Kho tàng số liệu hạt nhân. GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ đã khai thác hiệu quả hai máy gia tốc đầu tiên của Việt Nam là máy phát nơtron NA-3-C và Microtron MT-17 trong nghiên cứu cơ bản, nghiên cứu ứng dụng và đào tạo nhân lực. Trên cơ sở các thiết bị này, hai nhà khoa học đã tiến hành thành công những nghiên cứu cơ bản thực nghiệm đầu tiên về phản ứng hạt nhân ở Việt Nam; nghiên cứu và phát triển các phương pháp phân tích hạt nhân hiện đại và áp dụng thành công ở Việt Nam. Bà Nguyễn Thị Doan, Phó Chủ tịch nước CHXHCNVN và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/khtn2_e2865.jpg Phó Chủ tịch nước CHXHCNVN Nguyễn Thị Doan và Giáo sư - Viện sỹ Nguyễn Văn Hiệu trao giải thưởng cho 2 nhà khoa học GS.TS Trần Đức Thiệp và GS.TS Nguyễn Văn Đỗ. GS.VS Nguyễn Văn Hiệu chia sẻ: “Cách đây không lâu, Chính phủ đã ký quyết định xây dựng nhà máy điện hạt nhân trong điều kiện đất nước còn nhỏ bé, nghèo khó và vì thế việc đào tạo nhân lực là nhiệm vụ số 1 hiện nay. Rất may, Việt Nam có 2 nhà khoa học cực kỳ tâm huyết và nổi tiếng trong cả nước cũng như trên thế giới. Hội đồng khoa học chúng tôi muốn xướng tên 2 nhà khoa học này để Chính phủ huy động cùng phát triển xây dựng nhà máy điện hạt nhân.” GS.VS Hiệu nhấn mạnh, mặc dù điều kiện làm việc của 2 nhà khoa học không được quan tâm, làm việc trên những máy móc cũ kỹ được mua từ năm 1992 nhưng 2 ông vẫn xay mê cống hiến hết mình cho lĩnh Khoa học tự nhiên Việt Nam. * Giải thưởng Nhân tài Đất Việt trong lĩnh vực Y Dược: 2 giải 1. Nhóm nghiên cứu của Bệnh viện Hữu nghị Việt - Đức với công trình “Nghiên cứu triển khai ghép gan, thận, tim lấy từ người cho chết não”. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y_3dca2.jpg Tại bệnh viện Việt Đức, tháng 4/2011, các ca ghép tạng từ nguồn cho là người bệnh chết não được triển khai liên tục. Với 4 người cho chết não hiến tạng, bệnh viện đã ghép tim cho một trường hợp, 2 người được ghép gan, 8 người được ghép thận, 2 người được ghép van tim và tất cả các ca ghép này đều thành công, người bệnh được ghép đã có một cuộc sống tốt hơn với tình trạng sức khỏe ổn định. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y2_cb5a1.jpg Nguyên Tổng Bí Ban chấp hành TW Đảng CSVN Lê Khả Phiêu và ông Vũ Văn Tiền, Chủ tịch Hội đồng quản trị Ngân hàng An Bình trao giải thưởng cho nhóm nghiên cứu của BV Hữu nghị Việt - Đức. Công trong việc ghép tạng từ người cho chết não không chỉ thể hiện năng lực, trình độ, tay nghề của bác sĩ Việt Nam mà nó còn mang một ý nghĩa nhân văn to lớn, mang một thông điệp gửi đến những con người giàu lòng nhân ái với nghĩa cử cao đẹp đã hiến tạng để cứu sống những người bệnh khác. 2. Hội đồng ghép tim Bệnh viện Trung ương Huế với công trình nghiên cứu “Triển khai ghép tim trên người lấy từ người cho chết não”. Đề tài được thực hiện dựa trên ca mổ ghép tim thành công lần đầu tiên ở Việt Nam của chính 100% đội ngũ y, bác sĩ của Bệnh viện Trung ương Huế đầu tháng 3/2011. Bệnh nhân được ghép tim thành công là anh Trần Mậu Đức (26 tuổi, ở phường Phú Hội, TP. Huế). http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/y3_7768c.jpg Hội đồng ghép tim BV Trung ương Huế nhận Giải thưởng Nhân tài Đất Việt. Ghép tim từ người cho chết não đến người bị bệnh tim cần được ghép tim phải đảm bảo các yêu cầu: đánh giá chức năng các cơ quan; đánh giá tương hợp miễn dịch và phát hiện nguy cơ tiềm ẩn có thể xảy ra trong và sau khi ghép tim để từ đó có phương thức điều trị thích hợp. Có tới 30 xét nghiệm cận lâm sàng trung và cao cấp tiến hành cho cả người cho tim chết não và người sẽ nhận ghép tim tại hệ thống labo của bệnh viện. --------------------- * Giải thưởng Nhân tài đất Việt Lĩnh vực Công nghệ thông tin. Hệ thống sản phẩm đã ứng dụng thực tế: Giải Nhất: Không có. Giải Nhì: Không có Giải Ba: 3 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ cạc xử lý tín hiệu HDTV” của nhóm HD Việt Nam. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/hdtv_13b10.jpg Nhóm HDTV Việt Nam lên nhận giải. Đây là bộ cạc xử lý tín hiệu HDTV đầu tiên tại Việt Nam đạt tiêu chuẩn OpenGear. Bộ thiết bị bao gồm 2 sản phẩm là cạc khuếch đại phân chia tín hiệu HD DA và cạc xử lý tín hiệu HD FX1. Nhờ bộ cạc này mà người sử dụng cũng có thể điều chỉnh mức âm thanh hoặc video để tín hiệu của kênh tuân theo mức chuẩn và không phụ thuộc vào chương trình đầu vào. 2. “Mã nguồn mở NukeViet” của nhóm tác giả Công ty cổ phần phát triển nguồn mở Việt Nam (VINADES.,JSC). /uploads/news/2011_11/nukeviet-nhantaidatviet2011.jpg NukeViet nhận giải ba Nhân tài đất Việt 2011 NukeViet là CMS mã nguồn mở đầu tiên của Việt Nam có quá trình phát triển lâu dài nhất, có lượng người sử dụng đông nhất. Hiện NukeViet cũng là một trong những mã nguồn mở chuyên nghiệp đầu tiên của Việt Nam, cơ quan chủ quản của NukeViet là VINADES.,JSC - đơn vị chịu trách nhiệm phát triển NukeViet và triển khai NukeViet thành các ứng dụng cụ thể cho doanh nghiệp. 3. “Hệ thống ngôi nhà thông minh homeON” của nhóm Smart home group. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16132_82014.jpg Sản phẩm là kết quả từ những nghiên cứu miệt mài nhằm xây dựng một ngôi nhà thông minh, một cuộc sống xanh với tiêu chí: An toàn, tiện nghi, sang trọng và tiết kiệm năng lượng, hưởng ứng lời kêu gọi tiết kiệm năng lượng của Chính phủ. * Hệ thống sản phẩm có tiềm năng ứng dụng: Giải Nhất: Không có. Giải Nhì: trị giá 50 triệu đồng: “Dịch vụ Thông tin và Tri thức du lịch ứng dụng cộng nghệ ngữ nghĩa - iCompanion” của nhóm tác giả SIG. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/nhi_7eee0.jpg Nhóm tác giả SIG nhận giải Nhì Nhân tài đất Việt 2011 ở hệ thống sản phẩm có tiềm năng ứng dụng. ICompanion là hệ thống thông tin đầu tiên ứng dụng công nghệ ngữ nghĩa trong lĩnh vực du lịch - với đặc thù khác biệt là cung cấp các dịch vụ tìm kiếm, gợi ý thông tin “thông minh” hơn, hướng người dùng và kết hợp khai thác các tính năng hiện đại của môi trường di động. Đại diện nhóm SIG chia sẻ: “Tinh thần sáng tạo và lòng khát khao muốn được tạo ra các sản phẩm mới có khả năng ứng dụng cao trong thực tiễn luôn có trong lòng của những người trẻ Việt Nam. Cảm ơn ban tổ chức và những nhà tài trợ đã giúp chúng tôi có một sân chơi thú vị để khuyến khích và chắp cánh thực hiện ước mơ của mình. Xin cảm ơn trường ĐH Bách Khoa đã tạo ra một môi trường nghiên cứu và sáng tạo, gắn kết 5 thành viên trong nhóm.” Giải Ba: 2 giải, mỗi giải trị giá 30 triệu đồng. 1. “Bộ điều khiển IPNET” của nhóm IPNET http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16149_ed58d.jpg Nhà báo Phạm Huy Hoàn, Trưởng Ban Tổ chức Giải thưởng NTĐV, Tổng Biên tập báo điện tử Dân trí và ông Tạ Hữu Thanh - Phó TGĐ Jetstar Pacific trao giải cho nhóm IPNET. Bằng cách sử dụng kiến thức thiên văn học để tính giờ mặt trời lặn và mọc tại vị trí cần chiếu sáng được sáng định bởi kinh độ, vĩ độ cao độ, hàng ngày sản phẩm sẽ tính lại thời gian cần bật/tắt đèn cho phù hợp với giờ mặt trời lặn/mọc. 2. “Hệ thống lập kế hoạch xạ trị ung thư quản lý thông tin bệnh nhân trên web - LYNX” của nhóm LYNX. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/3tiem-nang_32fee.jpg Đây là loại phần mềm hoàn toàn mới ở Việt Nam, là hệ thống lập kế hoạch và quản lý thông tin của bệnh nhân ung thư qua Internet (LYNX) dựa vào nền tảng Silverlight của Microsoft và kiến thức chuyên ngành Vật lý y học. LYNX giúp ích cho các nhà khoa học, bác sĩ, kỹ sư vật lý, bệnh nhân và mọi thành viên trong việc quản lý và theo dõi hệ thống xạ trị ung thư một cách tổng thể. LYNX có thể được sử dụng thông qua các thiết bị như máy tính cá nhân, máy tính bảng… và các trình duyệt Internet Explorer, Firefox, Chrome… Chương trình trao giải đã được truyền hình trực tiếp trên VTV2 - Đài Truyền hình Việt Nam và tường thuật trực tuyến trên báo điện tử Dân trí từ 20h tối 20/11/2011. http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0545_c898e.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/NVH0560_c995c.jpg http://dantri4.vcmedia.vn/xFKfMbJ7RTXgah5W1cc/File/2011/PHN16199_36a5c.jpg Khởi xướng từ năm 2005, Giải thưởng Nhân tài Đất Việt đã phát hiện và tôn vinh nhiều tài năng trong lĩnh vực CNTT-TT, Khoa học tự nhiên và Y dược, trở thành một sân chơi bổ ích cho những người yêu thích CNTT. Mỗi năm, Giải thưởng ngày càng thu hút số lượng tác giả và sản phẩm tham gia đông đảo và nhận được sự quan tâm sâu sắc của lãnh đạo Đảng, Nhà nước cũng như công chúng. Đối tượng tham gia Giải thưởng trong lĩnh vực CNTT là những người Việt Nam ở mọi lứa tuổi, đang sinh sống trong cũng như ngoài nước. Năm 2006, Giải thưởng có sự tham gia của thí sinh đến từ 8 nước trên thế giới và 40 tỉnh thành của Việt Nam. Từ năm 2009, Giải thưởng được mở rộng sang lĩnh vực Khoa học tự nhiên, và năm 2010 là lĩnh vực Y dược, vinh danh những nhà khoa học trong các lĩnh vực này');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_cat`
--

DROP TABLE IF EXISTS `nv4_vi_news_cat`;
CREATE TABLE `nv4_vi_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `descriptionhtml` text,
  `image` varchar(255) DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `keywords` text,
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_cat`
--

INSERT INTO `nv4_vi_news_cat` VALUES
(1, 0, 'Tin tức', '', 'Tin-tuc', '', '', '', 0, 1, 1, 0, 'viewcat_main_right', 3, '8,12,9', 1, 4, 2, 0, '', '', 1274986690, 1274986690, '6'), 
(2, 0, 'Sản phẩm', '', 'San-pham', '', '', '', 0, 2, 5, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274986705, 1274986705, '6'), 
(8, 1, 'Thông cáo báo chí', '', 'thong-cao-bao-chi', '', '', '', 0, 1, 2, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987105, 1274987244, '6'), 
(9, 1, 'Tin công nghệ', '', 'Tin-cong-nghe', '', '', '', 0, 3, 4, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987212, 1274987212, '6'), 
(10, 0, 'Đối tác', '', 'Doi-tac', '', '', '', 0, 3, 9, 0, 'viewcat_main_right', 0, '', 1, 4, 2, 0, '', '', 1274987460, 1274987460, '6'), 
(11, 0, 'Tuyển dụng', '', 'Tuyen-dung', '', '', '', 0, 4, 12, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987538, 1274987538, '6'), 
(12, 1, 'Bản tin nội bộ', '', 'Ban-tin-noi-bo', '', '', '', 0, 2, 3, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987902, 1274987902, '6');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_config_post`
--

DROP TABLE IF EXISTS `nv4_vi_news_config_post`;
CREATE TABLE `nv4_vi_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_logs`
--

DROP TABLE IF EXISTS `nv4_vi_news_logs`;
CREATE TABLE `nv4_vi_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_rows`
--

DROP TABLE IF EXISTS `nv4_vi_news_rows`;
CREATE TABLE `nv4_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_rows`
--

INSERT INTO `nv4_vi_news_rows` VALUES
(1, 1, '1,8,12', 0, 1, 'Quỳnh Nhi', 1, 1274989177, 1275318126, 1, 1274989140, 0, 2, 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam', 'Ra-mat-cong-ty-ma-nguon-mo-dau-tien-tai-Viet-Nam', 'Mã nguồn mở NukeViet vốn đã quá quen thuộc với cộng đồng CNTT Việt Nam trong mấy năm qua. Tuy chưa hoạt động chính thức, nhưng chỉ trong khoảng 5 năm gần đây, mã nguồn mở NukeViet đã được dùng phổ biến ở Việt Nam, áp dụng ở hầu hết các lĩnh vực, từ tin tức đến thương mại điện tử, từ các website cá nhân cho tới những hệ thống website doanh nghiệp.', 'nangly.jpg', 'Thành lập VINADES.,JSC', 1, 1, '6', 1, 1, 0, 0, 0), 
(2, 1, '1,8,12', 1, 1, 'laser', 2, 1274989787, 1275318114, 1, 1274989740, 0, 2, 'Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC', 'Cong-bo-du-an-NukeViet-3-0-sau-1-thang-ra-mat-VINADES-JSC', 'NukeViet 3.0 - Một nền tảng được xây dựng hoàn toàn mới với những công nghệ web tiên tiến nhất hiện nay hứa hẹn sẽ làm một cuộc cách mạng về mã nguồn mở ở Việt Nam. Món quà này là lời cảm ơn chân thành nhất mà VINADES.,JSC muốn gửi tới cộng đồng sau một tháng chính thức ra mắt.', 'nukeviet3.jpg', 'NukeViet 3.0', 1, 1, '6', 1, 1, 0, 0, 0), 
(5, 2, '2', 1, 1, '', 5, 1274993307, 1275318039, 1, 1274993280, 0, 2, 'Giới thiệu về mã nguồn mở NukeViet', 'Gioi-thieu-ve-ma-nguon-mo-NukeViet', 'Chắc hẳn đây không phải lần đầu tiên bạn nghe nói đến mã nguồn mở. Và nếu bạn là người mê lướt web thì hẳn bạn từng nhìn thấy đâu đó cái tên NukeViet. NukeViet, phát âm là Nu-Ke-Việt, chính là phần mềm dùng để xây dựng các Website mà bạn ngày ngày online để truy cập đấy.', 'screenshot.jpg', '6', 1, 0, '2', 1, 1, 0, 0, 0), 
(6, 10, '1,8,10', 0, 1, '', 2, 1274994722, 1275318001, 1, 1274994720, 0, 2, 'Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm', 'Thu-moi-hop-tac', 'Hiện tại VINADES.,JSC đang tiến hành phát triển bộ mã nguồn NukeViet phiên bản 3.0 – một thế hệ CMS hoàn toàn mới với nhiều tính năng ưu việt, được đầu tư bài bản với kinh phí lớn. Với thiện chí hợp tác cùng phát triển VINADES.,JSC xin trân trọng gửi lời mời hợp tác đến Quý đối tác là các công ty cung cấp tên miền - hosting, các doanh nghiệp quan tâm và mong muốn hợp tác cùng VINADES để cùng thực hiện chung các hoạt động kinh doanh nhằm gia tăng giá trị, quảng bá thương hiệu chung cho cả hai bên.', 'hoptac.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(7, 11, '11', 0, 1, '', 2, 1307197282, 1307197381, 1, 1307197260, 0, 2, 'Tuyển dụng lập trình viên, chuyên viên đồ họa phát triển NukeViet', 'Tuyen-dung-lap-trinh-vien-chuyen-vien-do-hoa-phat-trien-NukeViet', 'Bạn đam mê nguồn mở? Bạn có năng khiếu lập trình PHP & MySQL? Bạn là chuyên gia đồ họa, HTML, CSS? Chúng tôi sẽ giúp bạn hiện thực hóa ước mơ của mình với một mức lương đảm bảo. Hãy gia nhập VINADES.,JSC để xây dựng mã nguồn mở hàng đầu cho Việt Nam.', 'nukeviet-job.jpg', '6', 1, 1, '2', 1, 1, 0, 0, 0), 
(8, 9, '9', 0, 1, 'laser', 3, 1310067949, 1310068009, 1, 1310067949, 0, 2, 'Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt', 'Webnhanhvn-website-dich-vu-chuyen-nghiep-cho-NukeViet-chinh-thuc-ra-mat', 'Sau một thời gian đi vào hoạt động, Webnhanh.vn đã nhận được nhiều ủng hộ cùng sự quan tâm, góp ý của cộng đồng và khách hàng. Để đáp ứng mong mỏi của cộng đồng về một dịch vụ web chuyên nghiệp với mức giá tối thiểu, Webnhanh.vn đã thực hiện chiến dịch siêu khuyến mại Giảm giá tất cả các gói web dựng sẵn, module, block và giao diện (theme). Mức giảm giá cao nhất tới 90% giá so với trước tháng 7 năm 2011.', 'webnhanh-vn.jpg', '', 1, 1, '6', 1, 1, 0, 0, 0), 
(9, 2, '2', 0, 1, 'Phạm Thế Quang Huy', 4, 1322685396, 1322686088, 1, 1322685396, 0, 2, 'NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam', 'NukeViet-Cong-cu-ma-nguon-mo-cho-cong-dong-thiet-ke-website-Viet-Nam', '(Dân trí) - Là một trong những hệ quản trị nội dung nổi tiếng hàng đầu tại Việt Nam, NukeViet đã được áp dụng rộng rãi trong việc xây dựng nhiều trang báo điện tử và các cổng thông tin điện tử nổi tiếng tại Việt Nam. Mới đây nhất, NukeViet đã vượt qua vòng sơ khảo để tranh tài tại vòng chung khảo của Giải Thưởng Nhân Tài Đất Việt 2011', 'product_box.jpg', 'Sản phẩm dự thi Nhân tài Đất Việt 2011&#x3A; Mã nguồn mở NukeViet', 1, 1, '6', 1, 1, 0, 0, 0), 
(10, 1, '1,9', 0, 1, '', 4, 1322685920, 1322686042, 1, 1322685920, 0, 2, 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 'Ma-nguon-mo-NukeViet-gianh-giai-ba-Nhan-tai-dat-Viet-2011', 'Không có giải nhất và giải nhì, sản phẩm Mã nguồn mở NukeViet của VINADES.,JSC là một trong ba sản phẩm đã đoạt giải ba Nhân tài đất Việt 2011 - Lĩnh vực Công nghệ thông tin (Sản phẩm đã ứng dụng rộng rãi).', 'nukeviet-nhantaidatviet2011.jpg', 'Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', 1, 1, '6', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_sources`
--

DROP TABLE IF EXISTS `nv4_vi_news_sources`;
CREATE TABLE `nv4_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_sources`
--

INSERT INTO `nv4_vi_news_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(2, 'VINADES.,JSC', 'http://vinades.vn', '', 2, 1274989787, 1274989787), 
(3, 'NukeViet', 'http://nukeviet.vn', '', 2, 1274989787, 1274989787), 
(4, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 3, 1322685396, 1322685396);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tags`
--

DROP TABLE IF EXISTS `nv4_vi_news_tags`;
CREATE TABLE `nv4_vi_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=33  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_tags`
--

INSERT INTO `nv4_vi_news_tags` VALUES
(1, 2, 'nguồn-mở', '', '', 'nguồn mở'), 
(2, 1, 'quen-thuộc', '', '', 'quen thuộc'), 
(3, 2, 'cộng-đồng', '', '', 'cộng đồng'), 
(4, 2, 'việt-nam', '', '', 'việt nam'), 
(5, 1, 'hoạt-động', '', '', 'hoạt động'), 
(6, 1, 'tin-tức', '', '', 'tin tức'), 
(7, 1, 'thương-mại-điện', '', '', 'thương mại điện'), 
(8, 1, 'điện-tử', '', '', 'điện tử'), 
(9, 3, 'nukeviet', '', '', 'nukeviet'), 
(10, 1, 'nền-tảng', '', '', 'nền tảng'), 
(11, 1, 'xây-dựng', '', '', 'xây dựng'), 
(12, 2, 'quản-trị', '', '', 'quản trị'), 
(13, 2, 'nội-dung', '', '', 'nội dung'), 
(14, 2, 'sử-dụng', '', '', 'sử dụng'), 
(15, 2, 'khả-năng', '', '', 'khả năng'), 
(16, 2, 'tích-hợp', '', '', 'tích hợp'), 
(17, 2, 'ứng-dụng', '', '', 'ứng dụng'), 
(18, 1, 'vinades', '', '', 'vinades'), 
(19, 1, 'lập-trình-viên', '', '', 'lập trình viên'), 
(20, 1, 'chuyên-viên-đồ-họa', '', '', 'chuyên viên đồ họa'), 
(21, 1, 'php', '', '', 'php'), 
(22, 1, 'mysql', '', '', 'mysql'), 
(23, 1, 'khai-trương', '', '', 'khai trương'), 
(24, 1, 'khuyến-mại', '', '', 'khuyến mại'), 
(25, 1, 'giảm-giá', '', '', 'giảm giá'), 
(26, 1, 'siêu-khuyến-mại', '', '', 'siêu khuyến mại'), 
(27, 1, 'webnhanh', '', '', 'webnhanh'), 
(28, 1, 'thiết-kế-website', '', '', 'thiết kế website'), 
(29, 1, 'giao-diện-web', '', '', 'giao diện web'), 
(30, 1, 'thiết-kế-web', '', '', 'thiết kế web'), 
(31, 2, 'nhân-tài-đất-việt-2011', '', '', 'nhân tài đất việt 2011'), 
(32, 2, 'mã-nguồn-mở', '', '', 'mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_tags_id`
--

DROP TABLE IF EXISTS `nv4_vi_news_tags_id`;
CREATE TABLE `nv4_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_tags_id`
--

INSERT INTO `nv4_vi_news_tags_id` VALUES
(1, 1, 'nguồn mở'), 
(1, 2, 'quen thuộc'), 
(1, 3, 'cộng đồng'), 
(1, 4, 'việt nam'), 
(1, 5, 'hoạt động'), 
(1, 6, 'tin tức'), 
(1, 7, 'thương mại điện'), 
(1, 8, 'điện tử'), 
(1, 9, 'nukeviet'), 
(2, 10, 'nền tảng'), 
(2, 11, 'xây dựng'), 
(2, 1, 'nguồn mở'), 
(2, 4, 'việt nam'), 
(2, 3, 'cộng đồng'), 
(5, 12, 'quản trị'), 
(5, 13, 'nội dung'), 
(5, 14, 'sử dụng'), 
(5, 15, 'khả năng'), 
(5, 16, 'tích hợp'), 
(5, 17, 'ứng dụng'), 
(7, 18, 'vinades'), 
(7, 9, 'nukeviet'), 
(7, 19, 'lập trình viên'), 
(7, 20, 'chuyên viên đồ họa'), 
(7, 21, 'php'), 
(7, 22, 'mysql'), 
(8, 23, 'khai trương'), 
(8, 24, 'khuyến mại'), 
(8, 25, 'giảm giá'), 
(8, 26, 'siêu khuyến mại'), 
(8, 27, 'webnhanh'), 
(8, 28, 'thiết kế website'), 
(8, 29, 'giao diện web'), 
(8, 30, 'thiết kế web'), 
(9, 31, 'Nhân tài Đất Việt 2011'), 
(9, 32, 'mã nguồn mở'), 
(10, 31, 'Nhân tài đất Việt 2011'), 
(10, 32, 'mã nguồn mở'), 
(10, 9, 'nukeviet');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_news_topics`
--

DROP TABLE IF EXISTS `nv4_vi_news_topics`;
CREATE TABLE `nv4_vi_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_news_topics`
--

INSERT INTO `nv4_vi_news_topics` VALUES
(1, 'NukeViet 3', 'NukeViet-3', '', 'NukeViet 3', 1, 'NukeViet 3', 1274990212, 1274990212);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_page`
--

DROP TABLE IF EXISTS `nv4_vi_page`;
CREATE TABLE `nv4_vi_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_page_config`
--

DROP TABLE IF EXISTS `nv4_vi_page_config`;
CREATE TABLE `nv4_vi_page_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_page_config`
--

INSERT INTO `nv4_vi_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_referer_stats`
--

DROP TABLE IF EXISTS `nv4_vi_referer_stats`;
CREATE TABLE `nv4_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_searchkeys`
--

DROP TABLE IF EXISTS `nv4_vi_searchkeys`;
CREATE TABLE `nv4_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `skey` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting`
--

DROP TABLE IF EXISTS `nv4_vi_voting`;
CREATE TABLE `nv4_vi_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_voting`
--

INSERT INTO `nv4_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 3?', '', 1, 1, '6', 1275318563, 0, 1), 
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', '', 1, 1, '6', 1275318563, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_vi_voting_rows`
--

DROP TABLE IF EXISTS `nv4_vi_voting_rows`;
CREATE TABLE `nv4_vi_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_vi_voting_rows`
--

INSERT INTO `nv4_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);